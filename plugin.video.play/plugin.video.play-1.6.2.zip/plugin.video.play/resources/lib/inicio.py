import os
import sys
import xbmc
import shutil
import xbmcgui
import xbmcaddon
import xbmcvfs
from xbmcvfs import translatePath as TRANSLATEPATH
import urllib.request
import xml.etree.ElementTree as ET
import zipfile


def copiar_carpeta(origen, destino):

    # 🔹 CASO 1: ORIGEN ES ARCHIVO (sources.xml, advancedsettings.xml)
    if os.path.isfile(origen):
        if not os.path.exists(destino):
            shutil.copy2(origen, destino)
        return

    # 🔹 CASO 2: ORIGEN ES CARPETA
    if os.path.isdir(origen):

        # Si destino no existe → copiar todo
        if not os.path.exists(destino):
            shutil.copytree(origen, destino)
            return

        # Si destino existe → copiar solo lo que falte
        for item in os.listdir(origen):
            origen_item = os.path.join(origen, item)
            destino_item = os.path.join(destino, item)

            if not os.path.exists(destino_item):
                if os.path.isdir(origen_item):
                    shutil.copytree(origen_item, destino_item)
                else:
                    shutil.copy2(origen_item, destino_item)
                    
full_version = xbmc.getInfoLabel('System.BuildVersion')
major_version = int(full_version.split('.')[0])
if major_version <= 20:   
    version_kodi = 'skin.xonfluence'
    origen_advancedsettings = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/advancedsettings.xml')
    destino_advancedsettings = TRANSLATEPATH('special://userdata/advancedsettings.xml')
    copiar_carpeta(origen_advancedsettings, destino_advancedsettings)
elif major_version >= 21:
    version_kodi = 'skin.xonfluence_O'
    

#xbmcgui.Dialog().ok("Resultado", f"version de kodi: {major_version}")

origen_xonfluence = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/skin.xonfluence')
origen_play = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/plugin.video.play')
origen_embuary = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/script.embuary.info')
origen_sources = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/sources.xml')


addon_data_folder = TRANSLATEPATH('special://profile/addon_data/')

destino_xonfluence = os.path.join(addon_data_folder, f'{version_kodi}')
destino_play = os.path.join(addon_data_folder, 'plugin.video.play')
destino_embuary = os.path.join(addon_data_folder, 'script.embuary.info')
destino_sources = TRANSLATEPATH('special://userdata/sources.xml')
        
copiar_carpeta(origen_xonfluence, destino_xonfluence)
copiar_carpeta(origen_play, destino_play)
copiar_carpeta(origen_embuary, destino_embuary)
copiar_carpeta(origen_sources, destino_sources)
# 1. Resolvemos las rutas del directorio de forma compatible con Windows y Android
TRANSLATEPATH = xbmc.translatePath if sys.version_info[0] == 2 else xbmcvfs.translatePath
ruta_lib = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib')
# 2. MODIFICACIÓN CLAVE: Buscamos si existe al menos un archivo que contenga "beeg_"
existe_disparador = False
if os.path.exists(ruta_lib):
    for archivo in os.listdir(ruta_lib):
        if "beeg_" in archivo:
            existe_disparador = True
            break  # Con encontrar uno solo, activamos el disparador de limpieza

# 3. Si el disparador se activó, borramos todos los que contengan "beeg" y terminen en ".xml"
if existe_disparador:
    # 3. Escaneamos la carpeta resources/lib
    if os.path.exists(ruta_lib):
        for archivo in os.listdir(ruta_lib):
            # Filtramos: que el nombre contenga "beeg" y termine en ".xml"
            if "beeg" in archivo and archivo.endswith(".xml"):
                ruta_completa = os.path.join(ruta_lib, archivo)
                try:
                    # Borramos el archivo físico
                    os.remove(ruta_completa)
                    xbmc.log(f"[plugin.video.play] Caché XML eliminada: {archivo}", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[plugin.video.play] Error al borrar {archivo}: {str(e)}", xbmc.LOGERROR)

    




    
    
    






