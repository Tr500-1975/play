import xbmc
import xbmcgui
import time
import os
import sys
import urllib.request
import requests
import re
from xbmcvfs import translatePath as variacion_translatePath

def revision(url_final, ruta_cache):
    try:
        req = urllib.request.Request(url_final, method='HEAD')
        with urllib.request.urlopen(req, timeout=5) as response:
            # Obtenemos el tamaño exacto en BYTES (Content-Length) del servidor
            peso_remoto = int(response.getheader('Content-Length', 0))
    except Exception as e:
        peso_remoto = -1
        
    # Crear la carpeta si no existe
    carpeta_cache = os.path.dirname(ruta_cache)
    if not os.path.exists(carpeta_cache):
        os.makedirs(carpeta_cache)

    # Si el archivo no existe, se crea vacío
    if not os.path.exists(ruta_cache):
        with open(ruta_cache, "w") as f:
            pass

    # Leemos el peso en Bytes guardado de la última descarga exitosa
    ruta_size = ruta_cache + ".size"
    peso_local = 0
    if os.path.exists(ruta_size):
        try:
            with open(ruta_size, "r") as f:
                peso_local = int(f.read())
        except:
            pass
    #xbmc.log(f'{peso_remoto}', xbmc.LOGINFO)      
    #xbmcgui.Dialog().ok("SISTEMA", F'peso_remoto: {peso_remoto}\n peso_local: {peso_local}')
    if peso_remoto != -1 and peso_remoto != peso_local:
        try:
            pDialog = xbmcgui.DialogProgressBG()
            pDialog.create('SISTEMA', 'Descargando desde Internet...')
            pDialog.update(20)# Mostramos la barra al 50% de progreso
            xbmc.sleep(55)
            # Descargamos los datos y los guardamos forzando formato UTF-8 para evitar el error
            with urllib.request.urlopen(url_final, timeout=10) as r: 
                raw_data = r.read()
            pDialog.update(40)
            xbmc.sleep(55)
            try:
                datos = raw_data.decode('utf-8')
            except UnicodeDecodeError:
                datos = raw_data.decode('latin-1', errors='ignore')
            pDialog.update(60)
            xbmc.sleep(55)
            with open(ruta_cache, "w", encoding="utf-8", errors="ignore") as f:
                f.write(datos)
            pDialog.update(80)
            xbmc.sleep(55)
            # Guardamos el peso en bytes original del servidor
            with open(ruta_size, "w") as f:
                f.write(str(peso_remoto))
                
            pDialog.update(100)
            xbmc.sleep(55)
            pDialog.close()
        except Exception as e:
            pass       
    ruta = ruta_cache        
    return ruta   
    
def pcloud(url, ruta_cache):
    url = url.replace('_', '')
    #xbmcgui.Dialog().textviewer("estoy dentro de mi funcion", url)   
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url, headers=headers)
    html_content = response.text    
                                    #aqui buscamos para darle valor a v1    
    match = re.search('(?s)downloadlink": "(.*?)"', html_content)
    v1 = match.group(1) 
    url_final = f"{v1}".replace("\\", "") + "|User-Agent=iPad"
    #xbmc.log("resultado variable 2: " + url_final, xbmc.LOGINFO)     
    #xbmcgui.Dialog().ok("resultado variable 2", v1)    
    ruta = revision(url_final, ruta_cache)
    return ruta
    
def pelisespa(url): 
    ruta_cache = variacion_translatePath('special://profile/addon_data/plugin.video.play/cache_pelisespa.html')
    ruta = pcloud(url, ruta_cache)
    return ruta
    
def salon_series(url):
    ruta_cache = variacion_translatePath('special://profile/addon_data/plugin.video.play/cache_salon_series.html')
    ruta = pcloud(url, ruta_cache)
    return ruta
    
def topuria():
    ruta_especial = variacion_translatePath('special://home/addons/plugin.video.play/resources/lib/contador.txt')
    def cargar_contador():
        if os.path.exists(ruta_especial):
            with open(ruta_especial, "r") as f:
                return int(f.read())
        else:
            return 1

    def guardar_contador(a):
        with open(ruta_especial, "w") as f:
            f.write(str(a))     
    topuria.a = cargar_contador()    
    if topuria.a == 1:
        mp3 = "special://home/addons/plugin.video.play/resources/lib/topuria.mp3"
        xbmc.executebuiltin(f'PlayMedia({mp3})')        
        #time.sleep(8)        
    topuria.a += 1
    guardar_contador(topuria.a)
    #xbmc.log(f'{url_final}', xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("url_final", str(url_final)) 
    url = "https://e.pcloud.link/publink/show?code=XZ8LUrZXsEkC4O8qAm96ygHXXod35L9R7jk"
    ruta_cache = variacion_translatePath('special://profile/addon_data/plugin.video.play/cache_topuria.html')
    ruta = pcloud(url, ruta_cache)
    return ruta    