import base64
import xbmcgui
import xbmc
import xbmcplugin
import xbmcaddon
import ast
import traceback
import xbmcvfs
from bs4 import BeautifulSoup
import requests
import re
from urllib.parse import quote
import inspect
import sys
import time
import threading
import os
from html import unescape
import html
import sqlite3
import urllib
from urllib.parse import urlparse
import urllib.parse
import unicodedata
import json
import datetime
from xbmcvfs import translatePath as variacion_translatePath
from concurrent.futures import ThreadPoolExecutor

html_content_errores = ''
HEADERS = {
    "android": {
        "User-Agent": "Mozilla/5.0 (Linux; Android 9; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    },
    "desktop": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    },
}
TRANSLATEPATH = xbmcvfs.translatePath
# Parámetros de Kodi
HANDLE = int(sys.argv[1])
ADDON_ID = sys.argv[0]
WEB_BASE = "https://www.elseptimoarte.net"
def procesar_pelicula(sesion, imagen):
    if not 'temporada' in imagen:
        # [REGEXP 2] Extrae el slug de la película a partir de la URL de la imagen
        m_slug = re.search(r'/([^/]+)\.jpg$', imagen)
        if not m_slug:
            return None

        slug = m_slug.group(1)
        url_pelicula = "https://www.justwatch.com/es/pelicula/" + slug
    else:
        xbmc.log(f"URL DE temporada: {imagen}", xbmc.LOGINFO)
        xbmcgui.Dialog().ok("Capturado", f"URL DE temporada: {imagen}")
        url_pelicula = imagen
    try:
        html2 = sesion.get(url_pelicula, timeout=5).text
    except Exception:
        return None

    # Si detecta que no es la película, salta a la siguiente
    if 'alt="JustWatch" title="JustWatch"' in html2 or 'alt="Cinesa" title="Cinesa"' in html2:
        return None
    if 'div class="title-detail-hero-details__item' in html2:
        # Filtro para descartar duraciones menores a 59 minutos
        duracion_match = re.search(
            r'div class="title-detail-hero-details__item[^"]*?"[^>]*?>\s*?((?:\d+h\s*)?(?:\d+min|\d+h))\s*?<',
            html2,
            re.S
        )

        if duracion_match:
            texto_duracion = duracion_match.group(1)  # Ejemplo: "1h 15min" o "45min"
            
            horas = 0
            minutos = 0
            
            # Extraemos las horas y los minutos si existen
            h_match = re.search(r'(\d+)h', texto_duracion)
            m_match = re.search(r'(\d+)min', texto_duracion)
            
            if h_match:
                horas = int(h_match.group(1))
            if m_match:
                minutos = int(m_match.group(1))
                
            total_minutos = (horas * 60) + minutos
            
            # Si la duración total es inferior a 59 minutos, se descarta
            if total_minutos < 59:
                return None
    # [REGEXP 3] Extrae la fecha de estreno en la página individual de la película
    m_fecha = re.search(
        r'upcoming-box__title-info--date">(.*?)<.*?img class="picture-comp__img" alt=.*?src="([^"]*)', 
        html2, 
        re.S
    )
    
    if m_fecha:
        return {
            "imagen": imagen,
            "fecha": m_fecha.group(1)
        }
    else:
        # Intenta la segunda expresión regular buscando el formato YYYY-MM-DD (ej: 2026-08-07)
        m_fecha = re.search(
            r'</path></svg><div.*?(\d{4}-\d{2}-\d{2})', 
            html2, 
            re.S
        )
        if m_fecha:
            return {
                "imagen": imagen,
                "fecha": m_fecha.group(1)
            }
    return None

def justwatch():
    url = "https://www.justwatch.com/es/peliculas/proximamente?production_countries=ES"

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/138.0.0.0 Safari/537.36"
        )
    }

    sesion = requests.Session()
    sesion.headers.update(headers)

    try:
        html = sesion.get(url, timeout=15).text
    except Exception:
        sys.exit()

    # [REGEXP 1] Obtiene todas las URLs .jpg del listado principal
    imagenes = re.findall(r'https://[^"]+?\.jpg', html)
   
    # Solo posiciones impares (1ª, 3ª, 5ª...)
    imagenes = imagenes[::2]
    
    imagenes_modificadas = []
    for imagen in imagenes:
        if "temporada" in imagen:
            # Reemplaza el guion por un espacio (ej: temporada-4 -> temporada 4)
            termino_busqueda = imagen.split('/')[-1].replace('.jpg', '').replace('-', ' ')
            '''xbmcgui.Dialog().ok("Capturado", f"{termino_busqueda}")
            sys.exit()'''
            # Busca en el HTML el href correspondiente al término de búsqueda
            patron_href = fr'{termino_busqueda}.*?href="([^"]+?)"[^>]*?>.*?'
            m_href = re.search(patron_href, html, re.I | re.S)
            
            if m_href:
                url_capturada = m_href.group(1)
                # Reemplaza la URL de la imagen por la nueva URL construida
                imagen = "https://www.justwatch.com" + url_capturada
                
        imagenes_modificadas.append(imagen)

    # Elimina los duplicados de la lista de forma eficiente manteniendo el orden original
    imagenes = list(dict.fromkeys(imagenes_modificadas))

    '''xbmc.log(f"IMAGENES {imagenes}", xbmc.LOGINFO)
    xbmcgui.Dialog().ok("imagenes", "vete al Log")
    sys.exit()'''
    estrenos = []

    # Procesamos las imágenes en paralelo usando hilos (hasta 10 simultáneos)
    with ThreadPoolExecutor(max_workers=10) as executor:
        # Enviamos todas las URLs a procesar
        resultados = executor.map(lambda img: procesar_pelicula(sesion, img), imagenes)
        
        # Recogemos los resultados válidos evitando los nulos
        for resultado in resultados:
            if resultado:
                estrenos.append(resultado)

    xbmc.log(f"ESTRENOS {estrenos}", xbmc.LOGINFO)
    xbmcgui.Dialog().ok("Capturado", "vete al Log")
    sys.exit()

   
def Texto_url(url):    
    #regex = "href='([^']*\.torrent[^']*)'"
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'
}
    response = requests.get(url, headers=headers, verify=False, timeout=10)
    html_content = response.text 
    return html_content

    
    
def beeg (url, nombre_actriz):   
    '''https://store.externulls.com/facts/tag?slug=ApoloniaLapiedra&limit=60&offset=0### este es el limite maximos de videos limit=60 y offset=0 son los videos que debe saltarse si quieres de 101 a 200 seria limit=100&offset=100'''
    # 1. Resolvemos la ruta del archivo al inicio para poder comprobarlo
    TRANSLATEPATH = xbmc.translatePath if sys.version_info[0] == 2 else xbmcvfs.translatePath
    ruta_lib = TRANSLATEPATH('special://profile/addon_data/plugin.video.play')
    archivo_xml = os.path.join(ruta_lib, f'beeg_{nombre_actriz}.xml')

    # 2. CONDICIÓN DE TIEMPO: Comprobamos si el archivo existe y es nuevo (menos de 4 días)
    if xbmcvfs.exists(archivo_xml):
        # 12 horas = 43200 segundos los enlaces expiran entre 13 y 14 horas
        limite_antiguedad = 43200
        segundos_transcurridos = time.time() - os.path.getmtime(archivo_xml)
        #xbmcgui.Dialog().ok(str(segundos_transcurridos), "if not")
        if segundos_transcurridos < limite_antiguedad:
            # Si el archivo tiene menos de 12 horas, no hace nada y sale            
            xml = ruta_lib + f'/beeg_{nombre_actriz}.xml'            
            xml = xml.replace('\\', '/')
            #xbmc.log("A VER " + f"{xml}", xbmc.LOGINFO)
            #xbmcgui.Dialog().ok("if not", "if not")
            return xml

    # 3. Si no existe o es más antiguo de 4 días, realiza todo el proceso
    texto_url = Texto_url(url)    
    # Expresión regular unificada
    regex = r'(?s)"file":.*?cd_file":\s+([^,]+),.*?"cd_value": "(.*?)".*?"fl_duration":\s+([^,]+),.*?"fl_cdn_multi": "(.*?)"'    
    # 3. Buscamos todas las coincidencias en el documento
    coincidencias = re.findall(regex, texto_url)
    
    # Nos aseguramos de que la ruta exista
    if not xbmcvfs.exists(ruta_lib):
        xbmcvfs.mkdirs(ruta_lib)

    # ==========================================
    # 4. CONSTRUIR EL CONTENIDO XML SOLICITADO
    # ==========================================
    xml_content = "<items>\n"
    xml_content += "<setviewmode>508</setviewmode>\n"  # BS4 en tu default parsea las etiquetas en minúsculas
    
    for id_foto, titulo, duracion, link in coincidencias:
        id_foto_limpio = str(id_foto)
        
        try:
            minutos = int(duracion) // 60
        except:
            minutos = 0
        
        titulo_final = f"[COLOR blue]{minutos}min[/COLOR] [COLOR gray]{titulo}[/COLOR]"
        url_foto = f"https://thumbs.externulls.com/videos/{id_foto_limpio}/0.webp?size=1280x720"
        
        # Construimos el enlace a 1080p con cabeceras de reproducción
        enlace_m3u8 = "https://video.beeg.com/" + link
        
        url_reproduccion = f"{enlace_m3u8}"
        
        # Estructura del item requerida por tu default para inputstream (mode 20)
        xml_content += "<item>\n"
        xml_content += f"  <title>{titulo_final}</title>\n"
        xml_content += f"  <inputstream>{url_reproduccion}</inputstream>\n"
        xml_content += f"  <thumbnail>{url_foto}</thumbnail>\n"
        xml_content += f"  <fanart>{url_foto}</fanart>\n"
        xml_content += "</item>\n"
        
    xml_content += "</items>"

    # ==========================================
    # 5. GUARDAR EL ARCHIVO XML EN DISCO
    # ==========================================
    try:
        with open(archivo_xml, 'w', encoding='utf-8') as f:
            f.write(xml_content)
    except:
        # Fallback de codificación para entornos antiguos
        with open(archivo_xml, 'w') as f:
            f.write(xml_content.encode('utf-8'))

    xml = ruta_lib + f'/beeg_{nombre_actriz}.xml'            
    xml = xml.replace('\\', '/')
    return xml
def cardio():
    
    #xbmcgui.Dialog().ok("cardio", "dentro")
    class InputWindow(xbmcgui.WindowDialog):
        def __init__(self, *args, **kwargs):
            self.txt = kwargs.get('txt', '')

            super().__init__()
            path = xbmcaddon.Addon().getAddonInfo('path')
            self.kbd = xbmc.Keyboard()
            self.kbd.setHiddenInput(True)  # Oculta la entrada del teclado
            self.kbd.setHeading(self.txt)

        def get(self):
            self.show()
            
            self.kbd.doModal()
            if self.kbd.isConfirmed():
                text = self.kbd.getText()
                self.close()
                return text
            self.close()
            return False
    
    def paso2(url):
        from myFunctions import Archivo_pcloud
        url_final = Archivo_pcloud(url)        
        return url_final
    def GetLSProData(page_data, Cookie_Jar, m, txt='Necesitas saber la clave para entrar'):
        
        addon = xbmcaddon.Addon('plugin.video.play')
        addon_version = addon.getAddonInfo('version')
        profile = variacion_translatePath(addon.getAddonInfo('profile'))

        solver = InputWindow(txt=txt)
        solution = solver.get()
        
        if solution == 'pichon3' or solution == 'ñ':
            url = "https://e.pcloud.link/publink/show?code=XZfRIrZP9W1Km22UvhY46YBjPX75bOhkKzV"
            final_url= paso2(url)
            return final_url
        else:
            # Correcta indentación para el bloque else
            addon_icon_path = os.path.join(variacion_translatePath('special://home/addons/plugin.video.play'), 'icon.png')
            icon_path = variacion_translatePath(addon_icon_path)
            
            xbmcgui.Dialog().notification(
                '[COLOR green]                     No te sabes la clave[/COLOR]',
                '[COLOR pink][B]Pues te vas a quedar con las ganas de verlo. :)[/COLOR][/B]',
                icon=icon_path,
                time=10000
            )
            
            url_fallo = "https://e.pcloud.link/publink/show?code=XZRbOrZlGyleCDRQwhKl6pHG3fJdFvuo19k"
            final_url= paso2(url_fallo)
            return final_url
    return GetLSProData("", "", None)    
def get_html(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
    try:
        r = requests.get(url, headers=headers, timeout=15)
        r.encoding = 'utf-8'
        return r.text
    except:
        return ""
def escritura_titulo_fechas(sitio_web, titulo, fecha):        
    ruta_addon_data = variacion_translatePath('special://profile/addon_data/plugin.video.play')
    if not os.path.exists(ruta_addon_data):
        os.makedirs(ruta_addon_data)

    ruta_txt = os.path.join(ruta_addon_data, 'titulo_fechas.txt')                            
    # Añadimos la línea con formato "Título|Fecha" al final del archivo
    with open(ruta_txt, 'a', encoding='utf-8') as f:
        f.write(f"{sitio_web}|{titulo}|{fecha}\n")
    return    
def Estrenos_Kodi(p_titulo, titulo_pelicula=False):
    url_fase_2 = sys.argv[0] + sys.argv[2]
    #xbmc.log("A VER " + f"{url_fase_2}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("Entrando en funcion Estrenos_Kodi", f"{p_titulo}")
    
    if not "&fase=imprimir" in sys.argv[2] and titulo_pelicula==False:
        
        liberar_reproductor()
          
        url_fase_2 = sys.argv[0] + sys.argv[2] + "&fase=imprimir"
        #xbmc.log("A VER " + f"{url_fase_2}", xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("if not", "if not")
        
        xbmc.executebuiltin(f"Container.Update({url_fase_2})")
        
        
    else: 
        #Estas dos linias ejecutan el cartel de arriba de kodi muy chulo
        #pDialog = xbmcgui.DialogProgressBG()
        #pDialog.create('Petra', 'Cargando estrenos...')
        
        #el jsonrpc ejecuta el cartelito de cargando 
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"GUI.ActivateWindow","params":{"window":"busydialog"},"id":1}')
        
        # 1. Generar URL por fecha
        ahora = datetime.datetime.now()
        meses = {
            1: "enero", 2: "febrero", 3: "marzo", 4: "abril", 5: "mayo", 6: "junio",
            7: "julio", 8: "agosto", 9: "septiembre", 10: "octubre", 11: "noviembre", 12: "diciembre"
        }        
        url_mes = f"{WEB_BASE}/estrenos/vod/{ahora.year}/{meses[ahora.month]}/"
        
        html_p1 = get_html(url_mes)
        
        if not html_p1: return

        # 2. aqui busca las paginas que existen si son 2 o mas
        paginas = [url_mes]
        enlaces_pag = re.findall(r'href="(/estrenos/vod/\d+/[^/]+/\d+/)"', html_p1)
        for p in enlaces_pag:
            full_url = WEB_BASE + p
            if full_url not in paginas:
                paginas.append(full_url)        
        paginas = sorted(list(set(paginas)))

        items_kodi = []
        regex_str = r'(?s)data-lazy-image="([^"]+)".*?title="([^"]+)".*?<p>(.*?)</p>'
        
        for url_pag in paginas:
            html = get_html(url_pag)
            matches = re.findall(regex_str, html)           
            for img_part, titulo_raw, fecha_raw in matches:
                imagen_full = WEB_BASE + img_part
                fecha_sucio = unescape(fecha_raw).strip()
                
                # Filtro de seguridad
                if "https:" in fecha_sucio: continue
                
                # 1. Formateamos la fecha
                match_f = re.search(r'([a-zA-Záéíóú]+)\s+(\d+),\s+(\d+)', fecha_sucio)
                if match_f:
                    mes, dia, anio = match_f.groups()
                    fecha = f"{dia} {mes} {anio}"                        
                else:
                    fecha = fecha_sucio
                
                # 2. Limpiamos título
                titulo = unescape(titulo_raw).strip()
                if titulo_pelicula:
                    #xbmcgui.Dialog().ok("comparando titulos", f"titulo {titulo}   p_titulo:  {p_titulo}")
                    if titulo == p_titulo:
                        #xbmcgui.Dialog().ok("estoy dentro", f'a ver si sigue el cosdigo')
                        # Invertimos su diccionario "meses" dinámicamente de (Número: Texto) a (Texto: Número)
                        meses_inv = {v: str(k) for k, v in meses.items()}
                        
                        partes = fecha.split()
                        if len(partes) == 3:
                            fecha = f"{partes[0]}/{meses_inv.get(partes[1].lower(), '1')}/{partes[2]}"
                        sitio_web = False    
                        escritura_titulo_fechas(sitio_web, titulo, fecha)   
                        return fecha
                        xbmc.log("A VER " + f"{titulo}   y fecha: {fecha}", xbmc.LOGINFO)
                        xbmcgui.Dialog().ok("comparando titulos", f"{titulo}   fecha:  {fecha}")
                        sys.exit()
                        
                # 3. Construimos el label con tus colores (Oro para fecha, Verde para título)
                label_display = f"[COLOR gold]{fecha}[/COLOR] [COLOR green][B]{titulo}[/B][/COLOR]"
                
                list_item = xbmcgui.ListItem(label=label_display)
                list_item.setArt({'thumb': imagen_full, 'icon': imagen_full})
                
                info = list_item.getVideoInfoTag()
                info.setTitle(label_display)
                info.setPlot(f"Estreno: {fecha}")

                url_click = f"{ADDON_ID}?action=play&name={urllib.parse.quote_plus(titulo)}"
                items_kodi.append((url_click, list_item, False))
                
        #xbmcgui.Dialog().ok("if not", "else")
        if items_kodi:
            '''if len(items_kodi) > 0:
                items_kodi.pop() # Elimina el último elemento de la lista'''
            # 1. Configuramos la vista
            xbmcplugin.setContent(HANDLE, 'movies')
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
            
            # 2. Imprimimos los items
            xbmcplugin.addDirectoryItems(HANDLE, items_kodi)
            
            # 3. Finalizamos el directorio (esto bloquea la ventana para que se vea)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True)       
            
            #4. Modo de vision
            monitor = xbmc.Monitor() 
            start_time = time.time()               
            while time.time() - start_time < 30:               
                esta_cargando = xbmc.getCondVisibility("Window.IsActive(busydialog)")
                ''' Si no esta la ruletita de cargando es por que esta en la ventana que quieres cambiar la vision, asi la ventana de atras conservara su vision'''
                #xbmcgui.Dialog().ok('Actulizado', f'ruletita = {esta_cargando}')
                if not esta_cargando:
                    #xbmcgui.Dialog().ok('Actulizado', f'{esta_actualizando}')
                    break
                if monitor.waitForAbort(0.05):
                    break    
            xbmc.executebuiltin("Container.SetViewMode(501)")           
        else:
            xbmcplugin.endOfDirectory(HANDLE, False)
    
def eventos(url):
    ruta_especial = variacion_translatePath('special://profile/addon_data/plugin.video.play/contador_hala.txt')
    
    def cargar_contador():
        if xbmcvfs.exists(ruta_especial):
            with open(ruta_especial, "r") as f:
                return int(f.read())
        else:
            return 1

    def guardar_contador(a):
        with open(ruta_especial, "w") as f:
            f.write(str(a))     
    contador_actual = cargar_contador()    
    if contador_actual == 1:
        mp3 = "special://home/addons/plugin.video.play/resources/lib/Hala_Madrid.mp3"
        xbmc.executebuiltin(f'PlayMedia({mp3})')            
    
    contador_actual += 1
    guardar_contador(contador_actual)
    
    
    traduccion_dias = {
        'MONDAY': 'LUNES',
        'TUESDAY': 'MARTES',
        'WEDNESDAY': 'MIÉRCOLES',
        'THURSDAY': 'JUEVES',
        'FRIDAY': 'VIERNES',
        'SATURDAY': 'SÁBADO',
        'SUNDAY': 'DOMINGO'
    }
    
    # 1. PREPARAMOS LA RUTA FÍSICA
    ruta_especial = 'special://home/addons/plugin.video.play/resources/lib/eventos.html'
    a = xbmcvfs.translatePath(ruta_especial)
    
    # --- INICIO DEL SISTEMA DE CACHÉ ---
    if xbmcvfs.exists(a):
        fecha_archivo = os.path.getmtime(a)
        ahora = time.time()
        segundos_cache = 1#0800 # 3 horas
        
        if (ahora - fecha_archivo) < segundos_cache:
            #xbmc.log(">>> MODO VAGO: Cargando desde el archivo local (Cache activa)", xbmc.LOGINFO)
            return a 
    # --- FIN DEL SISTEMA DE CACHÉ ---

    # Intentamos bajar la web si la caché falló o es vieja
    #xbmc.log(">>> MODO TRABAJO: Scrapeando web...", xbmc.LOGINFO)
    try:
        r = requests.get(url, timeout=10)
        r.encoding = 'utf-8'
        html_content = r.text
    except:
        # Si la web falla pero el archivo existe (aunque sea viejo), lo devolvemos
        if xbmcvfs.exists(a): return a
        return None

    # 2. ESQUELETO DEL HTML
    xml_header = """<html>
<head>
<style>body { background-size: cover; }</style>
</head>
<body BGCOLOR="#FEE64" TEXT="#000000" BACKGROUND="https://dl.dropbox.com/s/obarsb0ksu07ct6/gratis-png-emoticon-pulgar-arriba-emoticon-smiley-senal-pulgar-sonrisa-encantadora.png?dl=1">
<div id="oculto" style="visibility:hidden">
<items><SetViewMode>515</SetViewMode><item>
	<title>[COLOR violet]Documental: El 7 maravilla[/COLOR]</title>
	<inputstream>$doregex[series]</inputstream>
		<regex>
			<name>series</name>
			<expres>$pyFunction:petra.urlsolve("zdn83c18az2ipgmjo91j")</expres>
			<page></page>
		</regex>	<thumbnail>https://dl.dropbox.com/scl/fi/hnboxn1uboem37s93zg0r/el-7-maravilla.jpg?rlkey=3yikt2unfdyuk105aalerbn3q&st=jg4c3nyv&dl=0</thumbnail>
</item>"""

    xml_footer = """</items>
</div>
</body>
</html>"""

    items_acumulados = []
    patron = r"\b(MONDAY|TUESDAY|WEDNESDAY|THURSDAY|FRIDAY|SATURDAY|SUNDAY)\b|^(.*(hd6|hd10|hd11).*)$"
    dia_actual = "CALENDARIO"
    ultimo_dia = ""

    # 3. BUSQUEDA Y TRADUCCIÓN
    for coincidencia in re.finditer(patron, html_content, re.MULTILINE):
        if coincidencia.group(1):
            dia_ingles = coincidencia.group(1)
            dia_actual = traduccion_dias.get(dia_ingles, dia_ingles)
        
        elif coincidencia.group(2):
            if dia_actual != ultimo_dia:
                item_dia = f"""<item>
<title>[COLOR yellow]=== {dia_actual} ===[/COLOR]</title>
<link>NA</link>
<thumbnail>https://ih1.redbubble.net/image.3307659620.2337/bg,f8f8f8-flat,750x,075,f-pad,750x1000,f8f8f8.u1.jpg</thumbnail><fanart>https://e0.pxfuel.com/wallpapers/306/906/desktop-wallpaper-real-madrid-with-fire.jpg</fanart>
</item>"""
                items_acumulados.append(item_dia)
                ultimo_dia = dia_actual
            
            texto = re.sub(r'<[^>]+>', '', coincidencia.group(2)).strip()
            nombre, link = (texto.split("|") if "|" in texto else (texto, "http://error"))
            # Nueva línea que suma una hora "de corrido"
            nombre = re.sub(r'\b(\d{1,2}):(\d{2})\b', lambda m: f"{(int(m.group(1)) + 1) % 24:02d}:{m.group(2)}", nombre)
            
            #xbmc.log("TEXTO DE LA URL:  " + f'{nombre}', xbmc.LOGINFO)
            #xbmcgui.Dialog().ok("ids_encontrados", f"{nombre}")
            #sys.exit()
            link = link.replace('sportsonlline', 'sportzsonline')
            item_partido = f"""<item>
<title>{nombre.strip()}</title>
<inputstream>$doregex[series]</inputstream>
<regex><name>series</name><expres>$pyFunction:petra.futbol("{link.strip()}")</expres><page></page></regex>
<thumbnail>https://ih1.redbubble.net/image.3307659620.2337/bg,f8f8f8-flat,750x,075,f-pad,750x1000,f8f8f8.u1.jpg</thumbnail><fanart>https://e0.pxfuel.com/wallpapers/306/906/desktop-wallpaper-real-madrid-with-fire.jpg</fanart>
</item>"""
            items_acumulados.append(item_partido)

    # 4. ESCRITURA FINAL
    with open(a, "w", encoding="utf-8") as f:
        f.write(xml_header + "\n".join(items_acumulados) + xml_footer)

    return a
def Buscar_ID_Youtube(titulo):   
    # 1. Preparamos la búsqueda: Título + "trailer castellano"
    # Es vital añadir "trailer" para que no te salgan gameplays o tonterías
    busqueda = titulo + " trailer"
    query = urllib.parse.quote_plus(busqueda)
    url = f"https://m.youtube.com/results?search_query={query}"
    
    # 2. Disfraz de móvil (muy importante para evitar bloqueos)
    headers = {'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1'}
    
    try:
        html = requests.get(url, headers=headers, timeout=10).text
        #xbmc.log("TEXTO DE LA URL:  " + f'{html}', xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("html", f"{html}")
        #sys.exit()
        # 3. El "Anzuelo" (Regex) para pescar el ID de 11 letras
        # Buscamos el primer "watch?v=XXXXXXXXXXX" que aparezca
        regex = r'i\.ytimg\.com[\\/]+vi[\\/]+([a-zA-Z0-9_-]{11})[\\/]+default\.jpg'
        ids_encontrados = re.search(regex, html)
        
        if ids_encontrados[1]:
            # Devolvemos el primero de la lista (el más relevante)
            #xbmc.log("TEXTO DE LA URL:  " + f'{ids_encontrados[1]}', xbmc.LOGINFO)
            #xbmcgui.Dialog().ok("ids_encontrados", f"{ids_encontrados[1]}")
            
            return ids_encontrados[1]
            
    except:
        xbmcgui.Dialog().ok("Error", "Trailer no encontrado")
        pass
     
    return None   

def Youtube_Video(titulo):
    video_id = Buscar_ID_Youtube(titulo)
    # La "Llamada Mágica" al motor de YouTube
    url_youtube = f"plugin://plugin.video.youtube/play/?video_id={video_id}"

    # Le decimos a Kodi: "¡Cállate y reproduce esto!"
    xbmc.executebuiltin(f"PlayMedia({url_youtube})")
    sys.exit()
'''def reproducir (url, titulo):
    imagen = 'https://dl.dropbox.com/scl/fi/swx5fhv5o8qbo1p4dr5zy/gratis-png-emoticon-pulgar-arriba-emoticon-smiley-senal-pulgar-sonrisa-encantadora-removebg-preview.png?rlkey=joitqodpoxed4nw70v8qc9fop&st=uef6el8b&dl=0'
    xbmc.log(f"ANTES DE REPRODUCIRLA: {url}", xbmc.LOGINFO)    

    partes = url.split('|')
    url_limpia = partes[0]
    headers_sueltos = partes[1] if len(partes) > 1 else ""
    
    handle = int(sys.argv[1])
    xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path="http://0.0.0.0"))
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all, true)')     
    
    listitem = xbmcgui.ListItem(path=url_limpia)
    listitem.setLabel(titulo)
    listitem.setArt({'thumb': imagen})
    listitem.setContentLookup(False)

    # -----------------------------------------------------
    # CEREBRO DEL REPRODUCTOR (M3U8 vs MP4)
    # -----------------------------------------------------
    if '.m3u8' in url_limpia:
        # ES HLS: Configuramos InputStream Adaptive
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        listitem.setMimeType("application/vnd.apple.mpegurl")
        
        if headers_sueltos:
            listitem.setProperty('inputstream.adaptive.stream_headers', headers_sueltos)
            
        xbmc.Player().play(item=url_limpia, listitem=listitem)
        
    else:
        # ES MP4 (Krakenfiles): Kodi lo reproduce de forma nativa
        listitem.setMimeType("video/mp4")
        
        # IMPORTANTE: Al reproductor nativo de Kodi se le pasa la URL completa con el | 
        xbmc.Player().play(item=url, listitem=listitem)
    sys.exit() '''

def reproducir(url, titulo):
    #xbmc.log("TEXTO ENCONTRADO: " + url, xbmc.LOGINFO) 
    #xbmcgui.Dialog().ok("Estoy dentro", url) 
    #sys.exit()
    imagen = 'https://dl.dropbox.com/scl/fi/swx5fhv5o8qbo1p4dr5zy/gratis-png-emoticon-pulgar-arriba-emoticon-smiley-senal-pulgar-sonrisa-encantadora-removebg-preview.png?rlkey=joitqodpoxed4nw70v8qc9fop&st=uef6el8b&dl=0'
    xbmc.log(f"ANTES DE REPRODUCIRLA: {url}", xbmc.LOGINFO)    

    partes = url.split('|')
    url_limpia = partes[0]
    headers_sueltos = partes[1] if len(partes) > 1 else ""
    
    handle = int(sys.argv[1])
    
    # 1. Definimos la URL final que va a reproducir el ListItem
    # Si es mp4 usamos la url completa (con el |), si es m3u8 usamos la limpia
    path_reproduccion = url_limpia if '.m3u8' in url_limpia else url
    
    # 2. Creamos el ListItem principal con su ruta real
    listitem = xbmcgui.ListItem(path=path_reproduccion)
    listitem.setLabel(titulo)
    listitem.setArt({'thumb': imagen})
    listitem.setContentLookup(False)

    # 3. Configuramos el ListItem según el tipo (M3U8 vs MP4)
    if '.m3u8' in url_limpia:
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        listitem.setMimeType("application/vnd.apple.mpegurl")
        
        if headers_sueltos:
            listitem.setProperty('inputstream.adaptive.stream_headers', headers_sueltos)
            
    else:
        listitem.setMimeType("video/mp4")
        
    # Opcional: cerramos diálogos de carga si los hubiera
    xbmc.executebuiltin('Dialog.Close(all, true)')     

    # 4. MAGIA: En lugar de usar xbmc.Player().play(), resolvemos la URL de forma nativa.
    # Kodi se encargará de reproducirlo y de cerrar el proceso correctamente al llegar al 100%.
    xbmcplugin.setResolvedUrl(handle, True, listitem)    
def desofuscar(url,respuesta_web, titulo):
    '''# 1. Configuramos las cabeceras básicas
    USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    #xbmc.log("TEXTO ENCONTRADO: " + url, xbmc.LOGINFO) 
    #xbmcgui.Dialog().ok("Estoy dentro", url)

    parsed_url = urlparse(url)
    if 'embed' in url:
        referer = f"{parsed_url.scheme}://{parsed_url.netloc}/"
    else:
        referer = f"{parsed_url.scheme}://{parsed_url.netloc}"  
    
    s = requests.Session()
    s.headers.update({
    'User-Agent': USER_AGENT,
    'Referer': referer})
    
    # PASO 1: Obtener el ID del evento de la web original
    respuesta_web = s.get(url) '''
    
    '''if f_id and aff_id:
        coki = f"file_id={f_id.group(1)}; aff={aff_id.group(1)}; tsn=6"
    else:
        coki = "tsn=6"'''
    # PASO 2: EXTRAER LAS COOKIES (Aquí respondo a tu pregunta)
    # Esto convierte las cookies de la sesión en un diccionario
    
      
    regex = r"text/javascript'>(.*?)</script>"    
    
             
        
    # Añadimos .text a respuesta_web
    match = re.search(regex, respuesta_web, re.DOTALL)
    
    # Comprobamos si encontró algo para evitar errores
    if match:
        texto_encontrado = match.group(1)
        
    else:
        if 'expired or has been deleted.' in respuesta_web:
            xbmcgui.Dialog().ok("Fallo", 'El archivo ya no está disponible porque ha caducado o ha sido eliminado.')
        else:
            xbmc.log("TEXTO DE LA URL:  " + f'{respuesta_web}  {url}', xbmc.LOGINFO)
            xbmcgui.Dialog().ok("Fallo", f"{url} No se encontró el regex, en desofuscar, vete al log")
    if match:   
        #xbmcgui.Dialog().ok("MATCH", "hubo match")     
        match = match.group(1)        
         
        re_1 = r'([^"]*://[^"]*\?[^"]*)'# CAPTURA LO QUE ESTE ENTRE COMILLAS Y QUE CONTENGA :// y ?
        re_p = re.search(re_1, match)
        #xbmc.log(str(re_p), xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("captura regex", str(re_p.group(1)))
        if re_p:
            #re_p = '"' + re_p.group(1) + '"'
            re_p = re_p.group(1)
                            
        re_2 = r"',36[^|]*([^']+)"
        re_k = re.search(re_2, match)
        if re_k:
            re_k = re_k.group(1)
            
        ############################################################################ 
        
        p = re_p
        k = re_k
        a = 36
        
        # Convierte k en una lista de elementos.
        k_list = k.split('|') 
        
        # Patrones para encontrar los índices ofuscados
        pattern = re.compile(r'\b[0-9a-zA-Z]+\b')    
        
        # Función para obtener el reemplazo
        def reemplazo(match):
            # Extrae el índice desde el grupo del match
            index = int(match.group(0), a)
            if index < len(k_list):
                # Obtiene el valor de k_list
                valor_reemplazo = k_list[index]
                # Si el valor de reemplazo no es vacío, lo devuelve; de lo contrario, devuelve el texto original
                return valor_reemplazo if valor_reemplazo != "" else match.group(0)
            # Si el índice está fuera del rango, no realiza reemplazo
            return match.group(0)
        
        # Reemplaza las ocurrencias en el texto p utilizando la función reemplazo
        # Esto devuelve el texto modificado con los reemplazos
        p_modificado = pattern.sub(reemplazo, p)
        ########################################################################################      
        url_sin = p_modificado
        url_sin = url_sin.strip()
        if ".txt" in url_sin:
            xbmc.log(f'DESOFUSCAR el txt essss:  {url_sin}', xbmc.LOGINFO)
            xbmcgui.Dialog().ok("ERROR", 'Desofuscar cambio de .txt a .m3u8')
            sys.exit()
            url_sin = url_sin.replace(".txt", ".m3u8")

        '''# 2. Cookies sin espacios y sin quote total
        # file_id={f_id.group(1)};aff={aff_id.group(1)};tsn=6
        f_id = re.search(r"cookie\('file_id',\s*'(\d+)'", respuesta_web)
        aff_id = re.search(r"cookie\('aff',\s*'(\d+)'", respuesta_web)
        if f_id and aff_id:
            coki_clean = f"file_id={f_id.group(1)}; aff={aff_id.group(1)}"
        else:
            coki_clean = "tsn=6"'''
        

        # 3. Construir los headers para inputstream.adaptive
        # Importante: No uses quote() en toda la cadena, solo en los valores si es necesario
        
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ref = url # O la URL del iframe si falla
        
        # El pipe para el Path (formato estándar de Kodi)
        # Nota: Aquí SÍ se suele usar quote para el UA y Referer
        url_con = f"{url_sin}|User-Agent={ua}&Referer={ref}"             
    
    else:
        xbmcgui.Dialog().ok("sin coincidencia", f"{match}")
        global html_content_errores
        html_content_errores = html_content
     
    reproducir (url_con, titulo)
    sys.exit()
def seriesly (url):
    if '/series/' in url or '/animes/' in url:
        titulo = re.search(r"(?:/series/|/animes/)(.*?)$", url)
        titulo = titulo.group(1).replace('/', ' ').replace('-', ' ')
        #xbmcgui.Dialog().ok("Error", f"{titulo}")
        #sys.exit()
    else:
        titulo = re.search(r"peliculas/(.*?)$", url)
        titulo = titulo.group(1).replace('-', ' ')  
        #xbmcgui.Dialog().ok("Error", f"{titulo}")
        #sys.exit()
    # 1. Configuramos las cabeceras básicas
    USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'

    parsed_url = urlparse(url)
    referer = f"{parsed_url.scheme}://{parsed_url.netloc}/"

    coki = "XSRF-TOKEN=eyJpdiI6Ik5TNWRPTStoN3F1NldnelNRbjRseVE9PSIsInZhbHVlIjoiT0ptc1ZDbHRkSENGeWJ5cytLZ0ZyTWpUS2pOdnBtdkZnc1c5L09IMTlTUjVKeThNTHZnNVdJUjRwbGoydXJkbGlRQ2FBNERaMExhY1JvcVFiSFYyUUgxSWlyWjdIdkpqb2h4S1hoTGYvV2tkbThVWmVkMnFrWW0zUmtpdHhWQ08iLCJtYWMiOiI1NjliYzA5NDU3YWZkNmI4Nzc3ZDViYjJhZjI0MDkzZGNkOWJiM2IzNzZiZjMyZDkyNWQ5YjJhZjZmYTU5NmQ2IiwidGFnIjoiIn0%3D; seriesly_session=eyJpdiI6Ing0NlY2dUFReG9DWVZENGpncFFxdWc9PSIsInZhbHVlIjoiSG52WG1jZURQYWNqTmJreXRPQTdwNnVGNXIzL0RpVHROVEJ2cDZseFhkdld1RStEbjZ6NGNzS2RwdEp2ZFJwVUpvMVlLNmFxek1RY0RKRkRVYmhPK0RTaElhdmJkVVRNdmdud3VyUjZGZlRabkt3OTcwN1hDc1NaVDlVNG5tbnoiLCJtYWMiOiIyODJmZmE4NjJlNTQyZDZjZTk0YTRjNGJkYzRhM2M4NTI4OWJkMDZhZDRlNDIyYThlMTY5ZWZiMDkxNTliNDNlIiwidGFnIjoiIn0%3D; sly_device_id=7d9a2f5b-f2c2-48b8-b9b6-d0b1942e6cec; remember_web_59ba36addc2b2f9401580f014c7f58ea4e30989d=eyJpdiI6ImJVT0ZwL0dUYTE4d3gzcVhrUUpZYVE9PSIsInZhbHVlIjoicEQwaVZwTDV3Rk94em5KaW9nS2NYaktjL2lhZFozMXRPWUloUU9DN1RhdjBZZS8ydmxmZUY3dTNHZDBPSHRLYUVKWWllbXRoeGtGM1lmVnV5MXZXNVI1bWZXeTlJdnlmb1VoL2k3YzNVZEtHaElncDUzUitqNGZBQ01IeXFoWjlUcUpKZ01FU1hWalZQMkp3SDV0Y0lnc1Rhc0Y3TFk2Z013R2xIWTVUWDdkVWJOYjBadkk2a0N1NnVISjM2R2tKaVVvaUVrUkpQWWdEVHRvVjFHZnlzMzBxRXhTUHZZd0VvdytYTzdUMm5QOD0iLCJtYWMiOiI2MGVmNmZkNThiZTY5OGZiMzA4YzA1YThmYjJjMWQyNGQyYmM0NjZmNmQ3NGMwNmM3YzJhOGYzODJkYzYxNTc3IiwidGFnIjoiIn0%3D"
    s = requests.Session()
    s.headers.update({
    'User-Agent': USER_AGENT,
    'Cookie': coki,
    'Referer': referer
    })
    
    
    # PASO 1: Obtener el ID del evento de la web original
    respuesta_web = s.get(url)
    
    #Busca el servidor y la bandera española entonces que capture
    ###match_fid = re.search(r"""(?s)(>STREAMWISH<|>VIDHIDE<|>VIDMOLY<).*?PN9hZZzuVX1Df4H7iRE.png.*?click="playLink\('(.*?)'""", respuesta_web.text)
    # 1. Troceamos la web y sacamos TODAS las filas de la tabla individualmente
    # Esto crea una lista donde cada elemento es el código de un solo servidor
    filas = re.findall(r'(?s)<tr(.*?)</tr>', respuesta_web.text)
    bus_ser = '>STREAMWISH<|>VIDHIDE<|>VIDMOLY<'
    evento_id = None
    servidor_bueno = None
    # 2. Revisamos cada fila una por una (si una falla, pasa a la siguiente)
    for fila in filas:        
        # Condición A: ¿Tiene el servidor que queremos?
        tiene_servidor = re.search(rf'{bus_ser}', fila)        
        # Condición B: ¿Tiene explícitamente la bandera de España?
        tiene_bandera = 'PN9hZZzuVX1Df4H7iRE.png' in fila        
        # Condición C: Si CUMPLE LAS DOS en la misma fila, ¡atrapamos el link!
        if tiene_servidor and tiene_bandera:
            match_link = re.search(r"x-on:click=\"playLink\(\'(.*?)\'", fila)            
            if match_link:
                evento_id = match_link.group(1)                
                respuesta_reproductor = s.get(evento_id)
                codigo_fuente_reproductor = respuesta_reproductor.text 
                match_fid = re.search(r'(?i)src=\\?["\'](.*?)\\?["\']', codigo_fuente_reproductor)
                if not match_fid:
                    handle = int(sys.argv[1])
                    xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path="http://0.0.0.0"))
                    xbmc.sleep(100)
                    xbmc.executebuiltin('Dialog.Close(all, true)')
                    xbmcgui.Dialog().ok("Vete a Seriesly", "Actualiza que eres humano")
                    sys.exit()
                url2 = match_fid.group(1).replace('\\/', '/') 
                if not 'https' in url2: 
                    url2 = f'https:{url2}'
                #xbmc.log(f"{url2}", xbmc.LOGERROR)
                #xbmcgui.Dialog().ok("enlace encontrado", f"{url2}")
                if '.to' in url2:            
                    #masukestin
                    #audinifer
                    video_id = url2.split('/')[-1]
                    url2 = f"https://masukestin.com/e/{video_id}"
                # 1. Configuramos las cabeceras básicas
                parsed_url = urlparse(url2)
                if 'embed' in url2:
                    referer = f"{parsed_url.scheme}://{parsed_url.netloc}/"
                else:
                    referer = f"{parsed_url.scheme}://{parsed_url.netloc}"                 
                s2 = requests.Session()
                s2.headers.update({
                'User-Agent': USER_AGENT,
                'Referer': referer})                
                # PASO 1: Obtener el ID del evento de la web original
                respuesta_web = s2.get(url2) 
                respuesta_web_text = respuesta_web.text                
                if 'it expired or has been deleted' in respuesta_web_text or 'This video not found' in respuesta_web_text:
                    fallo = 1
                    continue
                else: 
                    fallo = 0            
                    break  # Detiene el bucle porque ya tenemos el enlace bueno
                    
    # 3. Comprobamos si al terminar el bucle conseguimos algo
    if not evento_id or fallo == 1:        
        xbmcgui.Dialog().ok("Fallo", "No hay enlaces en Español de los servidores preferidos.")
        handle = int(sys.argv[1])
        xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path="http://0.0.0.0"))
        xbmc.sleep(100)
        xbmc.executebuiltin('Dialog.Close(all, true)')
        sys.exit() 

    if match_fid:        
        url_origi = match_fid.group(1).replace('\\/', '/')
        video_id = url_origi.split('/')[-1]
        xbmc.log("URL A TRABAJARLA ESSSS:  " + f'{url_origi}', xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("te espera", f'{url_origi}')
        if not 'https' in url_origi:
            url_vidmoly = f'https:{url_origi}'#.replace('.net', '.biz')
            
            parsed_url = urlparse(url2)            
            ref = f"{parsed_url.scheme}://{parsed_url.netloc}/" 
            
            
            '''s = requests.Session()
            s.headers.update({
            'User-Agent': USER_AGENT,
            'Referer': ref})'''
            #xbmcgui.Dialog().ok('LOG', f'{url_vidmoly}')
            #xbmcgui.Dialog().ok("te espera", f'{url_vidmoly}')
            # PASO 1: Obtener el ID del evento de la web original
            respuesta_web = s.get(url_vidmoly) 
            url_sin = re.search(r"(?s)player.setup.*?file:\s*['\"](.*?)['\"]", respuesta_web.text)
            if url_sin:
                url_sin = url_sin.group(1)
            else:
                handle = int(sys.argv[1])
                xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path="http://0.0.0.0"))
                xbmc.sleep(100)
                xbmc.executebuiltin('Dialog.Close(all, true)')                
                xbmcgui.Dialog().ok("ERROR", "No encontro nada en vidmoly") 
                sys.exit()   
            url_con = f"{url_sin}|User-Agent={USER_AGENT}&Referer={ref}"
            xbmcgui.Dialog().ok("Url final", f'{url_con}')
            reproducir(url_con, titulo)
            sys.exit()
            
        xbmc.log(f"url = {url2} + respuesta_web_text = {respuesta_web_text} +  titulo = {titulo}", xbmc.LOGERROR)
        #xbmcgui.Dialog().ok("enlace encontrado", f"{url2}")    
        if '/embed/' in url_origi:
            desofuscar(url2, respuesta_web_text, titulo)
            
        if '.to' in url_origi:            
            #masukestin
            #audinifer
            #url_origi = f"https://masukestin.com/e/{video_id}"
            desofuscar(url2, respuesta_web_text, titulo)
        '''if 'krakenfiles' in url_origi:
            parsed_url = urlparse(url_origi)            
            ref = f"{parsed_url.scheme}://{parsed_url.netloc}/"            
            
            s = requests.Session()
            s.headers.update({
            'User-Agent': USER_AGENT,
            'Referer': ref})
            
            # PASO 1: Obtener el ID del evento de la web original
            respuesta_web = s.get(url_origi) 
            # 1. El regex súper fácil para capturar lo que hay dentro de src="..."
            regex_kraken = r'<source[^>]+src="([^"]+)"'
            match = re.search(regex_kraken, respuesta_web.text)
            if match:
                # 2. Sacamos el enlace en bruto (el del token larguísimo)
                url_sin = match.group(1)
                url_con = f"{url_sin}|User-Agent={urllib.parse.quote(USER_AGENT)}&Referer={ref}"
                #xbmc.log(f"Y EL ENLACE ESSSSS::::  {url_con}", xbmc.LOGERROR)
                #xbmcgui.Dialog().ok("LOG", "TENGO EL ENLACE")                
                reproducir(url_con, titulo)
                sys.exit()'''


        # Intentamos importar la librería de desencriptación para Kodi
        try:
            from Cryptodome.Cipher import AES
        except ImportError:
            try:
                from Crypto.Cipher import AES
            except ImportError:
                AES = None

        def reparar_base64(data):
            """ Función para arreglar el padding del Base64 (Imita a la función Mr del JS) """
            if not data: return b""
            # Reemplazamos caracteres URL-safe por estándar
            data = data.replace('-', '+').replace('_', '/')
            # Añadimos los '=' faltantes al final
            faltante = len(data) % 4
            if faltante:
                data += '=' * (4 - faltante)
            return base64.b64decode(data)

        if 'byse' in url_origi:           
            #bysejikuar
            session = requests.Session()
            
            '''# 1. Cabeceras EXACTAS del F12
            # He quitado las que Python añade automáticamente y dejado las que pide el servidor
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0',
                'Accept': 'application/json', # En el F12 ponía */* pero al ser API suele ser json
                'Accept-Language': 'es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7',
                'Content-Type': 'application/json',
                'Origin': 'https://rupertisdivingintoocean.com',
                'Referer': f'https://rupertisdivingintoocean.com/10g/{video_id}',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'X-Requested-With': 'XMLHttpRequest'
            }
            session.headers.update(headers)

            # 2. Primero vamos a la URL del video para que Cloudflare nos deje pasar y nos dé cookies
            url_puente = f'https://rupertisdivingintoocean.com/10g/{video_id}'
            session.get(url_puente)
            
            v_id = session.cookies.get("byse_viewer_id", "")
            d_id = session.cookies.get("byse_device_id", "")
            
            if not v_id:
                xbmc.log("PETRA: No se han obtenido cookies. Reintentando...", xbmc.LOGWARNING)
                # Reintento agresivo
                session.get("https://rupertisdivingintoocean.com/")
                session.get(url_puente)
                v_id = session.cookies.get("byse_viewer_id", "")
                d_id = session.cookies.get("byse_device_id", "")

            token_dinamico = ""
            
            # 3. LLAMADA DE ATESTACIÓN (Payload corregido según JS)
            try:
                attest_url = "https://rupertisdivingintoocean.com/api/videos/access/attest"
                
                # OJO: He cambiado gpu_vendor por gpuVendor, etc. para que sea igual al JS
                attest_payload = {
                    "embed": True,
                    "adBlock": False,
                    "premium": False,
                    "download": False,
                    "width": 1920,
                    "height": 1080,
                    "device": "Windows/Windows 10",
                    "browser": "Firefox 150.0", # He puesto el mismo que el User-Agent
                    "gpuVendor": "Google Inc. (NVIDIA)",
                    "gpuRenderer": "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11)",
                    "cpuCores": 12,
                    "cursorX": 0,
                    "cursorY": 0
                }
                
                r_attest = session.post(attest_url, json=attest_payload)
                
                xbmc.log(f"PETRA: Respuesta Attest -> Status: {r_attest.status_code}", xbmc.LOGINFO)

                if r_attest.status_code == 200:
                    token_dinamico = r_attest.json().get("token", "")
                    if token_dinamico:
                        xbmcgui.Dialog().notification("PETRA", "Token dinámico OK", xbmcgui.NOTIFICATION_INFO, 2000)
                else:
                    xbmc.log(f"PETRA: El servidor rechazó la atestación. Respuesta: {r_attest.text}", xbmc.LOGERROR)

            except Exception as e:
                xbmc.log(f"PETRA: Error de red en /attest: {str(e)}", xbmc.LOGERROR)

            # 4. Si el dinámico falló, tiramos del fijo (pero este caduca rápido)
            if not token_dinamico:
            token = "eyJ2aWV3ZXJfaWQiOiI4NWUwOWFjYzUxOWY0MTU3OWNhNzljMzQxYjAzN2M4ZCIsImRldmljZV9pZCI6IkN3YURHU3Nvb3Fzb2lGNUs4bHVyUHciLCJjb25maWRlbmNlIjowLjkxLCJpYXQiOjE3NzkzNTQxNTMsImV4cCI6MTc3OTM1NDc1M30.GGXd1nNcmHX9Z72pASqiN8R6pjVEuXA-jzy_wv0m7hg"'''

            # 2. API de Playback
            api_url = f"https://rupertisdivingintoocean.com/api/videos/{video_id}/embed/playback"
            
            api_headers = {
                "User-Agent": USER_AGENT,
                "Referer": f"https://rupertisdivingintoocean.com/hbe/{video_id}",
                "Origin": "https://rupertisdivingintoocean.com",
                "X-Embed-Parent": f"https://bysejikuar.com/e/{video_id}",
                "Content-Type": "application/json",
                "Accept": "*/*"
            }

            # 3. Fingerprint (Nota: El token es sensible, si falla el POST mira este campo)
            v_id = session.cookies.get("byse_viewer_id", "")
            d_id = session.cookies.get("byse_device_id", "")

            payload = {
                "fingerprint": {
                    "confidence": 0.91,
                    "device_id": d_id,
                    "viewer_id": v_id                    
                }
            }

            # 4. POST a la API
            r = session.post(api_url, headers=api_headers, json=payload)
            
            try:
                data = r.json()
                playback = data.get('playback', {})
                
                   
                # Usamos una f-string (la 'f' delante) para evitar errores si el texto es un número o None
                xbmc.log(f"TEXTO ENCONTRADO: {playback}", xbmc.LOGINFO)          
                # Pasamos la variable al diálogo
                xbmcgui.Dialog().ok("Estoy dentro", str(playback))
                
                if 'hls' in playback:
                    url_m3u8 = playback['hls']
                    url_final = f"{url_m3u8}|User-Agent={USER_AGENT}&Referer=https://rupertisdivingintoocean.com/"
                    xbmc.log("PETRA: ÉXITO - HLS", xbmc.LOGINFO)
                    reproducir(url_final, titulo)
                    sys.exit()

                elif 'payload' in playback:
                    if AES is None:
                        xbmcgui.Dialog().ok("ERROR", "Falta PyCryptodome. Añádelo al addon.xml")
                    else:
                        # --- DESENCRIPTACIÓN CON BASE64 CORREGIDO ---
                        key_parts = playback.get('key_parts', [])
                        iv_b64 = playback.get('iv', '')
                        enc_payload_b64 = playback.get('payload', '')

                        # Unimos las partes de la llave usando nuestra función de limpieza
                        llave_maestra = b"".join([reparar_base64(part) for part in key_parts])
                        
                        # Decodificamos el IV y el Payload con limpieza
                        iv = reparar_base64(iv_b64)
                        datos_completos = reparar_base64(enc_payload_b64)

                        # AES-GCM: Los últimos 16 bytes son el TAG
                        ciphertext = datos_completos[:-16]
                        tag = datos_completos[-16:]

                        # Descifrado
                        cipher = AES.new(llave_maestra, AES.MODE_GCM, nonce=iv)
                        decrypted_bytes = cipher.decrypt_and_verify(ciphertext, tag)
                        
                        video_config = json.loads(decrypted_bytes.decode('utf-8'))
                        
                        if 'sources' in video_config and len(video_config['sources']) > 0:
                            url_m3u8 = video_config['sources'][0]['url']
                            url_final = f"{url_m3u8}|User-Agent={USER_AGENT}&Referer=https://rupertisdivingintoocean.com/"
                            xbmc.log("PETRA: ÉXITO - VIDEO DESCIFRADO", xbmc.LOGINFO)
                            reproducir(url_final, titulo)
                            sys.exit()
                        else:
                            xbmcgui.Dialog().ok("ERROR", "No hay fuentes en el video descifrado.")

            except Exception as e:
                xbmc.log(f"ERROR PETRA: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().ok("ERROR FINAL", f"Error en descifrado: {str(e)}")



    else:
        xbmcgui.Dialog().ok("ERROR", 'Desbloquea Seriesly')
        sys.exit()   
    #sys.exit()
    
    
def ufc(url):
    # 1. Configuramos las cabeceras básicas
    USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0'

    s = requests.Session()
    s.headers.update({
    'User-Agent': USER_AGENT})

    
    # PASO 1: Obtener el ID del evento de la web original
    respuesta_web = s.get(url)

    # Buscamos fid="mevent1" (o el evento que sea)
    match_fid = re.search(r'fid="([^"]+)"', respuesta_web.text)
    if not match_fid:
        xbmcgui.Dialog().ok("Error", "Error: No se encontró el ID del evento")

    evento_id = match_fid.group(1) # "mevent1"

    # PASO 2: Construir la URL mágica que acabas de descubrir
    url_reproductor = f"https://executeandship.com/premiumcr.php?player=mobile&live={evento_id}"
    
    # TRUCO ANTIBLOQUEO: Simulamos descargar el .js para que el servidor nos dé las Cookies
    #s.get("https://executeandship.com/premium.js", headers={'Referer': url})

    # Creamos cabeceras fuertes simulando ser un reproductor anidado (iframe)
    cabeceras_iframe = {'Referer': url}
    #xbmc.log("TEXTO DE LA URL:  " + f'{cabeceras_iframe}', xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("te esprera", "vete al log")
    # PASO 3: Descargamos el código fuente de ese reproductor oculto
    respuesta_reproductor = s.get(url_reproductor, headers=cabeceras_iframe)
    codigo_fuente_reproductor = respuesta_reproductor.text
    
        
    
    # PASO 4: Extraemos el array de letras ocultas y lo reconstruimos
    match_array = re.search(r'return\(\[(.*?)\]\.join', codigo_fuente_reproductor)

    if not match_array:
        xbmcgui.Dialog().ok("Error", "Error: No se encontró el m3u8 ofuscado") 
        

    # Cogemos las letras: "h","t","t","p","s"... y las limpiamos
    letras = match_array.group(1)
    enlace_puro = letras.replace('"', '').replace(',', '').replace('\\/', '/')
    #

    # PASO 5: Montamos el enlace final para KODI con las cabeceras necesarias
    cabeceras_kodi = {
        'Referer': 'https://executeandship.com/',
        'Origin': 'https://executeandship.com',
        'User-Agent': USER_AGENT
    }

    cabeceras_codificadas = urllib.parse.urlencode(cabeceras_kodi)

    # ¡URL FINAL PARA REPRODUCIR!
    url_final = f"{enlace_puro}|{cabeceras_codificadas}"    
    
    # 2. TRUCO MAESTRO: Liberamos el Addon (0.0.0.0)
    handle = int(sys.argv[1])
    xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path="http://0.0.0.0"))
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all, true)')    
    # 3. LANZAMIENTO DIRECTO (Mandos a la derecha y audio OK)
    xbmc.Player().play(url_final)
    #xbmc.executebuiltin(f'PlayMedia("{url_final}")')
def directo_al_partido(url): 
    xbmc.executebuiltin(f'PlayMedia("{url}")')
    xbmc.sleep(3000)
    sys.exit()
def futbol(url_madre):
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0"
    titulo = ''
    # 1. Creamos sesión de búsqueda
    session = requests.Session()
    session.headers.update({"User-Agent": ua})

    try:
        # PASO A: Entrar en la web de deportes y buscar el iframe
        html_madre = session.get(url_madre, timeout=10).text
        iframe_url = re.findall(r'iframe src=["\'](.*?)["\']', html_madre)[0]
        
        # PASO B: Entrar al iframe de dynamicsnake usando el Referer correcto
        headers_iframe = {"Referer": url_madre}
        html_iframe = session.get(iframe_url, headers=headers_iframe, timeout=10).text
        xbmc.log("TEXTO DE LA URL:  " + f'{html_iframe}', xbmc.LOGINFO)
        xbmcgui.Dialog().ok("Valor de Alldebrid API", f'{iframe_url}')
        # PASO C: Pescar la URL final con el s= y el e=
        url_clean = re.findall(r'var src = "(.*?)"', html_iframe)[0]
        
        
        # ---------------------------------------------------------
        # PASO D: PREPARAR EL LANZAMIENTO (EL ADN QUE ENCONTRASTE)
        # ---------------------------------------------------------
        # Extraemos la hora para el nombre
        ###timestamp = int(url_clean.split('e=')[-1].split('&')[0])
        ###hora_corte = datetime.datetime.fromtimestamp(timestamp).strftime('%H:%M')
        
        # Construimos las "mentiras" para Kodi (usando tu JSON)
        # Usamos el dominio del iframe como Referer para el video
        dom_iframe = "/".join(iframe_url.split('/')[:3]) + "/"
        headers_kodi = f"User-Agent={ua}&Referer={dom_iframe}&Origin={dom_iframe.rstrip('/')}&Accept=*/*&Accept-Language=es-ES,es;q=0.9"
        
        
        url_final = f"{url_clean}|{headers_kodi}"
        return url_final
        sys.exit()

        # 2. TRUCO MAESTRO: Liberamos el Addon (0.0.0.0)
        handle = int(sys.argv[1])
        xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path="http://0.0.0.0"))
        xbmc.sleep(100)
        xbmc.executebuiltin('Dialog.Close(all, true)')
        
        
        # 3. LANZAMIENTO DIRECTO (Mandos a la derecha y audio OK)
        xbmc.executebuiltin(f'PlayMedia("{url_final}")')
        
        # Notificación final de éxito
        ###xbmc.executebuiltin(f'Notification(PETRA OK, Visionado hasta las {hora_corte}, 5000)')

    except Exception as e:
        # Capturamos el error detallado del sistema
        error_detallado = traceback.format_exc()
        xbmc.log("PETRA ERROR COMPLETO:\n" + error_detallado, xbmc.LOGERROR)
        
        # Mostramos la causa exacta en la pantalla de Kodi
        xbmcgui.Dialog().ok("Petra Error", f"Causa del fallo:\n{str(e)}")

    
def practica_futbol(canal, url_clean):
    # 1. Definimos las credenciales básicas
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0"
    
    # IMPORTANTE: Para 'requests', los headers DEBEN ser un diccionario {}
    headers_busqueda = {
        "User-Agent": ua,
        "Accept": "*/*",
        "Accept-Language": "es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7",
        "Connection": "keep-alive"
    }

    try:
        # PASO A: Entrar en la web del canal (Sportzsonline)
        # Usamos GET porque normalmente estas webs no esperan un POST aquí
        response = requests.get(canal, headers=headers_busqueda, timeout=10)
        html_content = response.text 
        
        # Buscamos el iframe
        regex_iframe = r'iframe src=["\'](.*?)["\']'
        match_iframe = re.search(regex_iframe, html_content)
        
        if not match_iframe:
            xbmcgui.Dialog().ok("Error", "No se encontró el iframe en la web madre")
            return
            
        iframe_url = match_iframe.group(1)
        
        # PASO B: Entrar en el iframe (Dynamicsnake)
        # IMPORTANTE: Para que el iframe no nos bloquee, el Referer debe ser la web madre
        headers_busqueda["Referer"] = canal 
        
        r_iframe = requests.get(iframe_url, headers=headers_busqueda, timeout=10)
        html_b = r_iframe.text

        # PASO C: Buscar la variable 'var src = "..."'
        regex_src = r'var src = "(.*?)"'
        match_src = re.search(regex_src, html_b)

        if match_src:
            url_deco = match_src.group(1)
            # Si lo hemos encontrado, lo mostramos
            #xbmcgui.Dialog().ok("¡Logrado!", f"URL encontrada:\n{url_deco}")
            
            # Aquí es donde luego llamarías a tu función de reproducción
            # enviando url_deco al PlayMedia...
            
        else:            
            xbmcgui.Dialog().ok("Error", "No se encontró 'var src' dentro del iframe")

    except Exception as e:
        xbmcgui.Dialog().ok("Error Crítico", str(e))

    sys.exit()
    
    
    #xbmc.log("TEXTO DE LA URL:  " + f'{html_content}', xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("Valor de Alldebrid API", f'{iframe}')
    
    # ---------------------------------------------------------
    # BLOQUE NUEVO: CALCULAR LA HORA
    # ---------------------------------------------------------
    try:
        # Extraemos el número e= (ej: 1710800000)
        timestamp_expira = int(url_clean.split('e=')[-1].split('&')[0])
        # Tiempo actual en segundos (Universal)
        ahora = int(time.time())        
        minutos_faltantes = (timestamp_expira - ahora) // 60
        
        # Esto detecta automáticamente dónde está tu icono
        addon = xbmcaddon.Addon()
        icon_path = addon.getAddonInfo('icon') 

        if minutos_faltantes > 0:            
            aviso = f"{minutos_faltantes}"
            # Comando limpio
            xbmc.executebuiltin(f'Notification(INFO:, Credito de {aviso} Min, 7000, {icon_path})')
            
        else:
            item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)    
            xbmc.sleep(100)
            xbmc.executebuiltin('Dialog.Close(all)')
            aviso = "¡ Enlace frito !"
            xbmc.sleep(100)
            xbmc.executebuiltin(f'Notification(INFO:, {aviso}, 7000, {icon_path})')
            sys.exit()
    except Exception as e:
        aviso = "Error: URL sin parámetro de tiempo"
        minutos_faltantes = -1
    # CORRECCIÓN DE LA NOTIFICACIÓN: El 5000 va DENTRO del paréntesis
    
    # ---------------------------------------------------------
    # TU CÓDIGO QUE YA FUNCIONA (SIN CAMBIOS)
    # ---------------------------------------------------------
    
    ref = f'{iframe}'           
    org = f'{iframe}'
           
    headers = f"User-Agent={ua}&Referer={ref}&Origin={org}"
    
    url_montada = f"{url_clean}&visionado={int(time.time())}|{headers}"

    # Primero: Liberamos el addon
    handle = int(sys.argv[1])
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(handle, True, item_silencioso)    
    
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all, true)')
    xbmc.sleep(100)     
    
    # Segundo: Lanzamos el video
    comando = f'PlayMedia("{url_montada}")'
    xbmc.executebuiltin(comando)
     
    
def cancelar_totalmente():
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)    
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
    sys.exit()
    #xbmc.sleep(100) # Pequeña pausa para dejar que Kodi procese el setResolved
    #xbmc.executebuiltin('Dialog.Close(okdialog)') 
    
def Limpiar_BD():    
    
    # Reproducción del dummy de audio para evitar cuelgues
    mp3 = "special://home/addons/plugin.video.play/resources/lib/Peter.mp3"
    xbmc.executebuiltin(f'PlayMedia({mp3})')
    xbmc.sleep(1000)
    
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)    
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
    xbmc.sleep(300)
    
    
    # ----------------------------------------------------
    # Paso 1: Limpiar LOS .ZIP (Packages)
    # ----------------------------------------------------
    packages = 0
    addon_data = xbmcvfs.translatePath("special://home/addons/packages/").replace('\\', '/')
    if xbmcvfs.exists(addon_data):
        # Evitamos IndexError verificando que listdir devuelva contenido
        directorios, archivos = xbmcvfs.listdir(addon_data)
        for f in archivos:        
            path = os.path.join(addon_data, f).replace('\\', '/')
            if xbmcvfs.exists(path): 
                packages += 1
                xbmcvfs.delete(path)
    if packages > 0:
        xbmc.log(f"[plugin.video.play] 1_Packages Vaciados", xbmc.LOGINFO)
    
    # ----------------------------------------------------
    # Paso 2: BORRAR ARCHIVOS DE LA CARPETA THUMBNAILS
    # ----------------------------------------------------
    Thumbnails = 0
    thumbnails_path = xbmcvfs.translatePath("special://userdata/Thumbnails/").replace('\\', '/')    
    if xbmcvfs.exists(thumbnails_path):
        for raiz, directorios, archivos in os.walk(thumbnails_path):
            for archivo in archivos:
                ruta_archivo = os.path.join(raiz, archivo).replace('\\', '/')
                try:
                    if xbmcvfs.exists(ruta_archivo):
                        xbmcvfs.delete(ruta_archivo)
                        Thumbnails += 1                        
                except Exception as e:
                    xbmc.log(f"[plugin.video.play] No se pudo borrar el archivo de miniatura {archivo}: {str(e)}", xbmc.LOGERROR)  
    if Thumbnails > 0:
        xbmc.log(f"[plugin.video.play] 2_Thumbnails Vaciados", xbmc.LOGINFO)                
    # ----------------------------------------------------
    # Paso 3: LIMPIAR CACHÉ DEL ADDON (temp/)
    # ----------------------------------------------------
    borrador = 0
    cache_addon = xbmcvfs.translatePath("special://home/addons/temp/")    
    if xbmcvfs.exists(cache_addon):
        for raiz, directorios, archivos in os.walk(cache_addon, topdown=False):
            for archivo in archivos:
                ruta_archivo = os.path.join(raiz, archivo).replace('\\', '/')
                try:
                    if xbmcvfs.exists(ruta_archivo):
                        borrador += 1
                        xbmcvfs.delete(ruta_archivo)
                        
                except Exception as e:
                    xbmc.log(f"[plugin.video.play] No se pudo borrar el archivo de caché {archivo}: {str(e)}", xbmc.LOGERROR)
            
            raiz_norm = raiz.replace('\\', '/').rstrip('/')
            cache_norm = cache_addon.replace('\\', '/').rstrip('/')
            
            if raiz_norm != cache_norm:
                ruta_carpeta = raiz_norm + '/'
                try:
                    if xbmcvfs.exists(ruta_carpeta):
                        borrador += 1
                        xbmcvfs.rmdir(ruta_carpeta)
                        
                except Exception as e:
                    xbmc.log(f"[plugin.video.play] No se pudo borrar la carpeta de caché {ruta_carpeta}: {str(e)}", xbmc.LOGERROR)
    if borrador > 0:
        xbmc.log(f"[plugin.video.play] 3_addons/temp/ Vaciado", xbmc.LOGINFO)             
    
    # ----------------------------------------------------
    # Paso 4: PRO-MANTENIMIENTO DE BASES DE DATOS (.DB)
    # ----------------------------------------------------
    
    database_path = xbmcvfs.translatePath("special://userdata/Database/").replace('\\', '/')
    if xbmcvfs.exists(database_path):
        for archivo in os.listdir(database_path):
            if archivo.endswith(".db") and not archivo.startswith("Textures") and not archivo.startswith("ViewModes"):
                ruta_db = os.path.join(database_path, archivo).replace('\\', '/')
                try:
                    conexion = sqlite3.connect(ruta_db)
                    conexion.isolation_level = None
                    cursor = conexion.cursor()
                    cursor.execute("REINDEX")
                    cursor.execute("VACUUM")
                    cursor.execute("ANALYZE")
                    conexion.close()
                    xbmc.log(f"[plugin.video.play] 4_Optimizado: {archivo}", xbmc.LOGINFO)
                except Exception as e:
                    # Guardamos el fallo en el log de forma silenciosa para no molestar con popups recurrentes
                    xbmc.log(f"[plugin.video.play] No se pudo optimizar la DB {archivo} (en uso o bloqueada): {str(e)}", xbmc.LOGWARNING)

            elif archivo.startswith("Textures") and archivo.endswith(".db"):
                ruta_db = os.path.join(database_path, archivo).replace('\\', '/')
                try:
                    conexion = sqlite3.connect(ruta_db)
                    cursor = conexion.cursor()
                    cursor.execute("DELETE FROM texture")
                    cursor.execute("DELETE FROM path")
                    try:
                        cursor.execute("DELETE FROM sizes")
                    except:
                        pass
                    conexion.commit()
                    
                    conexion.isolation_level = None
                    cursor.execute("REINDEX")
                    cursor.execute("VACUUM")
                    cursor.execute("ANALYZE")
                    conexion.close()
                    xbmc.log(f"[plugin.video.play] 4_Vaciado y compactado: {archivo}", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[plugin.video.play] Error al vaciar la DB de texturas por SQL: {str(e)}", xbmc.LOGERROR)  
                    
            elif archivo.startswith("ViewModes") and archivo.endswith(".db"):
                ruta_db = os.path.join(database_path, archivo).replace('\\', '/')
                try:
                    conexion = sqlite3.connect(ruta_db)
                    cursor = conexion.cursor()
                    
                    # 1. Extraemos todos los registros de vistas guardados
                    cursor.execute("SELECT idView, path FROM view")
                    filas = cursor.fetchall()
                    
                    ids_a_borrar = []
                    for id_view, path in filas:
                        if path and path.startswith('plugin://'):
                            # Extraemos el addon_id (ej: de 'plugin://plugin.video.thecrew/...' sacamos 'plugin.video.thecrew')
                            partes = path[9:].split('/')
                            if partes:
                                addon_id = partes[0]
                                # Comprobamos si la carpeta física del addon existe en el almacenamiento
                                ruta_addon = xbmcvfs.translatePath(f"special://home/addons/{addon_id}").replace('\\', '/')
                                ruta_addon_sys = xbmcvfs.translatePath(f"special://xbmc/addons/{addon_id}").replace('\\', '/')
                                if not xbmcvfs.exists(ruta_addon) and not xbmcvfs.exists(ruta_addon_sys):
                                    ids_a_borrar.append(id_view)
                                    
                    # 2. Borramos los registros obsoletos en bloque (lote) para mayor rapidez
                    if ids_a_borrar:
                        cursor.execute(f"DELETE FROM view WHERE idView IN ({','.join(map(str, ids_a_borrar))})")
                        conexion.commit()
                        xbmc.log(f"[plugin.video.play] 4b_ViewModes: Limpiados {len(ids_a_borrar)} registros obsoletos en {archivo}", xbmc.LOGINFO)
                    
                    # 3. Compactamos y optimizamos la base de datos
                    conexion.isolation_level = None
                    cursor.execute("REINDEX")
                    cursor.execute("VACUUM")
                    cursor.execute("ANALYZE")
                    conexion.close()                    
                    xbmc.log(f"[plugin.video.play] 4b_Vaciado y compactado: {archivo}", xbmc.LOGINFO)                    
                except Exception as e:
                    xbmc.log(f"[plugin.video.play] Error al limpiar y optimizar ViewModes {archivo}: {str(e)}", xbmc.LOGERROR)

    # ----------------------------------------------------
    # Paso 5: LIMPIAR ARCHIVOS TEMPORALES (special://temp/)
    # ----------------------------------------------------
    Borra_temp = 0
    temp_path = xbmcvfs.translatePath("special://temp/").replace('\\', '/')
    if xbmcvfs.exists(temp_path):
        # Usamos xbmcvfs.listdir para asegurar compatibilidad en Android
        directorios_temp, archivos_temp = xbmcvfs.listdir(temp_path)
        for archivo in archivos_temp:
            # Protegemos el log activo de Kodi de intentos inútiles de borrado que ensucian el log
            if archivo.lower() in ["kodi.log"]:
                continue
            
            ruta_temp = os.path.join(temp_path, archivo).replace('\\', '/')
            try:
                if xbmcvfs.exists(ruta_temp):                    
                    xbmcvfs.delete(ruta_temp)
                    Borra_temp += 1                    
            except:
                pass
    if Borra_temp > 0:
        xbmc.log(f"[plugin.video.play] 5_Temp's Vaciados", xbmc.LOGINFO)      
    # ----------------------------------------------------
    # Paso 6: Limpiar LIBRERIA DE VIDEOS
    # ----------------------------------------------------
    
    xbmc.executebuiltin("CleanLibrary(video, false)")    
    # Finalizamos y cerramos los diálogos de Kodi
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    xbmc.executebuiltin('Dialog.Close(12002)')
    xbmc.log(f"[plugin.video.play] 6_Libreria de videos Limpiada", xbmc.LOGINFO)
    
    # Borrado físico opcional de la caché de Palantir 3 para regeneración limpia
    palantir_db = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/cache.db").replace('\\', '/')
    if xbmcvfs.exists(palantir_db):
        xbmcvfs.delete(palantir_db)
        xbmc.log("[plugin.video.play] 7_Caché de Palantir 3 eliminada físicamente para regeneración limpia.", xbmc.LOGINFO)
        
    # ----------------------------------------------------
    # Paso 3.5: LIMPIAR ARCHIVOS DE LA CARPETA CACHÉ DE RESOLVEURL
    # ----------------------------------------------------
    borrados_resolve = 0
    resolveurl_cache_dir = xbmcvfs.translatePath("special://profile/addon_data/script.module.resolveurl/cache/").replace('\\', '/')
    
    if xbmcvfs.exists(resolveurl_cache_dir):
        # Listamos los archivos dentro de la carpeta de caché de ResolveURL
        directorios_res, archivos_res = xbmcvfs.listdir(resolveurl_cache_dir)
        
        for archivo in archivos_res:
            ruta_archivo = os.path.join(resolveurl_cache_dir, archivo).replace('\\', '/')
            try:
                if xbmcvfs.exists(ruta_archivo):
                    xbmcvfs.delete(ruta_archivo)
                    borrados_resolve += 1
            except Exception as e:
                xbmc.log(f"[plugin.video.play] No se pudo borrar archivo de caché ResolveURL {archivo}: {str(e)}", xbmc.LOGERROR)
                
    if borrados_resolve > 0:
        xbmc.log(f"[plugin.video.play] 8_Archivos de caché ResolveURL vaciados: {borrados_resolve}", xbmc.LOGINFO)  
    
    pbg = xbmcgui.DialogProgress()
    pbg.create("Atención: Mantenimiento", "[COLOR orangered][B]Iniciando limpieza. \n         [COLOR gold]   Kodi a partir de ahora, \n                        [COLOR orangered]  será más rápido que un Cohete...[/B][/COLOR][/COLOR][/COLOR]")
    for i in range(100):
        pbg.update(i, "[COLOR orangered][B]Iniciando limpieza. \n         [COLOR gold]   Kodi a partir de ahora, \n                        [COLOR orangered]  será más rápido que un Cohete...[/B][/COLOR][/COLOR][/COLOR]")
        xbmc.sleep(70)  # Puedes bajar este número (ej: 30) para ir más rápido, o subirlo (ej: 80) para ir más despacio
    pbg.update(100, "¡Mantenimiento completado! \n\n                              Kodi se cerrará automáticamente")   
    xbmc.sleep(2000)    
    pbg.close() 
    xbmc.sleep(60)
    # Forzar el cierre inmediato y seguro
    os._exit(1)
    #xbmc.executebuiltin('Dialog.Close(all)')
    #sys.exit()  
def saber_numero_carpeta(sindatos):
    #prueba = 13782380
    #series = 17082018
    url = "https://1fichier.com/console/get_folder_content.pl?id=17082018"
    ##########  no funciona por que tienes que iniciar sesion pero para pedir el id de la carpeta abre navegador inicia sesion y clik a esa url es de la id de series ###########
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    
    response = requests.post(url, headers=headers)
    html_content = response.text 
    

def get_alldebrid_apikey_regex():
    # --- CONFIGURACIÓN ---
    ADDON_ID = 'plugin.video.palantir3' 
    # ---------------------    
    try:
        # Creamos la conexión con el addon Palantir 3
        addon = xbmcaddon.Addon(ADDON_ID)
        
        # --- 1. OBTENCIÓN DE LA API KEY ---
        # Leemos el valor del ajuste 'Alldebrid_apikey'
        api_key = addon.getSetting('Alldebrid_apikey')
        
        # Mostramos un mensaje en pantalla con el valor obtenido
        #xbmcgui.Dialog().ok("Valor de Alldebrid API", f'{api_key}')
        return api_key
    
    except Exception as e:
        # Si el addon no está instalado o hay error, no hace nada
        pass
    
        
def urlsolve(url):
    if url == "v":
        #xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
        handle = int(sys.argv[1])
        xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path="http://0.0.0.0"))
        xbmc.sleep(100)
        xbmc.executebuiltin('Dialog.Close(all, true)')
        sys.exit()

    # 1. Preparación de la URL de origen
    original_url = f"https://1fichier.com/?{url}"
    
    # 2. Obtener la API Key (Asegúrate de que esta función sea rápida)
    apikey = get_alldebrid_apikey_regex()
    
    # 3. Configuración de la petición mediante diccionario de parámetros
    api_endpoint = "https://api.alldebrid.com/v4/link/unlock"
    payload = {
        'agent': 'Palantir3',
        'apikey': apikey,
        'link': original_url
    }
    
    try:
        # Realizamos la petición (requests gestiona los headers y el encoding)
        response = requests.get(api_endpoint, params=payload, timeout=20)
        response.raise_for_status() # Lanza error si la web no responde (404, 500, etc)
        
        # 4. Parseo directo de JSON (Mucho más rápido que regex)
        data = response.json()
        
        if data.get('status') == 'success':
            # Extraemos el link directo
            return data['data']['link']
        else:
            # Si Alldebrid devuelve un error (ej: apikey inválida o link caído)
            error_msg = data.get('error', {}).get('message', 'Error desconocido')
            xbmcgui.Dialog().ok("ERROR", f"Error de AllDebrid: {error_msg}")
            return None

    except Exception as e:
        xbmcgui.Dialog().ok("ERROR", f"Error en la petición: {e}")
        return None
       
def rev_pal (id):
    url = f'https://api.alldebrid.com/v4/link/unlock?agent=Palantir3&apikey=6F2vxJcLC2vHwRhgc3ym&link={id}'
    respuesta = str(Texto_url(url))
    regex = 'link":"(.*?)"'
    match = re.search(regex, respuesta)
    url = match.group(1)
    url_p1 = urllib.parse.unquote(url)
    url_final = str(url_p1).replace("\\", "").replace(" ", "")
    return url_final
    xbmc.log("TEXTO DE LA URL:  " + url_final, xbmc.LOGINFO)
    xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
def carpeta_ficher (id):
    url = "https://api.1fichier.com/v1/file/ls.cgi"
    headers = {
        "Authorization": "Bearer gkYeVeslP_jqLfvMqV_g-2DSkbCqfFb5",
        "Content-Type": "application/json"
    }
    data = {
        "folder_id": f'{id}'
    }
    response = requests.post(url, headers=headers, json=data)
    html_content = response.text 
    #xbmc.log("TEXTO DE LA URL:  " + html_content, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    # Extraer todos los nombres de archivo
    nombres = []
    patron_nombre = r'"filename":"(.*?)"'
    nombres = re.findall(patron_nombre, html_content)
    
    # Extraer todas las URLs
    urls = []
    patron_url = r'"url":"(.*?)"'
    urls = re.findall(patron_url, html_content)
    
    # Emparejar nombres con URLs
    archivos_emparejados = []
    for i in range(len(nombres)):
        nombre_limpio = re.sub(r'\.(mp4|mkv|avi|mov|wmv|flv|webm)$', '', nombres[i])
        archivos_emparejados.extend(['nombre', nombre_limpio, 'url', urls[i]])
    #xbmc.log("TEXTO DE LA URL:  " + str(archivos_emparejados), xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    '''
    # Definimos la ruta directamente usando el protocolo de Kodi
    ruta_resolveurl = "special://profile/addon_data/script.module.resolveurl/"
    settings_path = ruta_resolveurl + "settings.xml"

    # Comprobamos si la carpeta existe
    if xbmcvfs.exists(ruta_resolveurl):
        # Comprobamos si el archivo settings.xml existe
        if not xbmcvfs.exists(settings_path): 
            xbmcgui.Dialog().ok("Atención por favor!!:", "Si quieres ver el contenido, primero tienes que emparejar tu cuenta de ALLDEBRID con Play.")
            # Si no existe el xml, ejecutamos el plugin
            url_plugin = "plugin://script.module.resolveurl/?mode=auth_ad"
            xbmc.executebuiltin(f'RunPlugin({url_plugin})')
    else:
        xbmcgui.Dialog().ok("Atención por favor!!:", "Si quieres ver el contenido, primero tienes que emparejar tu cuenta de ALLDEBRID con Play.")
        url_plugin = "plugin://script.module.resolveurl/?mode=auth_ad"
        xbmc.executebuiltin(f'RunPlugin({url_plugin})')'''
        #xbmcgui.Dialog().ok("Resultado:", "No existe la carpeta de configuración de 'resolveurl'")
    #xbmc.log(f"DEBUG: El contenido actual es: {xbmc.getInfoLabel('Container.Content')}", xbmc.LOGINFO)   
    return archivos_emparejados
def Tv(url):
    #xbmcgui.Dialog().ok("torrent", url)
    item = xbmcgui.ListItem(path=f"{url}")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


    
    
def BIG(url):
    
    #regex = "href='([^']*\.torrent[^']*)'"
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
    'referer': 'https://www10.playdede.link/pelicula/sin_instrucciones_1238200',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
}
    response = requests.get(url, headers=headers)
    html_content = response.text
    html_content = html_content.replace('\x00', '')
    #xbmc.log("URL FINAL ES :  " + html_content, xbmc.LOGINFO)
    xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    
def torrent(url):
    #xbmc.log("URL FINAL ES :  " + url, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("torrent", url)
    regex = "href='(.*?)'"
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    match = re.search(regex, html_content)
    url = match.group(1)
    
    url = "https:" + url 
    
    item = xbmcgui.ListItem(path=f"plugin://plugin.video.elementum/play?uri={url}")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def torrent_di(url):    
    #xbmcgui.Dialog().ok("torrent", url)
    item = xbmcgui.ListItem(path=f"plugin://plugin.video.elementum/play?uri={url}")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def Favoritos_p(url): 
   #PRIMERO CERRAR CUADROS DE DIALOGOS IMPORTANTISIMO PARA QUE FUNCIONE BIEN
   item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
   xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
   xbmc.sleep(100)
   xbmc.executebuiltin('Dialog.Close(all)')
   #REPLICAR EXACTAMENTE COMO FAVORITOS    
   xbmc.executebuiltin(f'PlayMedia("{url}")')
   #LAS TRES LINEAS SIGUIENTES VAN UNIDAS PARA QUE NO SALGAN ERRORES POSTERIORES
   
                               
   sys.exit()
def vista_serie():
    xbmc.executebuiltin("Container.SetViewMode(515)") 

def Buscador_series_Pa(url):   
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
     
    
    
    url_base = "plugin://plugin.video.palantir3/?dmL0JXYuFmZcx1MylGduFGbhBnLvVGZpZnLul2Z1xGccx1cu9GZkFGXclGZvtEXcdmbp1WYvJFXcFGdhREcwFEXcZHVfNXdzFEXcNnclNXVcxlODdCI6ICdyFmbhZmIgwyJzVGbpZ2JgojI05WZ052bjJCIscyMyF2YzVnYnAiOi42bpR3YhJye9JyOx4Wa0FGbgUEVBxETPNEIvxWd0lGdgknYgIVREJ1TgkybsVHdpRHIscyclcCKgAFWFdURSlGIlJXZodHIsFmcl5WZH91cllmclN3X2BSTPJlRuxlccBCIn5Wa0Fmcgwybn9GbyFWZsNGIsIXZslWYyRHIs8mcl5WZnxSYhBXbs8WakVXYsIGZtRHLvRmbvZGLyVGdz9GcsQ3bsBHLhh2YlZGLvxWd0lGdgQ1QFxURTJCI6ICbxNnIgwyJdJ1TM90Qvs1cllmclNVXwAzNkZmZmZGIS9ETPN0WnAiOiQ3bsBnIgwCMgojIldWYwJCIscSXS9ETPN0Lb9Gb1RXrDTHIy9GUgACIg0FMwcDZmZmZmBiUPx0TDt1JgojIsVmYhxmIgwyJn5GcuIXYjNXdixFXhlGZl1GXcNXZjJXdvNXZyxFXzIXa05WYsFGcu8WZklmdu4WanVHbwxFXz52bkRWYcxVak92Scx1ZulWbh9mUcxVY0FGRwBXQcxldU91c1NXQcx1cyV2cVxFX6M0JgojIu92YpJCIsciZp"
    
    # Usamos Container.Update con "replace" para machacar el historial
    
    xbmc.executebuiltin(f'Container.Update("{url_base}",replace)')
    
    # 3. EL BUCLE CENTINELA (Vigilante)
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        # Consultamos qué hay en pantalla ahora mismo
        ruta_actual = xbmc.getInfoLabel('Container.FolderPath')
        
        # CONDICIÓN DE SALIDA: 
        # Si la ruta actual YA NO es la de los resultados de Palantir, 
        # es que el usuario ha dado a "Atrás"
        if ruta_actual == 'plugin://plugin.video.palantir3/':            
            # 5. LANZAR TU URL DE 'PLAY'
            # Redireccionamos a tu addon para limpiar la navegación
            url_play = "plugin://plugin.video.play/?dXJsPWh0dHBzJTNBJTJGJTJGZGwuZHJvcGJveC5jb20lMkZzJTJGNDkyeHRzbW45dnVodG5yJTJGU2VyaWVzLmh0bWwmbW9kZT0xJm5hbWU9JTVCQ09MT1Irb3JhbmdlcmVkJTVEJTVCQiU1RCUzQyU1QkNPTE9SK2dvbGQlNUQlM0MlNUIlMkZDT0xPUiU1RCUzQyU1QiUyRkNPTE9SJTVEK1NlcmllcyslNUJDT0xPUitvcmFuZ2VyZWQlNUQlM0UlNUJDT0xPUitnb2xkJTVEJTNFJTVCJTJGQ09MT1IlNUQlM0UlNUIlMkZCJTVEJTVCJTJGQ09MT1IlNUQmZmFuYXJ0PWh0dHBzJTNBJTJGJTJGZHJpdmUuZ29vZ2xlLmNvbSUyRnVjJTNGZXhwb3J0JTNEZG93bmxvYWQlMjZpZCUzRDFuVmNHVS1XZnhOU2xhdmVQVU43QlI0WHU3VzE1UjMzVQ="
            
            xbmc.executebuiltin(f'ReplaceWindow(10025, "{url_play}")')
            
            # Salimos del bucle
            break
        
        # Pequeño sueño para no quemar la CPU (vuelve a mirar cada 250ms)
        if monitor.waitForAbort(0.1):
            break
    
    sys.exit()   
def Buscador_Pelis_Pa(url):   
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
     
    
    
    url_base = "plugin://plugin.video.palantir3/?vUWbvh2LvoDbhl2YlB3cnAiOi42bjlmIgwyJml2ZuQnch5WYm9yMylGduFGbhBnLvVGZpZnLul2Z1xGcvMnbvRGZh9SZt9Gav8iOsFWajVGczdCI6ICdyFmbhZmIgwyJzVGbpZ2JgojI05WZ052bjJCIscyMyF2YzVnYnAiOi42bpR3YhJyeQfisTMulGdhxGIFRVQMx0TDBybsVHdpRHI5JGISVERS9EIp8Gb1RXa0BCLnMXJngCIQhVRHVkUpBSZyVGa3BSYsV3YpxWZQ91cpxWZw9ldg00TSZkbcJHXgASYpJ3bnVGdhNGIscmbpRXYyBCLvd2bsJXYlx2YgwiclxWahJHdgwybyVmbldGLhFGctxibvlGdhJXdkxiYk1GdsQWYklGbhNGLvlGZ1FGLvRmbvZGLyVGdz9GcsQ3bsBHLhh2YlZGLvxWd0lGdgQ1QFxURTJCI6ICbxNnIgwyJdJ1TM90Qvs1chxWdj16wsVGUdBDM3QmZmZmZgI1TM90QbdCI6ICdvxGciACLwAiOiU2ZhBnIgwyM1AiOiQ3cpxUblRXS0lWbpxmIgwyJdJ1TM90Qvs1bsVHdtOMdgI3bQBCIgASXwAzNkZmZmZGIS9ETPN0WnAiOiwWZiFGbiACLncmbw5ichN2c1J2LhlGZl12LzV2YyV3bzVmcvMjcpRnbhxWYw5yblRWa25ibpdWdsB3Lz52bkRWY"
    
    # Usamos Container.Update con "replace" para machacar el historial
    
    xbmc.executebuiltin(f'Container.Update("{url_base}",replace)')
    
    # 3. EL BUCLE CENTINELA (Vigilante)
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        # Consultamos qué hay en pantalla ahora mismo
        ruta_actual = xbmc.getInfoLabel('Container.FolderPath')
        
        # CONDICIÓN DE SALIDA: 
        # Si la ruta actual YA NO es la de los resultados de Palantir, 
        # es que el usuario ha dado a "Atrás"
        if ruta_actual == 'plugin://plugin.video.palantir3/':            
            # 5. LANZAR TU URL DE 'PLAY'
            # Redireccionamos a tu addon para limpiar la navegación
            url_play = "plugin://plugin.video.play/?dXJsPWh0dHBzJTNBJTJGJTJGZGwuZHJvcGJveC5jb20lMkZzJTJGZDRrMW9nODg5ZGhodWUzJTJGc2Fsb25fcGVsaWN1bGFzLmh0bWwmbW9kZT0xJm5hbWU9JTVCQ09MT1Irb3JhbmdlcmVkJTVEJTVCQiU1RCUzQyU1QkNPTE9SK2dvbGQlNUQlM0MlNUIlMkZDT0xPUiU1RCUzQyU1QiUyRkNPTE9SJTVEK1BlbCVDMyVBRGN1bGFzKyU1QkNPTE9SK29yYW5nZXJlZCU1RCUzRSU1QkNPTE9SK2dvbGQlNUQlM0UlNUIlMkZDT0xPUiU1RCUzRSU1QiUyRkIlNUQlNUIlMkZDT0xPUiU1RCZmYW5hcnQ9aHR0cHMlM0ElMkYlMkZkcml2ZS5nb29nbGUuY29tJTJGdWMlM0ZleHBvcnQlM0Rkb3dubG9hZCUyNmlkJTNEMW5WY0dVLVdmeE5TbGF2ZVBVTjdCUjRYdTdXMTVSMzNV"
            
            xbmc.executebuiltin(f'ReplaceWindow(10025, "{url_play}")')
            
            # Salimos del bucle
            break
        
        # Pequeño sueño para no quemar la CPU (vuelve a mirar cada 250ms)
        if monitor.waitForAbort(0.1):
            break
    
    sys.exit()
    xbmcgui.Dialog().notification('salir del bucle', 'lol', time=1000, sound=False)
    
def liberar_reproductor():
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
    return

    
def cambio_vision(numero):
    deseo = "Inicio"
    actual = "Inicio"
    intentos = 1    
    
    deseo = xbmc.getInfoLabel("Container.FolderPath")
    actual = xbmc.getInfoLabel("ListItem.FolderPath")
    
    #xbmc.log(f'Voy de {ruta1}\na entar a {eleccion}', xbmc.LOGINFO)
    #xbmcgui.Dialog().ok('de A a B', f"Voy de {ruta1}\na entar a {eleccion}")
    #xbmcgui.Dialog().ok('al final ', f"{ruta}\n {viewmode}")      
    monitor = xbmc.Monitor()
    start_time = time.time()
    while not monitor.waitForAbort(0.05):        
        actual = xbmc.getInfoLabel("Container.FolderPath")       
        #xbmc.log(f'(CAMBIO_VISION) =======  {intentos}, {numero}', xbmc.LOGINFO)
        #xbmcgui.Dialog().ok('de A a B', f"Voy de {ruta1}\na entar a {eleccion}")
        ruletita = xbmc.getCondVisibility("Window.IsActive(busydialog)")
        if actual == deseo and not ruletita:            
            #xbmc.sleep(100)
            xbmc.executebuiltin(f"Container.SetViewMode({numero})")
            xbmc.log(f'({numero} CAMBIO_VISION) = {intentos} intentos', xbmc.LOGINFO)
            break    
        if time.time() - start_time > 5:
            xbmc.log(f'(CAMBIO_VISION NO SE PUDO) =======  {intentos}', xbmc.LOGINFO)    
            break     
        intentos += 1 
        
def modo_escucha(desde_cajon=False, modo="favoritos_sv"):
    '''vista_actual = xbmc.getInfoLabel('Container.Viewmode')    
    xbmc.log("TEXTO ENCONTRADO: " + vista_actual, xbmc.LOGINFO)
    xbmcgui.Dialog().ok("sale del bucle", f"{vista_actual}")'''
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    
    xbmc.sleep(1000)
    ruta_de_entrada = xbmc.getInfoLabel("Container.FolderPath")
    TIEMPO_MAX_INACTIVIDAD = 20
    tiempo_ignorado = 0 
    
    deseo = "Inicio"
    actual  = "Inicio"
    deseo = xbmc.getInfoLabel("Container.FolderPath")
    actual = xbmc.getInfoLabel("ListItem.FolderPath")
    #xbmc.log(f'estoy en  =======  {actual}\ny voy a ======= {deseo}', xbmc.LOGINFO)
    #sys.exit()
    while not monitor.abortRequested():
        
        # === CAMBIO 2: NUESTRA NUEVA LÓGICA DE TIEMPO ===
        idle_actual = xbmc.getGlobalIdleTime()
        
        # Si el usuario toca el mando, el contador de Kodi baja a 0, 
        # así que nosotros también reiniciamos nuestra trampa matemática.
        if idle_actual < tiempo_ignorado:
            tiempo_ignorado = 0
            
        # Calculamos el tiempo real de inactividad restando lo que ignoramos
        tiempo_real_inactivo = idle_actual - tiempo_ignorado

        # Ahora preguntamos por el tiempo real, no por el de Kodi
        if tiempo_real_inactivo > TIEMPO_MAX_INACTIVIDAD:
            # 1. Cerramos cualquier ventana de diálogo abierta (por si acaso)
            xbmc.executebuiltin('Dialog.Close(all)')
            # 2. Simulamos la pulsación de la tecla "Atrás"
           
            xbmc.executebuiltin('Action(Back)')
            # 3. Esperamos un momento para que Kodi procese el retroceso
            #xbmc.sleep(500)
            
            return True
            
        if player.isPlaying():
            
            # 1. Variable para recordar cómo ha terminado el vídeo
            termino_solo = False 
            
            
            while player.isPlaying() and not monitor.abortRequested(): 
                # AQUI CONTROLAS EL STOP a MITAD Y EL FINAL O QUE ACABE SOLA
                
                try:
                    tiempo_actual = player.getTime()
                    tiempo_total = player.getTotalTime()
                    #if tiempo_total > 0 and (tiempo_total - tiempo_actual) < 180:
                    if tiempo_total > 0:
                        # Calculamos el porcentaje que se ha reproducido
                        porcentaje_visto = (tiempo_actual / tiempo_total) * 100
                        
                        if tiempo_actual >= 180:
                            termino_solo = True
                except:
                    pass
                monitor.waitForAbort(0.2)
                
            # =========================================================
            # EL VÍDEO YA NO SE REPRODUCE. TOMAMOS DECISIONES:
            # =========================================================
            # ESTE apartado '''El IF''' es para marca capitulo (palomita o play) El ELSE es para cuando sale cartel por dar stop pronto'''
            
            if termino_solo:              
                start_time = time.time()                
                while not monitor.waitForAbort(0.05):                     
                    vista = xbmc.getCondVisibility("Control.IsVisible(50)")
                    ruletita = xbmc.getCondVisibility("Window.IsActive(busydialog)")
                    if vista and not ruletita:
                        break
                    if time.time() - start_time > 30:
                        break
                xbmc.executebuiltin("Container.SetViewMode(515)")        
                #cambio_vision(515)
                #return False
            else:
                #xbmcgui.Dialog().ok("recibido de escucha ", f'{termino_solo}')
                intentos_stop = 1
                con_rule = 0
                dialogo_cerrado = False
                ruleta_detectada = False
                ruleta_registrada = False
                start_time2 = time.time()
                while not monitor.waitForAbort(0.05): 
                    
                    vista = xbmc.getCondVisibility("Control.IsVisible(50)")
                    ruletita = xbmc.getCondVisibility("Window.IsActive(busydialog)")
                    
                    if ruletita:
                        ruleta_detectada = True
                    if not ruletita and ruleta_detectada and not ruleta_registrada:
                        xbmc.log(f'(STOP)La ruleta se quito en === {intentos_stop}', xbmc.LOGINFO) 
                        ruleta_registrada = True 
                        
                    if xbmc.getCondVisibility("Window.IsActive(12000)"):
                        xbmc.executebuiltin("Dialog.Close(12000)")                  
                        dialogo_cerrado = True
                        xbmc.log(f'(STOP)se cerro opciones en === {intentos_stop}', xbmc.LOGINFO)
                    
                    if vista and dialogo_cerrado and not ruletita:
                        xbmc.log(f'(STOP)salimos en === {intentos_stop}', xbmc.LOGINFO)
                        return False    
                    if time.time() - start_time2 > 30:
                        xbmc.log(f'SALTAMOS EL BUCLE POR TIEMPO en STOP  =======  {intentos_stop}', xbmc.LOGINFO)
                        break 
                        
                    intentos_stop += 1                                
                        
            # === CAMBIO 3: EL VÍDEO HA TERMINADO Y TODO ESTÁ CARGADO ===
            # Le decimos a nuestro script que todo el tiempo que Kodi haya 
            # acumulado hasta este exacto segundo... queda perdonado/ignorado.
            tiempo_ignorado = xbmc.getGlobalIdleTime()                   

        # --- Lógica de Salida CUANDO EL USUARIO A ATRAS EN EPISODIOS---
        ruta_actual = xbmc.getInfoLabel("Container.FolderPath")
        if ruta_actual != ruta_de_entrada:
           
            #
            if not player.isPlaying() and not ruta_actual.startswith(ruta_de_entrada):
                
                
                if xbmc.getCondVisibility('Control.IsVisible(508)') or xbmc.getCondVisibility('Control.IsVisible(50)'):
                    atras = 'atras o avance'
                    #xbmcgui.Dialog().ok("recibido de escucha ", f'{atras}')
                    if modo == "favoritos_sv":
                        return False
                    if modo == "favoritos_s":
                        return True

        if not xbmc.getCondVisibility("Window.IsActive(10025)"):
            break

        if monitor.waitForAbort(0.2):
            break
    
    return True
def limpieza_de_bucles():
    # ==========================================================
    #  COMBO DE LIMPIEZA DE SEGURIDAD (POST-BUCLE)
    # ==========================================================

    # 1. Forzar el cierre de cualquier ruleta de carga o diálogo de progreso atascado
    xbmc.executebuiltin("Dialog.Close(busydialog, true)")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Dialog.Close(extendedprogressdialog, true)")
    xbmc.sleep(1000)
    xbmc.executebuiltin('Dialog.Close(all, true)')

    # 2. Eliminar referencias a variables pesadas y al monitor de eventos
    if 'monitor' in locals():
        del monitor

    # 3. Forzar la liberación inmediata de memoria RAM (Garbage Collector)
    import gc
    gc.collect()

    # 4. Detener por completo la ejecución de este hilo de Python
    
    sys.exit()   
def Favoritos_sv(url_raiz):
    
    liberar_reproductor()
    
    xbmc.executebuiltin(f'ActivateWindow(10025,"{url_raiz}",return)')    
    
    monitor = xbmc.Monitor() 
    while not monitor.abortRequested():    
        # 1. Preguntamos qué hay en el contenedor y qué vista tiene puesta
        es_temporadas = xbmc.getCondVisibility("Container.Content(seasons)")
        es_episodios = xbmc.getCondVisibility("Container.Content(episodes)")
        # Solo actuamos si el control 50 (la lista) es visible
        focus = xbmc.getCondVisibility("Control.HasFocus(50)")
        vista = xbmc.getCondVisibility("Control.IsVisible(50)")
        ruletita = xbmc.getCondVisibility("Window.IsActive(busydialog)")
        if vista and focus and not ruletita:            
            # --- NIVEL A: TEMPORADAS (Vista 724) ---
            if es_temporadas: # Si no es la 724, la forzamos
                cambio_vision(724)
                #xbmc.executebuiltin("Container.SetViewMode(724)")             
                termino_solo = modo_escucha(True, "favoritos_sv")
            # --- NIVEL B: EPISODIOS (Vista 515) ---
            elif es_episodios: # Si no es la 515, la forzamos
                
                cambio_vision(515)       
                
                termino_solo = modo_escucha(True, "favoritos_sv")
                #xbmcgui.Dialog().ok("recibido de escucha ", f'{termino_solo}')
                if termino_solo:
                    
                    # 300 intentos x 100 milisegundos (0.1s) = 30 segundos en total
                    vista_actual = xbmc.getInfoLabel("Container.Viewmode")
                    
                    #sys.exit()
                    start_time = time.time()   
                    while time.time() - start_time < 10:                       
                        vista_futura = xbmc.getInfoLabel("Container.Viewmode")
                        ruletita = xbmc.getCondVisibility("Window.IsActive(busydialog)")
                        focus = xbmc.getCondVisibility("Control.HasFocus(50)")
                        #xbmc.log(f'vista_actual {vista_actual}\nvista_futura {vista_futura}', xbmc.LOGINFO)
                        if  vista_actual != vista_futura and not ruletita and focus:#xbmcgui.Dialog().ok("ok", "estoy en temporadas")
                            xbmc.executebuiltin("Container.SetViewMode(724)")
                            #cambio_vision(724)
                            xbmc.sleep(3000)                            
                            xbmc.executebuiltin('Action(Back)')
                            return
                            # Esto evita que Kodi se cuelgue y sirve como nuestro reloj.
                        if monitor.waitForAbort(0.2):
                            break
                        
                    break
                # Al volver del modo_escucha, forzamos un refresco visual
                # para que al volver a temporadas se ponga bien la vista
                #xbmc.sleep(300) 
                continue # Saltamos al principio del bucle para re-evaluar todo
        #
        # --- NIVEL C: SALIDA SI EL USUARIO ECHA ATRAS---
        elif not es_temporadas and not es_episodios:
            if xbmc.getCondVisibility('Control.IsVisible(508)'):
                #
                break          
        if monitor.waitForAbort(0.2):
            break
            
    limpieza_de_bucles()
    #xbmcgui.Dialog().ok("SISTEMA", "Bucle cerrado correctamente.")
    
    
    #xbmcgui.Dialog().ok("a ver", "palante") 

        
def Favoritos_s(url):
    
    liberar_reproductor()
    
    xbmc.executebuiltin(f'ActivateWindow(10025,"{url}",return)')  
        
    if "thecrew" in url:
        xbmc.executebuiltin("Container.SetViewMode(500)")
    elif "balandro" in url: 
        xbmc.executebuiltin("Container.SetViewMode(50)")
    else:       
        monitor = xbmc.Monitor()      
        start_time = time.time()       
        inicio_ruleta = None
        while True: 
            #xbmcgui.Dialog().ok('modo_escucha retorna', f"{termino_solo}")
            ruletita = xbmc.getCondVisibility("Window.IsActive(busydialog)")
            if ruletita:
                if inicio_ruleta is None:
                    inicio_ruleta = time.time()
                if time.time() - inicio_ruleta > 30:
                    # La ruleta lleva 30 segundos seguidos
                    break
            else:
                # La ruleta desapareció, reiniciamos el contador
                inicio_ruleta = None
                                
            ''' Si no esta la ruletita de cargando es por que esta en la ventana que quieres cambiar la vision, asi la ventana de atras conservara su vision''' 
            focus = xbmc.getCondVisibility("Control.HasFocus(50)")
            vista = xbmc.getCondVisibility("Control.IsVisible(50)") 
            ruletita = xbmc.getCondVisibility("Window.IsActive(busydialog)")
            if vista and focus and not ruletita:
                cambio_vision(515)
                termino_solo = modo_escucha(True, "favoritos_s")
                 
                if termino_solo:                    
                    break               
            
            # SALVAVIDAS 1: Si el usuario cierra Kodi o el addon se detiene
            if monitor.abortRequested():
                return False
                
            # SALVAVIDAS 2: Si el usuario se cansa de esperar y da atrás (sale de la ventana de videos)
            if not xbmc.getCondVisibility("Window.IsActive(10025)"):
                return False
                
            # Pequeña pausa de 100ms para no saturar el procesador mientras espera
            if monitor.waitForAbort(0.2):
                break
            
    #xbmcgui.Dialog().ok('ESTOY FUERA', "Se acabó")               
    limpieza_de_bucles()     
    
        
def resolver_Streamwish(url, titulo):
    
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    desofuscar(url, html_content, titulo)
    
    #xbmc.log(f"url = {url} + respuesta_web_text = {html_content} +  titulo = {titulo}", xbmc.LOGERROR)
    #xbmcgui.Dialog().ok("enlace encontrado", f"{url}")  
    
    
def texto_url2(url):
    es_android = xbmc.getCondVisibility("system.platform.android")
    headers = HEADERS["android"] if es_android else HEADERS["desktop"]
    try:
        
        response = requests.get(url, headers=headers)  # Agregar tiempo de espera
        #response.raise_for_status() # Lanza una excepción si la respuesta no es 2xx
        #xbmc.log(response.text, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("Estoy dentro de texto_url", f'devuelvo texto: {url}')
        return response.text
        
    except requests.RequestException as e:
        caller_frame = inspect.stack()[1]
        caller_info = f"Llamado desde {caller_frame.filename}, línea {caller_frame.lineno}, en la función {caller_frame.function}"
        #xbmc.log(caller_info, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("Estoy dentro de funcion texto_url", f'devuelvo none: {url}')
        return None
    
def url_con_cabeza(url, regex):  
    es_android = xbmc.getCondVisibility("system.platform.android")
    headers = HEADERS["android"] if es_android else HEADERS["desktop"]
    response = requests.get(url, headers=headers)
    html_content = response.text    
    match = re.search(regex, html_content)
    #xbmc.log(html_content, xbmc.LOGINFO) 
    #xbmcgui.Dialog().ok("Estoy dentro de url_con_cabeza", str(match))
    if match:
        url_final = match.group(1)        
        headers_string = '&'.join([f"{key}::{value.replace(' ', '+')}" for key, value in headers.items()])
        headers_string = quote(headers_string, safe="&+").replace('%3A%3A', '=')    
        url_con = f"{url_final}|{headers_string}"
    else:
        url_con = "2701"
    return url_con
    #url_final_with_headers = f'''{url_final}|Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/98.0.4758.102Safari/537.36'''
    #return url_final_with_headers
    
    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url_final_with_headers))
    #sys.exit()
    
def resolver_Vtube(url, regex1, regex2): 
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url, headers=headers)
    html_content = response.text
        
    match = re.search(f"(?s){regex1}.*?{regex2}", html_content)
    cacho2 = match.group(1)    
    cacho1 = match.group(2)    
    url_final = f"https://{cacho1}.vtube.network/hls/{cacho2}.urlset/master.m3u8"  
    #xbmc.log(url_final, xbmc.LOGINFO) 
    url_final_with_headers = f'''{url_final}|Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/98.0.4758.102Safari/537.36'''
    return url_final_with_headers
    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url_final_with_headers))
    #sys.exit()
def resolve_vidhide(url):
    
    try:  
        
        resolved_url = desofuscar(url)              
        return resolved_url                
    except:
        #xbmc.log(url, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("error", f'error desofuscar: {url}')
        #sys.exit()
        html_content = html_content_errores 
        
        if "Video is processing" in html_content:
            xbmcgui.Dialog().ok("Aviso de codificación.", "Pendiente de codificación, cuando termine el proceso podrá disfrutar del video, disculpe las molestias.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')
            sys.exit()
        elif "vidhide" in url:
            url_descargas = url.replace("/v/", "/download/").replace("/file/", "/download/")   
            html_content = texto_url(url_descargas)
            if 'No such file=' in html_content:
                url = "2701"
                return url
                #xbmc.log(html_content, xbmc.LOGINFO)
                #xbmcgui.Dialog().ok("Error--- 2701", "Contacte con el creador del addon para darle el código de error. Disculpe las molestias.")
            if '.mkv' in html_content:
                prefijo = "_n" 
                nueva_url_descargas = url_descargas + prefijo
                html_content = texto_url(nueva_url_descargas)
                
                if 'Downloads disabled' in html_content:
                    xbmcgui.Dialog().ok("Avis de codificación", "Pendiente de codificación, cuando termine el proceso podrá disfrutar del video, disculpe las molestias.")
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                    xbmc.executebuiltin('Dialog.Close(all)') 
        
        elif "Please allow a few hours for the file to be" in html_content or "Please give us some time" in html_content:       
            xbmcgui.Dialog().ok("Servidor en mantenimiento", "Espere unas horas para que el archivo se transfiera a un servidor de mayor rendimiento. Gracias por su paciencia.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')                
        elif "File Not Found" in html_content:
            xbmcgui.Dialog().ok("Archivo borrado", "Contacte con el creador del addon para que repare el enlace. Si no le avisa, él no sabrá que este enlace tiene que repararlo. Disculpe las molestias.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')
        else:
            url = "2701"
            return url
            #xbmcgui.Dialog().ok("Error--- 2701", "Contacte con el creador del addon para darle el código de error. Disculpe las molestias.")
            #xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            #xbmc.executebuiltin('Dialog.Close(all)')
    #xbmcgui.Dialog().ok("Error 2701", str(url))
#bandera = True 
def normalizar_texto(texto):
    """
    Convierte entidades HTML, minúsculas y quita acentos
    """
    if texto is None:
        return ""
    
    # 1. Convertir entidades HTML (&amp; -> &)
    # Esto detecta cosas como &amp;, &quot;, &lt;, etc. y las limpia
    texto = html.unescape(texto)
    
    # 2. Convertir a minúsculas
    texto = texto.lower()
    
    # 3. Quitar acentos usando unicodedata
    texto = ''.join(
        c for c in unicodedata.normalize('NFD', texto)
        if unicodedata.category(c) != 'Mn'
    )
    
    return texto
def consulta_titulo_fechas(sitio_web, titulo):
    fecha_estreno = None                        
    # 1. Definimos la ruta del archivo de texto
    ruta_addon_data = variacion_translatePath('special://profile/addon_data/plugin.video.play')
    ruta_txt = os.path.join(ruta_addon_data, 'titulo_fechas.txt')
    
    # 2. Si el archivo existe, buscamos la película dentro de él
    if os.path.exists(ruta_txt):
        try:
            with open(ruta_txt, 'r', encoding='utf-8') as f:
                for linea in f:
                    linea = linea.strip()
                    partes = linea.split("|")
                    
                    # Comprobamos que la línea tenga exactamente las 3 partes
                    if len(partes) == 3:
                        guardado_sitio = partes[0]
                        guardado_titulo = partes[1]
                        guardado_fecha = partes[2]
                        
                        # Comparamos el título quitando espacios sobrantes
                        if guardado_titulo.strip() == titulo.strip():
                            fecha_estreno = guardado_fecha.strip()
                            break
        except Exception as e:
            xbmc.log(f"Error al leer el archivo de caché: {str(e)}", xbmc.LOGINFO)
    
    # 3. Si no existía el archivo o la película no estaba guardada, consultamos la web
    if not fecha_estreno:
        #xbmcgui.Dialog().ok("NO", f'No la encontre en caché, tengo que preguntar en la web')
        if not sitio_web:
            fecha_estreno = Estrenos_Kodi(titulo, titulo_pelicula=True)                           
    return fecha_estreno          
def ranking(titulo, año, es_estreno=False):
    sitio_web = True
    enlace_ex = ""
    PELICULAS_ESPECIALES = {}
    sinmatch = 1
    url_Dic ="https://dl.dropbox.com/scl/fi/xcoq9md1t1c58z5w1ycb8/diccionario.txt?rlkey=877jkx64tapwtfye0qqh9fy8u&st=5eyvhnd7&dl=1"
    url = ''
    encoded_titulo = urllib.parse.quote(titulo, safe='')
    url_segun = f'https://www.themoviedb.org/search/movie?query={encoded_titulo}&language=es'
    
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url_segun, headers=headers, timeout=10)
    response.raise_for_status()
    pagi = response.text
    #xbmc.log(f"matches: {pagi}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("ahora", "ves")
    soup = BeautifulSoup(response.text, "html.parser")
    # --- NUEVA CAPTURA ADAPTADA AL HTML DE ABRIL 2026 ---
    resultados = []
    # 1. Buscamos el contenedor principal de películas
    seccion_peliculas = soup.find("div", class_="search_results movie")
    
    if seccion_peliculas:
        # 2. En el nuevo HTML, las películas están en divs que contienen "media-card"
        # Buscamos los bloques de información (donde están el título y la trama)
        # Filtramos por los divs que tienen el padding p-3 o la clase release_date
        bloques = seccion_peliculas.find_all("div", class_=re.compile("items-center content-center"), limit=5)
        
        for bloque in bloques:
            # El enlace ahora está un poco más arriba o en el h2
            enlace_tag = bloque.find_previous("a", attrs={"data-media-type": "movie"})
            h2 = bloque.find("h2")
            fecha = bloque.find("span", class_="release_date")
            overview = bloque.find("p")

            if h2:
                resultados.append({
                    "url": enlace_tag.get("href", "") if enlace_tag else "",
                    "titulo": h2.find("span").get_text(strip=True) if h2.find("span") else h2.get_text(strip=True),
                    "fecha": fecha.get_text(strip=True) if fecha else "",
                    "descripcion": overview.get_text(strip=True) if overview else ""
                })
    # -------------------------------------------------------
    #xbmc.log(f"matches: {resultados}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("ahora", f"{resultados}")
    if resultados:
        titulo_normalizado = normalizar_texto(titulo)

        for resultado in resultados:
            enlaceth = resultado["url"]
            tituloth = resultado["titulo"].strip()
            añoth = resultado["fecha"]
            tramath = resultado["descripcion"]

            match_añoth = re.search(r'\d{4}', añoth)

            if not match_añoth:
                continue

            añoth = match_añoth.group()
            tituloth = normalizar_texto(tituloth)

            if titulo_normalizado == tituloth and año == añoth:
                if titulo_normalizado == 'campeones':
                    if 'baloncesto' in tramath.lower():
                        enlace_ex = enlaceth
                        trama = tramath
                        break
                    else:
                        continue
                else:
                    sinmatch = 0
                    enlace_ex = enlaceth
                    trama = tramath
                    break    
      
    
    if sinmatch == 1: 
        
        response = requests.get(url_Dic, headers=headers)    
        html_content = response.text    
        # Buscamos directamente el título dentro del string
        # Este regex busca: "titulo": "enlace" o 'titulo': 'enlace'
        pattern = rf'["\']{re.escape(titulo.lower())}["\']\s*:\s*["\'](.*?)["\']'
        match_peli = re.search(pattern, html_content, re.IGNORECASE)

        if match_peli:
            enlace_ex = match_peli.group(1)
                        
    
        
    url = 'https://www.themoviedb.org' + enlace_ex 
    #xbmc.log(f"matches: {url}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("ahora", f"{url}")
    
    if enlace_ex == "":
        #xbmcgui.Dialog().ok("ERROR 270175", f'La pelicula: *** [COLOR green]{titulo}[/COLOR] *** tienes que añadirla al diccionario, por favor informe al Boos del Play')
        puntuacion = ""
        matches_invertidos = ""
        trama = ""
        #xbmc.log(f"URL obtenida: {puntuacion} {trama} {matches_invertidos}", xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("return 1", 'ves')
        return puntuacion, matches_invertidos, trama
        #cancelar_totalmente()
    
    if es_estreno:
        consulta = consulta_titulo_fechas(sitio_web, titulo)
        if consulta:
            return consulta
        headers = {'User-Agent': 'iPad'}
        response = requests.get(url, headers=headers)
        html_content = response.text 
        match = re.search(r'(?s)class="release">(.*?)<', html_content)
        if match:
            estreno = match.group(1)
            fecha_estreno = estreno.replace(' ', '').replace('(ES)', '').replace('\n', '')
            
            # --- NUEVA LÓGICA DE COMPARACIÓN SEGURA ---
            try:
                # Dividimos la fecha "DD/MM/YYYY" por sus barras diagonales
                partes = fecha_estreno.split('/')
                if len(partes) == 3:
                    # partes[0] = Día, partes[1] = Mes, partes[2] = Año
                    dia = int(partes[0])
                    mes = int(partes[1])
                    anio = int(partes[2])
                    
                    # Creamos el objeto de fecha directamente usando enteros (sin strptime)
                    fecha_estreno_obj = datetime.date(anio, mes, dia)
                    
                    # Obtenemos la fecha del día de hoy
                    fecha_hoy = datetime.date.today()
                    
                    # Comparamos cronológicamente
                    if fecha_estreno_obj > fecha_hoy:
                        
                        escritura_titulo_fechas(sitio_web, titulo, fecha_estreno)
                        return fecha_estreno                        
                    else:
                        sitio_web = False
                        fecha_estreno = consulta_titulo_fechas(sitio_web, titulo) 
                        return fecha_estreno
                        sys.exit()
            except Exception as e:
                # Si ocurre cualquier error inesperado en la conversión, lo ignoramos de forma segura
                xbmc.log(f"Error al procesar fecha de estreno: {str(e)}", xbmc.LOGINFO)
                fecha_estreno = 'DD/MM/YYYY'
                return fecha_estreno
    
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url, headers=headers)
    html_content = response.text             
    match = re.search(r'description" content="(.*?)"', html_content)
    if match:
        trama = match.group(1)
        
    match = re.search(r'(?s)data-percent="(.*?)"', html_content)
    if match:
        puntuacion_texto = match.group(1)       
        puntuacion = int(puntuacion_texto) / 10
        puntuacion = str(puntuacion).replace('.0', '').replace('.', ',')
        if len(puntuacion) == 1:
            puntuacion = " " + puntuacion
    else:
        puntuacion = '--' 
        
    if '?language=es' in url:       
        url = url.replace('?language=es', '/cast')
    else:
        url = url + '/cast'
        
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    
    R_corte_web = r'(?s)section class="panel pad">(.*?)</section' 
    match = re.search(R_corte_web, html_content)
    if match:
        corte_web = match.group(1)        
        soup = BeautifulSoup(corte_web, 'html.parser')
    else:
        soup = BeautifulSoup(html_content, 'html.parser')

    # Buscamos todos los elementos de la lista del reparto
    reparto_items = soup.find_all('li', attrs={'data-order': True})

    matches_invertidos = []
    count = 0

    for item in reparto_items:
        # Si ya tenemos 10 actores VÁLIDOS, paramos
        if count >= 10:
            break

        # 1. EXTRAER NOMBRE (Obligatorio)
        info_div = item.find('div', class_='info')
        nombre = ""
        personaje = ""
        foto = ""
        if info_div:
            nombre_tag = info_div.find('a')
            if nombre_tag:
                nombre = nombre_tag.get_text(strip=True)
                
                personaje_tag = info_div.find('p', class_='character')
                if personaje_tag:
                    personaje = personaje_tag.get_text(strip=True)

        # 2. EXTRAER FOTO (Obligatorio)
        # Buscamos la etiqueta img; si no existe, 'foto' será un string vacío
        img_tag = item.find('img', class_='profile w-full')
        foto = img_tag.get('src', '') if img_tag else ""       

        # --- VALIDACIÓN CRÍTICA ---
        # Solo procesamos si hay NOMBRE y hay FOTO
        if nombre and foto:
            # Limpieza de entidades HTML (ej: &amp; -> &)
            nombre_clean = html.unescape(nombre)
            personaje_clean = html.unescape(personaje)

            if personaje_clean:
                text = f"{nombre_clean} ([COLOR green]{personaje_clean}[/COLOR])"
            else:
                text = nombre_clean

            # Añadimos a la lista y subimos el contador
            matches_invertidos.append((text, foto))
            count += 1
        else:
            # Si falta el nombre o la foto, ignoramos este <li> y pasamos al siguiente
            continue

    #xbmc.log(f"URL obtenida: {puntuacion} {trama} {matches_invertidos}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("return 2", 'ves')    
    return puntuacion, matches_invertidos, trama
    
def decode (url):
    #xbmc.log(f"URL obtenida: {url}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("dentro de petra.cajon", url)
    params = sys.argv[2]
    url = params.replace('?', '')
    url = urllib.parse.unquote(url)
    padding_needed = len(url) % 4
    if padding_needed:
        url += '=' * (4 - padding_needed)            
    trozo_bites = base64.b64decode(url)
    url = trozo_bites.decode('utf-8') 
    
    return url
def foto_lista():
     # Obtener la lista de reproducción de video
    playlist_id = xbmc.PLAYLIST_VIDEO
    #xbmc.log(f"Obteniendo la lista de reproducción de videos con ID {playlist_id}.", xbmc.LOGINFO)
    playlist = xbmc.PlayList(playlist_id)
    
    # Asegurarse de que la lista de reproducción no esté vacía
    size = playlist.size()
    #xbmc.log(f"Lista de reproducción de videos obtenida: tamaño {size}.", xbmc.LOGINFO)
    
    ###if size == 0:
        ###xbmc.log("La lista de reproducción de videos está vacía.", xbmc.LOGINFO)
        ###return
    
    #urls = []
    for index in range(size):
        item = playlist[index]
        #xbmc.log(f"Accediendo al elemento {index}.", xbmc.LOGINFO)
        if isinstance(item, xbmcgui.ListItem):
            # Obtener la URL del item, que normalmente se encuentra en el 'path'
            url = item.getPath()
            #xbmc.log(f"URL obtenida: {url}", xbmc.LOGINFO)
            #if url:
                #urls.append(url)
        else:
            xbmc.log(f"Elemento en la lista de reproducción no es un xbmcgui.ListItem: {item}", xbmc.LOGINFO)
    
    
    url_L = decode(url)
    match = re.search(r"iconimage=(.*?)&", url_L)
        
    
    if any(term in url for term in ['palantir', 'mega', 'rapidgator', '.com/%3F']):
        
        #re.search(r'palantir|mega|rapidgator', url):
        foto = 'https://dl.dropbox.com/scl/fi/xljdbiee07ody1xo0mimp/pasar_por_caja.jpg?rlkey=3o2mripsa3c14fqmzj2e6enoz&st=f5qb845n&dl=0'
    else:    
        foto = match.group(1)
   
    return foto
    #xbmcgui.Dialog().ok("dentro de petra.cajon", str(url))
    #sys.exit()
def palantir_p(url):    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    xbmc.executebuiltin('Dialog.Close(all)')           
        ##EJECUTA EL LINK DE PALANTIR
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))
    control_bucle = 0
    # Sistema de espera infinita
    player = xbmc.Player()
    monitor = xbmc.Monitor() 
    xbmc.executebuiltin('Dialog.Close(12002)')            
    time.sleep(5)
    if player.isPlaying():                
        while not monitor.abortRequested():
            #xbmcgui.Dialog().notification('dentro del bucle', 'lol', time=1000, sound=False)
            # 1. Usuario reproduce algo
            if player.isPlaying():
                # Esperar a que termine usuario da STOP
                while player.isPlaying() and not monitor.abortRequested():           
                    monitor.waitForAbort(0.1)
            if xbmc.getCondVisibility("Window.IsActive(12000)"):             
                xbmc.executebuiltin('Dialog.Close(12000)')
                control_bucle = 1
                break 
            if xbmc.getCondVisibility('Control.IsVisible(50)') or xbmc.getCondVisibility('Window.IsVisible(Home)'):            
                control_bucle = 2
                break
            monitor.waitForAbort(0.4)        
    '''if control_bucle == 1:
        xbmcgui.Dialog().notification('cartel de opciones', 'Estoy fuera del blucle', time=2000, sound=False)
    if control_bucle == 2:
        xbmcgui.Dialog().notification('Back', 'Estoy fuera del blucle', time=2000, sound=False)'''
        
    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(12002)')
    sys.exit()
    
def cajon(trailer, url, saltar, año, titulo):
    
    if titulo != "":
        foto = foto_lista()
        foto = urllib.parse.unquote(foto)        
        puntuacion_pelicula, fotos_filma, trama = ranking(titulo, año)
        if titulo == 'Petty Thief Girl':
            titulo = 'Chica Quinqui'
        #xbmcgui.Dialog().ok("dentro de petra.cajon", titulo)
        if titulo == 'Jokes & Cigarettes':
            titulo = 'Saben aquell'
        #if titulo != "Ocho pasos":
        sinopsis = trama.replace("(FILMAFFINITY)", "").replace("<br />", "")
        try:
            # Para Python >= 3.4
            from html import unescape
            def decode_html_entities(text):
                return unescape(text)
        except ImportError:
            # Para Python < 3.4
            from HTMLParser import HTMLParser
            def decode_html_entities(text):
                return HTMLParser().unescape(text)  # Instancia HTMLParser localmente
        sinopsis = decode_html_entities(sinopsis)
    
########################################################################################################## 
            ######### fotos_filma es una lista de tuplas cada tupla tiene el nombre y foto
        # Inicializar todas las variables con valores vacíos
        nombres = [""] * 10
        imagenes = [""] * 10

        # Asignar valores desde la tupla fotos_filma
        for i, (nombre, imagen) in enumerate(fotos_filma[:10]):
            nombres[i] = nombre
            imagenes[i] = imagen

        # Desempaquetar valores en variables explícitas
        n_ac1, n_ac2, n_ac3, n_ac4, n_ac5, n_ac6, n_ac7, n_ac8, n_ac9, n_ac10 = nombres
        ac1, ac2, ac3, ac4, ac5, ac6, ac7, ac8, ac9, ac10 = imagenes
        
############################################################################################################ 
    else:
        sinopsis = año
    salta_cajon = int(saltar)
    
    #Cuando salta_cajon es 1 y respuesta = 0 va directamente a darte la pelicula seccion hecha para cine kinki
    if salta_cajon == 1:
        respuesta = 0
        if any(substring in trailer for substring in ["duffyou", "moestv", "imdb", "vidhidepre"]) and url == "url":            
            respuesta = 1
            #xbmcgui.Dialog().ok("paso 1/4", "respuesta = 1")
    # Determinar la función de traducción de ruta adecuada según la versión de Kodi
    kodi_version = xbmc.getInfoLabel('System.BuildVersion')
    if kodi_version.startswith('19'):
        from xbmc import translatePath as variacion_translatePath
        db_name = "MyVideos119.db"
    elif int(kodi_version.split('.')[0]) >= 20:
        from xbmcvfs import translatePath as variacion_translatePath
        db_name = "MyVideos121.db"
    else:
        raise RuntimeError("Versión de Kodi no compatible")
    
    
    ruta_especial_kodi = xbmcvfs.translatePath("special://database/").encode("utf-8").decode("utf-8")        
    nombre_db = db_name
    ruta_completa_db = os.path.join(ruta_especial_kodi, nombre_db)
    #xbmcgui.Dialog().textviewer("ruta", str(ruta_completa_db))
    # Conecta con la base de datos SQLite
    conexion = sqlite3.connect(ruta_completa_db)
    cursor = conexion.cursor()
    #xbmc.log(str(cursor), xbmc.LOGINFO)
    #xbmcgui.Dialog().textviewer("ruta", str(cursor))
    try:
        # Consulta para obtener todos los datos de la columna strFilename de la tabla files
        cursor.execute("SELECT idFile, strFilename FROM files;")
        resultados = cursor.fetchall()
        
        # Variable para verificar si se encontraron datos
        datos_encontrados = False

        # Imprime los resultados en el log de Kodi
        for resultado in resultados:
            decoded_str_filename = urllib.parse.unquote(resultado[1])  # Decodificar la cadena
            #xbmc.log(f"ID: {resultado[0]}, strFilename: {decoded_str_filename}", xbmc.LOGINFO)
            
            
            if url in decoded_str_filename:
                # Se encontró la URL en el strFilename. Ahora, consultamos la tabla bookmark
                cursor.execute("SELECT idBookmark FROM bookmark WHERE idFile = ?;", (resultado[0],))
                bookmark_resultado = cursor.fetchone()

                if bookmark_resultado:
                    #xbmcgui.Dialog().ok("BINGO!!!!", f"Se encontró la URL en el strFilename. ID: {resultado[0]}\nID Bookmark: {bookmark_resultado[0]}")
                    salta_cajon = 1
                    respuesta = 0
                    if any(substring in trailer for substring in ["duffyou", "moestv", "imdb", "vidhidepre"]) and url == "url":
                        respuesta = 1
                        #xbmcgui.Dialog().ok("paso 2/4", "seguimos insistiendo en respuesta = 1")
                    conexion.close()
                #else:
                    #xbmcgui.Dialog().ok("BINGO!!!!", f"Se encontró la URL en el strFilename. ID: {resultado[0]}\nNo hay Bookmark asociado.")

                #datos_encontrados = True

        # Muestra el mensaje adecuado en el diálogo de Kodi
        #if not datos_encontrados:
            #xbmcgui.Dialog().ok("Datos encontrados.", "NINGUNO")

    except sqlite3.Error as e:
        xbmc.log(f"Error al consultar la base de datos: {e}", xbmc.LOGERROR)

    finally:
        # Cierra la conexión con la base de datos
        if conexion:
            conexion.close()
    #xbmcgui.Dialog().textviewer("ruta", str(cursor))
    

    #xbmcgui.Dialog().ok("ruta", str(salta_cajon))
    if salta_cajon == 0:
        if url.startswith('Estreno:'):
            dialog = xbmcgui.Dialog()
            respuesta = dialog.select('Próximamente......', [f'                                                        [COLOR pink][B]   {url}[/COLOR][/B]  ', '                                    <<  [COLOR green][B]Ver trailer[/B][/COLOR]  >>'])
        else:
            if sinopsis == "":
                dialog = xbmcgui.Dialog()
                respuesta = dialog.select('¿ Qué eliges ver ?                                                            ', ['                                <<<  [COLOR green][B]Ver película[/B][/COLOR]  >>>', '                                    <<  [COLOR green][B]Ver tráiler[/B][/COLOR]  >>'])
            else:
                if 'estreno' in url:                                
                    fecha_estreno = ranking(titulo, año, es_estreno=True)
                    #xbmcgui.Dialog().ok("paso 1/4", f'La fecha de estreno es esta :{fecha_estreno} debes de verla a partir de esa fecha')
                mostrar_reparto = len(fotos_filma) > 0
                
                class CustomDialog(xbmcgui.WindowXMLDialog):
                    
                    def __init__(self, *args, **kwargs):
                        super(CustomDialog, self).__init__(*args, **kwargs)
                        # Guardamos el valor que calculamos antes (True o False)
                        self.mostrar_reparto = kwargs.get('mostrar_reparto', False)
                        self.puntuacion = kwargs.get('puntuacion', 'puntuacion no disponible')
                        self.sinopsis = kwargs.get('sinopsis', 'Sinopsis no disponible')
                        self.N_ac1 = kwargs.get('N_ac1', 'N_ac1 no disponible')
                        self.N_ac2 = kwargs.get('N_ac2', 'N_ac2 no disponible')
                        self.N_ac3 = kwargs.get('N_ac3', 'N_ac3 no disponible')
                        self.N_ac4 = kwargs.get('N_ac4', 'N_ac4 no disponible')
                        self.N_ac5 = kwargs.get('N_ac5', 'N_ac5 no disponible')
                        self.N_ac6 = kwargs.get('N_ac6', 'N_ac6 no disponible')
                        self.N_ac7 = kwargs.get('N_ac7', 'N_ac7 no disponible')
                        self.N_ac8 = kwargs.get('N_ac8', 'N_ac8 no disponible')
                        self.N_ac9 = kwargs.get('N_ac9', 'N_ac9 no disponible')
                        self.N_ac10 = kwargs.get('N_ac10', 'N_ac10 no disponible')
                        self.foto = kwargs.get('foto', 'foto no disponible')
                        self.foto_ac1 = kwargs.get('foto_ac1', 'foto_ac1 no disponible')
                        self.foto_ac2 = kwargs.get('foto_ac2', 'foto_ac2 no disponible')
                        self.foto_ac3 = kwargs.get('foto_ac3', 'foto_ac3 no disponible')
                        self.foto_ac4 = kwargs.get('foto_ac4', 'foto_ac4 no disponible')
                        self.foto_ac5 = kwargs.get('foto_ac5', 'foto_ac5 no disponible')
                        self.foto_ac6 = kwargs.get('foto_ac6', 'foto_ac6 no disponible')
                        self.foto_ac7 = kwargs.get('foto_ac7', 'foto_ac7 no disponible')
                        self.foto_ac8 = kwargs.get('foto_ac8', 'foto_ac8 no disponible')
                        self.foto_ac9 = kwargs.get('foto_ac9', 'foto_ac9 no disponible')
                        self.foto_ac10 = kwargs.get('foto_ac10', 'foto_ac10 no disponible')
                        self.button_label = kwargs.get('button_label', 'Python')
                        self.button_label2 = kwargs.get('button_label2', 'Python2')
                        self.respuesta = None

                    def onInit(self):
                        try:
                            # Si mostrar_reparto es True, enviamos "true" al XML, si no "false"
                            valor_xml = "true" if self.mostrar_reparto else "false"
                            self.setProperty('hay_reparto', valor_xml)
                            self.getControl(200).setImage(self.foto)
                            self.getControl(201).setImage(self.foto_ac1)
                            xbmc.log(f"Setting CurrentActor to: {self.N_ac1}", xbmc.LOGINFO)  # Log para depurar
                            xbmcgui.Window().setProperty("CurrentActor", self.N_ac1)  # Se establece la propiedad directamente
                            self.getControl(202).setImage(self.foto_ac2)
                            self.getControl(203).setImage(self.foto_ac3)
                            self.getControl(204).setImage(self.foto_ac4)
                            self.getControl(205).setImage(self.foto_ac5)
                            self.getControl(206).setImage(self.foto_ac6)
                            self.getControl(207).setImage(self.foto_ac7)
                            self.getControl(208).setImage(self.foto_ac8)
                            self.getControl(209).setImage(self.foto_ac9)
                            self.getControl(210).setImage(self.foto_ac10)
                            self.getControl(101).setLabel(self.puntuacion)
                            self.getControl(100).setText(self.sinopsis)
                            self.getControl(301).setLabel(self.N_ac1)
                            self.getControl(302).setLabel(self.N_ac2)
                            self.getControl(303).setLabel(self.N_ac3)
                            self.getControl(304).setLabel(self.N_ac4)
                            self.getControl(305).setLabel(self.N_ac5)
                            self.getControl(306).setLabel(self.N_ac6)
                            self.getControl(307).setLabel(self.N_ac7)
                            self.getControl(308).setLabel(self.N_ac8)
                            self.getControl(309).setLabel(self.N_ac9)
                            self.getControl(310).setLabel(self.N_ac10)
                            self.getControl(1).setLabel(self.button_label)
                            self.getControl(2).setLabel(self.button_label2)
                            # Aquí puedes configurar los controles si es necesario
                        except Exception as e:
                            xbmcgui.Dialog().textviewer("Error en onInit:", f'{str(e)}')
                            xbmc.log(f"Error en onInit: {str(e)}", xbmc.LOGERROR)
                    
                    def onClick(self, controlId):
                        if controlId == 10:  # El ID del botón "X"
                            self.close()  # Cierra el diálogo
                            
                        elif controlId == 1:
                            self.respuesta = 0
                            self.close()
                        elif controlId == 2:
                            self.respuesta = 1
                            self.close()

                    def getRespuesta(self):
                        return self.respuesta

                # Obtener ruta absoluta para el archivo XML
                addon = xbmcaddon.Addon()
                direccion = addon.getAddonInfo('path')

                # Crear y mostrar el diálogo personalizado
                if 'estreno' in url:                
                    color_titulo = 'red'
                else:
                    color_titulo = 'orange'
                    
                dialog = CustomDialog('dialog_custom.xml', direccion, 'skin.xonfluence',
                mostrar_reparto = mostrar_reparto,
                foto = f'{foto}', foto_ac1 = f'{ac1}', 
                foto_ac2 = f'{ac2}', 
                foto_ac3 = f'{ac3}', 
                foto_ac4 = f'{ac4}', 
                foto_ac5 = f'{ac5}', 
                foto_ac6 = f'{ac6}', 
                foto_ac7 = f'{ac7}', 
                foto_ac8 = f'{ac8}', 
                foto_ac9 = f'{ac9}', 
                foto_ac10 = f'{ac10}', 
                N_ac1=f'{n_ac1}',
                N_ac2=f'{n_ac2}',
                N_ac3=f'{n_ac3}',
                N_ac4=f'{n_ac4}',
                N_ac5=f'{n_ac5}',
                N_ac6=f'{n_ac6}',
                N_ac7=f'{n_ac7}',
                N_ac8=f'{n_ac8}',
                N_ac9=f'{n_ac9}',
                N_ac10=f'{n_ac10}',
                puntuacion=f"{puntuacion_pelicula}", 
                sinopsis=f"{sinopsis}", 
                button_label=f"[COLOR {color_titulo}][B]{titulo}[/B][/COLOR]" if color_titulo == 'orange' else f"[COLOR {color_titulo}][B]{titulo}[/B][/COLOR] [COLOR pink]El estreno será el {fecha_estreno}[/COLOR]", 
                button_label2="[B][COLOR red]-------[/COLOR][/B]" if trailer == "" or ".com/v" in trailer else "[B]Tráiler[/B]")
                dialog.doModal()

                # Recuperar la respuesta después de que el diálogo se haya cerrado
                respuesta = dialog.getRespuesta()
                #xbmc.log(f"Respuesta del diálogo: {respuesta}", xbmc.LOGDEBUG)
                del dialog
            
                ##dialog = xbmcgui.Dialog()
                ##respuesta = dialog.select('¿ Qué eliges ver ?                                                            ', ['                                <<<  [COLOR green][B]Ver película[/B][/COLOR]  >>>', '                                    <<  [COLOR green][B]Ver tráiler[/B][/COLOR]  >>', '[COLOR orange][B]                                            Sinopsis[/B][/COLOR]'])
       
    if respuesta in [-1, None]:
        cancelar_totalmente()
        
    elif respuesta == 0: 
        rojo = []
        urlfija = url
        seleccionada = ''
        if not "//" in url and not ".com" in url:
            url_final = urlsolve(url)
            return url_final
        #xbmcgui.Dialog().ok("aqui", f'{url}')    
        if any(substring in url for substring in ["vidhide", "mivalyo", "ryderjet", "wish", "dumbalag", "iplayerhls", "filemoon", "upstream", "bigwarp", "vembed", "palantir", "com/?"]):
            
            #xbmcgui.Dialog().ok("dentro de petra.cajon", str(url))
            #xbmc.log(f"com/%3F {url}.", xbmc.LOGINFO)
            if "streamwish" in url:
                url = url.replace("streamwish.to/", "yuguaab.com/")
            '''if "dhtpre" in url:
                url = url.replace("dhtpre.com/f", "mivalyo.com/file")
            url = url.replace("_", "")'''
            #xbmcgui.Dialog().ok("aqui", f'{url}')           
            if titulo != "":
                while True:
                    url2 = 'https://dl.dropbox.com/scl/fi/uq3zbn24v6wxzwrjqs3mb/lipe.html?rlkey=qjkiqb0l71sootb8k3qe4ryu7&st=0hcgtw4h&dl=0' 
                    #xbmc.log(url, xbmc.LOGINFO)            
                    headers = {'User-Agent': 'iPad'}
                    response = requests.get(url2, headers=headers)
                    html_content = response.text
                    
                    nombre_buscado = titulo
                    # Buscar si el nombre existe y capturar el contenido del link correspondiente
                    pattern = rf'nombre="{re.escape(nombre_buscado)}".*?link=\[([^\]]+)\]'
                    
                    match = re.search(pattern, html_content, re.DOTALL)
                    #xbmcgui.Dialog().ok("titulo coincide", str(sys.version))
                    #nombre_capturado = match.group(1)
                    #xbmc.log(f"URL seleccionada: {match2}", xbmc.LOGINFO)
                    #
                    
                    if match:                        
                        # Extraer las URLs asociadas al nombre
                        urls_raw = match.group(1)                   
                                       # Contenido entre corchetes
                        urls = [url2.strip() for url2 in urls_raw.split(",")]
                        urls.insert(0, urlfija)
                        
                        ###opciones = [f"[COLOR red]{urlparse(url).netloc.split('.')[0]}[/COLOR]" if url in rojo else urlparse(url).netloc.split('.')[0].replace('www', 'Torrent') for url in urls]
                        opciones = []
                        for url in urls:
                            #xbmcgui.Dialog().ok("url", f"{url}")
                            
                            if url in rojo:
                                opciones.append(f"[COLOR red]{urlparse(url).netloc.split('.')[0]}[/COLOR]")
                            else:
                                original_domain = urlparse(url).netloc.split('.')[0]
                                modified_url = original_domain.replace('www', 'Torrent').replace('Torrent28', 'Torrent')
                                if "com/?" in url:
                                    modified_url = "LiveVideo"
                                if modified_url == "":
                                    #xbmcgui.Dialog().ok("a ver", f"paso1  {url}")
                                    modified_url = "magnet"
                                if 'Torrent' in modified_url or 'plugin' in modified_url or 'magnet' in modified_url or 'LiveVideo' in modified_url:
                                    match = re.search(r'(BluRay-720p|BluRay-1080p|MicroHD|4K|BDremux|4k|plugin|magnet|com/\?|WEB-DL%201080p)', url)
                                    
                                    if match:
                                        if modified_url == "LiveVideo":
                                            opciones.append(f'[COLOR olive][B]{modified_url}[/B][/COLOR]')
                                        if modified_url == "plugin":
                                            modified_url = "Varios link"
                                            opciones.append(f'[COLOR violet]{modified_url}[/COLOR]')
                                        if modified_url == "magnet": 
                                            modified_url = "MagNet"
                                            opciones.append(f'[COLOR violet]{modified_url}[/COLOR]')
                                        if modified_url == "Torrent":
                                            opciones.append(f'[COLOR violet]{match.group(0)}[/COLOR]'.replace("%20"," "))
                                    else:
                                        opciones.append(modified_url)
                                else:
                                    
                                    opciones.append(modified_url)
                        #xbmc.log(f"URL seleccionada: {opciones}", xbmc.LOGINFO)       
                        #xbmcgui.Dialog().ok("segundo", "log")
                        opciones = [
    item.replace("Varios link plugin", "Varios link") if "Varios link plugin" in item else item
    for item in opciones
]
                            
                        dialog = xbmcgui.Dialog()
                        opcion = dialog.select(f"Enlaces para la película:[COLOR green] {titulo}[/COLOR]", opciones)  # Mostrar lista de URLs
                        
                        if opcion != -1:  # Si se selecciona una opción
                            seleccionada = urls[opcion]
                            #xbmcgui.Dialog().ok("url seleccionada", str(seleccionada))
                            url = seleccionada
                            if "streamwish" in url:
                                url = url.replace("streamwish.to/", "dumbalag.com/")
                            url = url.replace("_", "")
                            #xbmc.log(f"URL seleccionada: {seleccionada}", xbmc.LOGINFO)
                            #xbmcgui.Dialog().notification("URL Seleccionada", seleccionada, xbmcgui.NOTIFICATION_INFO)
                        else:
                            ###CON LAS 5 LINEAS LE DECIMOS A KODI QUE CIERRE EL CUADRO DE DIALOGO SIN EMITIR ERRORES
                            cancelar_totalmente()
                        if "plugin" in url:
                            break    
                        if "torrent" in url or "magnet" in url:
                            break
                        #xbmc.log(com_url, xbmc.LOGINFO)                 
                            
                        com_url = texto_url(url)                        
                        if com_url is None:                             
                            url_final = "2701"
                            
                        elif any(substring in seleccionada for substring in ['rapidgator', 'streamsilk', 'vembed']) and com_url != None:                                                    
                            import resolveurl                                            
                            resolved_url = resolveurl.resolve(seleccionada) 
                            if not resolved_url:
                                #para que entre por la condicion 2701
                                url_final = "2701"                               
                            else:                        
                                url_final = resolved_url
                                break
                                
                        elif "bigwarp" in url and com_url != None:                            
                            regex = '(?s)sources:\s*\[{file:"(.*?)"'            
                            url_final = url_con_cabeza(url, regex)
                            if url_final != "2701":
                                break
                            
                        elif "filemoon" in url and com_url != None:                  
                            url_final = resolve_vidhide(com_url)
                            if url_final != "2701":
                                break                            
                        else: 
                            
                            url_final = resolve_vidhide(com_url)
                            break
                        
                        if url_final == "2701":                     
                            if seleccionada not in rojo:                       
                                rojo.append(seleccionada)                     
                                                      
                    else:
                        #xbmcgui.Dialog().ok("estará", f"No esta {titulo}")
                        
                        if 'estreno' in url:
                            break
                        if "plugin" in url or "com/?" in url:
                            break
                        com_url = texto_url(url)
                        url_final = resolve_vidhide(com_url)
                        return url_final
                        
            else:
                if "plugin" in url:
                    palantir_p(url)
                else:
                    com_url = texto_url(url)
                    url_final = resolve_vidhide(com_url)
                    return url_final
            if "torrent" in url or "magnet" in url:                
                #xbmc.log(url, xbmc.LOGINFO)
                #xbmcgui.Dialog().ok("estará", 'vete al log')
                return url
                ###item = xbmcgui.ListItem(path=f"plugin://plugin.video.elementum/play?uri={url}")
                ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
                ###sys.exit()
            if "plugin" in url:
                palantir_p(url)
                #xbmcgui.Dialog().ok("estará", 'vete al log')
                #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))
                sys.exit()
            if "com/?" in url:
                url = url.replace('com/?', '')            
                return urlsolve(url)
            
        elif "com/?" in url:
            url = url.replace('com/?', '')            
            return urlsolve(url)
            
        elif "palantir" in url:
            palantir_p(url)
            '''
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')           
                ##EJECUTA EL LINK DE PALANTIR
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))
            control_bucle = 0
            # Sistema de espera infinita
            player = xbmc.Player()
            monitor = xbmc.Monitor() 
            xbmc.executebuiltin('Dialog.Close(12002)')            
            time.sleep(7)
            if player.isPlaying():                
                while not monitor.abortRequested():
                    #xbmcgui.Dialog().notification('dentro del bucle', 'lol', time=1000, sound=False)
                    # 1. Usuario reproduce algo
                    if player.isPlaying():
                        # Esperar a que termine usuario da STOP
                        while player.isPlaying() and not monitor.abortRequested():           
                            monitor.waitForAbort(0.1)
                    if xbmc.getCondVisibility("Window.IsActive(12000)"):             
                        xbmc.executebuiltin('Dialog.Close(12000)')
                        control_bucle = 1
                        break 
                    if xbmc.getCondVisibility('Control.IsVisible(50)') or xbmc.getCondVisibility('Window.IsVisible(Home)'):            
                        control_bucle = 2
                        break
                    monitor.waitForAbort(0.4)       
            if control_bucle == 1:
                xbmcgui.Dialog().notification('cartel de opciones', 'Estoy fuera del blucle', time=2000, sound=False)
            if control_bucle == 2:
                xbmcgui.Dialog().notification('Back', 'Estoy fuera del blucle', time=2000, sound=False)
                
            
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(12002)')
            sys.exit()'''
            
        elif 'estreno' in url:
            item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0")        
            xbmc.executebuiltin('Dialog.Close(all, true)')
            xbmcplugin.setResolvedUrl(HANDLE, True, item_silencioso)    
            xbmc.sleep(100)
            xbmc.executebuiltin('Dialog.Close(all, true)')            
            
            
            #xbmcgui.Dialog().ok("estoy estreno", 'a ver que papa')
             # Ruta local al icono en la misma carpeta que tu script
            addon_icon_path = os.path.join(variacion_translatePath('special://home/addons/plugin.video.play'), 'icon.png')
            # Convierte la ruta local a una ruta special://
            icon_path = variacion_translatePath(addon_icon_path)

            # Muestra la notificación con la ruta especial
            xbmcgui.Dialog().notification('[COLOR green]                  No seas impaciente[/COLOR]', f'    La fecha del estreno es: [COLOR pink]{fecha_estreno}[/COLOR]', icon=icon_path, time=6000)                
            sys.exit()
        
            
    elif respuesta == 1:
        #xbmcgui.Dialog().ok("estoy en respuesta 1", trailer)
        if trailer == "" or ".com/v" in trailer:            
            cancelar_totalmente()
        elif "?" in trailer:
            item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0")        
            xbmc.executebuiltin('Dialog.Close(all, true)')
            xbmcplugin.setResolvedUrl(HANDLE, True, item_silencioso)    
            xbmc.sleep(100)
            xbmc.executebuiltin('Dialog.Close(all, true)')
            trailer = trailer.replace('?', '')
            #xbmcgui.Dialog().ok("estoy imbd", trailer)
            resolve = Youtube_Video(trailer)
            return resolve            
        else:
            #RESUELVE LOS TRILER DE FICHER
            trailer_final = urlsolve (trailer)            
            return trailer_final
    elif respuesta == 2: 
        xbmcgui.Dialog().textviewer("Sinopsis", f'{sinopsis}') 
        #xbmc.executebuiltin('Dialog.Close(all, true)')
        #cajon(trailer, url, saltar, sinopsis)
        sys.exit()#con esto se para dentro de la funcion y no vuelve al xml
                    
''''''                    