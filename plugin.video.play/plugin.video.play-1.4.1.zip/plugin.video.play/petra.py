import base64
import xbmcgui
import xbmc
import xbmcplugin
import xbmcaddon
import ast
import xbmcvfs
from bs4 import BeautifulSoup
import requests
import re
from urllib.parse import quote
import inspect
import sys
import time
import threading
import os
import html
import sqlite3
import urllib
from urllib.parse import urlparse
import unicodedata
import json
import datetime
html_content_errores = ''
HEADERS = {
    "android": {
        "User-Agent": "Mozilla/5.0 (Linux; Android 9; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    },
    "desktop": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    },
}
TRANSLATEPATH = xbmcvfs.translatePath
def futbol(canal, url_clean):
    
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0"
    headers = {
        "User-Agent": f"{ua}"        
    }    
    response = requests.post(canal, headers=headers)
    html_content = response.text 
    regex = r'iframe src=["\'](.*?)["\']'
    match = re.search(regex, html_content)
    iframe = match.group(1)
    #xbmc.log("TEXTO DE LA URL:  " + f'{html_content}', xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("Valor de Alldebrid API", f'{iframe}')
    
    # ---------------------------------------------------------
    # BLOQUE NUEVO: CALCULAR LA HORA
    # ---------------------------------------------------------
    try:
        # Extraemos el número e= (ej: 1710800000)
        timestamp_expira = int(url_clean.split('e=')[-1].split('&')[0])
        # Tiempo actual en segundos (Universal)
        ahora = int(time.time())
        
        minutos_faltantes = (timestamp_expira - ahora) // 60
        
        if minutos_faltantes > 0:
            aviso = f"{minutos_faltantes}"
        else:
            aviso = "¡EL ENLACE YA CADUCÓ!"
    except Exception as e:
        aviso = "Error: URL sin parámetro de tiempo"
        minutos_faltantes = -1
    # CORRECCIÓN DE LA NOTIFICACIÓN: El 5000 va DENTRO del paréntesis
    xbmc.executebuiltin(f'Notification(INFO, Tienes {aviso} Min, 5000)')
    # ---------------------------------------------------------
    # TU CÓDIGO QUE YA FUNCIONA (SIN CAMBIOS)
    # ---------------------------------------------------------
    
    ref = f'{iframe}'           
    org = f'{iframe}'
           
    headers = f"User-Agent={ua}&Referer={ref}&Origin={org}"
    
    url_montada = f"{url_clean}&visionado={int(time.time())}|{headers}"

    # Primero: Liberamos el addon
    handle = int(sys.argv[1])
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(handle, True, item_silencioso)    
    
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all, true)')
    xbmc.sleep(100)     
    
    # Segundo: Lanzamos el video
    comando = f'PlayMedia("{url_montada}")'
    xbmc.executebuiltin(comando)
    sys.exit() 
    
def cancelar_totalmente():
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)    
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
    sys.exit()
    #xbmc.sleep(100) # Pequeña pausa para dejar que Kodi procese el setResolved
    #xbmc.executebuiltin('Dialog.Close(okdialog)') 
    
def Limpiar_BD():
    #borrar un fichero en concreto
    #ruta_completa = TRANSLATEPATH("special://database/Textures13.db")
    #xbmcvfs.delete(ruta_completa)
    ##ESTO ES TB UNA VENTANA DE NOTIFICACIONES
    ##xbmc.executebuiltin('ActivateWindow(10107)')##ojo esta ventana es de notificaciones
    
    # Paso 1: Limpiar LOS .ZIP
    addon_data = xbmcvfs.translatePath("special://home/addons/packages/")    
    files = xbmcvfs.listdir(addon_data)[1]
    #xbmc.log("TEXTO DE LA URL:  " + f'{files}', xbmc.LOGINFO)
    for f in files:        
        path = os.path.join(addon_data, f)
        if xbmcvfs.exists(path):            
            xbmcvfs.delete(path)
    # Paso 2: Limpiar LIBRERIA        
    xbmc.executebuiltin("CleanLibrary(video, true)")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    xbmc.executebuiltin('Dialog.Close(12002)')
    sys.exit()    
def saber_numero_carpeta(sindatos):
    #prueba = 13782380
    #series = 17082018
    url = "https://1fichier.com/console/get_folder_content.pl?id=17082018"
    ##########  no funciona por que tienes que iniciar sesion pero para pedir el id de la carpeta abre navegador inicia sesion y clik a esa url es de la id de series ###########
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    
    response = requests.post(url, headers=headers)
    html_content = response.text 
    

def get_alldebrid_apikey_regex():
    # --- CONFIGURACIÓN ---
    ADDON_ID = 'plugin.video.palantir3' 
    # ---------------------    
    try:
        # Creamos la conexión con el addon Palantir 3
        addon = xbmcaddon.Addon(ADDON_ID)
        
        # --- 1. OBTENCIÓN DE LA API KEY ---
        # Leemos el valor del ajuste 'Alldebrid_apikey'
        api_key = addon.getSetting('Alldebrid_apikey')
        
        # Mostramos un mensaje en pantalla con el valor obtenido
        #xbmcgui.Dialog().ok("Valor de Alldebrid API", f'{api_key}')
        return api_key
    
    except Exception as e:
        # Si el addon no está instalado o hay error, no hace nada
        pass
    
        
def urlsolve (url):
    #xbmcgui.Dialog().ok("entra", 'Si')
    # 1. Preparación de la URL de origen
    original_url = f"https://1fichier.com/?{url}"
    
    # 2. Obtener la API Key (Asegúrate de que esta función sea rápida)
    apikey = get_alldebrid_apikey_regex()
    
    # 3. Configuración de la petición mediante diccionario de parámetros
    api_endpoint = "https://api.alldebrid.com/v4/link/unlock"
    payload = {
        'agent': 'Palantir3',
        'apikey': apikey,
        'link': original_url
    }
    
    try:
        # Realizamos la petición (requests gestiona los headers y el encoding)
        response = requests.get(api_endpoint, params=payload, timeout=20)
        response.raise_for_status() # Lanza error si la web no responde (404, 500, etc)
        
        # 4. Parseo directo de JSON (Mucho más rápido que regex)
        data = response.json()
        
        if data.get('status') == 'success':
            # Extraemos el link directo
            return data['data']['link']
        else:
            # Si Alldebrid devuelve un error (ej: apikey inválida o link caído)
            error_msg = data.get('error', {}).get('message', 'Error desconocido')
            print(f"Error de AllDebrid: {error_msg}")
            return None

    except Exception as e:
        print(f"Error en la petición: {e}")
        return None
       
def rev_pal (id):
    url = f'https://api.alldebrid.com/v4/link/unlock?agent=Palantir3&apikey=6F2vxJcLC2vHwRhgc3ym&link={id}'
    respuesta = str(Texto_url(url))
    regex = 'link":"(.*?)"'
    match = re.search(regex, respuesta)
    url = match.group(1)
    url_p1 = urllib.parse.unquote(url)
    url_final = str(url_p1).replace("\\", "").replace(" ", "")
    return url_final
    xbmc.log("TEXTO DE LA URL:  " + url_final, xbmc.LOGINFO)
    xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
def carpeta_ficher (id):
    url = "https://api.1fichier.com/v1/file/ls.cgi"
    headers = {
        "Authorization": "Bearer gkYeVeslP_jqLfvMqV_g-2DSkbCqfFb5",
        "Content-Type": "application/json"
    }
    data = {
        "folder_id": f'{id}'
    }
    response = requests.post(url, headers=headers, json=data)
    html_content = response.text 
    #xbmc.log("TEXTO DE LA URL:  " + html_content, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    # Extraer todos los nombres de archivo
    nombres = []
    patron_nombre = r'"filename":"(.*?)"'
    nombres = re.findall(patron_nombre, html_content)
    
    # Extraer todas las URLs
    urls = []
    patron_url = r'"url":"(.*?)"'
    urls = re.findall(patron_url, html_content)
    
    # Emparejar nombres con URLs
    archivos_emparejados = []
    for i in range(len(nombres)):
        nombre_limpio = re.sub(r'\.(mp4|mkv|avi|mov|wmv|flv|webm)$', '', nombres[i])
        archivos_emparejados.extend(['nombre', nombre_limpio, 'url', urls[i]])
    #xbmc.log("TEXTO DE LA URL:  " + str(archivos_emparejados), xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    
    # Definimos la ruta directamente usando el protocolo de Kodi
    ruta_resolveurl = "special://profile/addon_data/script.module.resolveurl/"
    settings_path = ruta_resolveurl + "settings.xml"

    # Comprobamos si la carpeta existe
    if xbmcvfs.exists(ruta_resolveurl):
        # Comprobamos si el archivo settings.xml existe
        if not xbmcvfs.exists(settings_path): 
            xbmcgui.Dialog().ok("Atención por favor!!:", "Si quieres ver el contenido, primero tienes que emparejar tu cuenta de ALLDEBRID con Play.")
            # Si no existe el xml, ejecutamos el plugin
            url_plugin = "plugin://script.module.resolveurl/?mode=auth_ad"
            xbmc.executebuiltin(f'RunPlugin({url_plugin})')
    else:
        xbmcgui.Dialog().ok("Atención por favor!!:", "Si quieres ver el contenido, primero tienes que emparejar tu cuenta de ALLDEBRID con Play.")
        url_plugin = "plugin://script.module.resolveurl/?mode=auth_ad"
        xbmc.executebuiltin(f'RunPlugin({url_plugin})')
        #xbmcgui.Dialog().ok("Resultado:", "No existe la carpeta de configuración de 'resolveurl'")
    #xbmc.log(f"DEBUG: El contenido actual es: {xbmc.getInfoLabel('Container.Content')}", xbmc.LOGINFO)   
    return archivos_emparejados
def Tv(url):
    #xbmcgui.Dialog().ok("torrent", url)
    item = xbmcgui.ListItem(path=f"{url}")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def Trailer_IMBD(url):
    regex = '(?s)"value":"\d{3,4}.*?url":"(.*?)"'
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'}
    response = requests.get(url, headers=headers)
    html_content = response.text 
    match = re.search(regex, html_content)
    url = match.group(1)
    url_limpia = re.sub(r"\\[^A-Z]*", "&", url)
    #xbmc.log("TEXTO DE LA URL:  " + url_limpia, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    return url_limpia
def Texto_url(url):    
    #regex = "href='([^']*\.torrent[^']*)'"
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'
}
    response = requests.get(url, headers=headers, verify=False, timeout=10)
    html_content = response.text 
    

    xbmc.log("TEXTO DE LA URL:  " + html_content, xbmc.LOGINFO)
    xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    
    
def BIG(url):
    
    #regex = "href='([^']*\.torrent[^']*)'"
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
    'referer': 'https://www10.playdede.link/pelicula/sin_instrucciones_1238200',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
}
    response = requests.get(url, headers=headers)
    html_content = response.text
    html_content = html_content.replace('\x00', '')
    #xbmc.log("URL FINAL ES :  " + html_content, xbmc.LOGINFO)
    xbmcgui.Dialog().ok("vete al log", "Te esta esperando el log")
    
def torrent(url):
    #xbmc.log("URL FINAL ES :  " + url, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("torrent", url)
    regex = "href='(.*?)'"
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    match = re.search(regex, html_content)
    url = match.group(1)
    
    url = "https:" + url 
    
    item = xbmcgui.ListItem(path=f"plugin://plugin.video.elementum/play?uri={url}")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def torrent_di(url):    
    #xbmcgui.Dialog().ok("torrent", url)
    item = xbmcgui.ListItem(path=f"plugin://plugin.video.elementum/play?uri={url}")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def Favoritos_p(url): 
   #PRIMERO CERRAR CUADROS DE DIALOGOS IMPORTANTISIMO PARA QUE FUNCIONE BIEN
   item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
   xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
   xbmc.sleep(100)
   xbmc.executebuiltin('Dialog.Close(all)')
   #REPLICAR EXACTAMENTE COMO FAVORITOS    
   xbmc.executebuiltin(f'PlayMedia("{url}")')
   #LAS TRES LINEAS SIGUIENTES VAN UNIDAS PARA QUE NO SALGAN ERRORES POSTERIORES
   
                               
   sys.exit()
def vista_serie():
    xbmc.executebuiltin("Container.SetViewMode(515)") 

def Buscador_series_Pa(url):   
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
     
    
    
    url_base = "plugin://plugin.video.palantir3/?dmL0JXYuFmZcx1MylGduFGbhBnLvVGZpZnLul2Z1xGccx1cu9GZkFGXclGZvtEXcdmbp1WYvJFXcFGdhREcwFEXcZHVfNXdzFEXcNnclNXVcxlODdCI6ICdyFmbhZmIgwyJzVGbpZ2JgojI05WZ052bjJCIscyMyF2YzVnYnAiOi42bpR3YhJye9JyOx4Wa0FGbgUEVBxETPNEIvxWd0lGdgknYgIVREJ1TgkybsVHdpRHIscyclcCKgAFWFdURSlGIlJXZodHIsFmcl5WZH91cllmclN3X2BSTPJlRuxlccBCIn5Wa0Fmcgwybn9GbyFWZsNGIsIXZslWYyRHIs8mcl5WZnxSYhBXbs8WakVXYsIGZtRHLvRmbvZGLyVGdz9GcsQ3bsBHLhh2YlZGLvxWd0lGdgQ1QFxURTJCI6ICbxNnIgwyJdJ1TM90Qvs1cllmclNVXwAzNkZmZmZGIS9ETPN0WnAiOiQ3bsBnIgwCMgojIldWYwJCIscSXS9ETPN0Lb9Gb1RXrDTHIy9GUgACIg0FMwcDZmZmZmBiUPx0TDt1JgojIsVmYhxmIgwyJn5GcuIXYjNXdixFXhlGZl1GXcNXZjJXdvNXZyxFXzIXa05WYsFGcu8WZklmdu4WanVHbwxFXz52bkRWYcxVak92Scx1ZulWbh9mUcxVY0FGRwBXQcxldU91c1NXQcx1cyV2cVxFX6M0JgojIu92YpJCIsciZp"
    
    # Usamos Container.Update con "replace" para machacar el historial
    
    xbmc.executebuiltin(f'Container.Update("{url_base}",replace)')
    
    # 3. EL BUCLE CENTINELA (Vigilante)
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        # Consultamos qué hay en pantalla ahora mismo
        ruta_actual = xbmc.getInfoLabel('Container.FolderPath')
        
        # CONDICIÓN DE SALIDA: 
        # Si la ruta actual YA NO es la de los resultados de Palantir, 
        # es que el usuario ha dado a "Atrás"
        if ruta_actual == 'plugin://plugin.video.palantir3/':            
            # 5. LANZAR TU URL DE 'PLAY'
            # Redireccionamos a tu addon para limpiar la navegación
            url_play = "plugin://plugin.video.play/?dXJsPWh0dHBzJTNBJTJGJTJGZGwuZHJvcGJveC5jb20lMkZzJTJGNDkyeHRzbW45dnVodG5yJTJGU2VyaWVzLmh0bWwmbW9kZT0xJm5hbWU9JTVCQ09MT1Irb3JhbmdlcmVkJTVEJTVCQiU1RCUzQyU1QkNPTE9SK2dvbGQlNUQlM0MlNUIlMkZDT0xPUiU1RCUzQyU1QiUyRkNPTE9SJTVEK1NlcmllcyslNUJDT0xPUitvcmFuZ2VyZWQlNUQlM0UlNUJDT0xPUitnb2xkJTVEJTNFJTVCJTJGQ09MT1IlNUQlM0UlNUIlMkZCJTVEJTVCJTJGQ09MT1IlNUQmZmFuYXJ0PWh0dHBzJTNBJTJGJTJGZHJpdmUuZ29vZ2xlLmNvbSUyRnVjJTNGZXhwb3J0JTNEZG93bmxvYWQlMjZpZCUzRDFuVmNHVS1XZnhOU2xhdmVQVU43QlI0WHU3VzE1UjMzVQ="
            
            xbmc.executebuiltin(f'ReplaceWindow(10025, "{url_play}")')
            
            # Salimos del bucle
            break
        
        # Pequeño sueño para no quemar la CPU (vuelve a mirar cada 250ms)
        if monitor.waitForAbort(0.1):
            break
    
    sys.exit()   
def Buscador_Pelis_Pa(url):   
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
     
    
    
    url_base = "plugin://plugin.video.palantir3/?vUWbvh2LvoDbhl2YlB3cnAiOi42bjlmIgwyJml2ZuQnch5WYm9yMylGduFGbhBnLvVGZpZnLul2Z1xGcvMnbvRGZh9SZt9Gav8iOsFWajVGczdCI6ICdyFmbhZmIgwyJzVGbpZ2JgojI05WZ052bjJCIscyMyF2YzVnYnAiOi42bpR3YhJyeQfisTMulGdhxGIFRVQMx0TDBybsVHdpRHI5JGISVERS9EIp8Gb1RXa0BCLnMXJngCIQhVRHVkUpBSZyVGa3BSYsV3YpxWZQ91cpxWZw9ldg00TSZkbcJHXgASYpJ3bnVGdhNGIscmbpRXYyBCLvd2bsJXYlx2YgwiclxWahJHdgwybyVmbldGLhFGctxibvlGdhJXdkxiYk1GdsQWYklGbhNGLvlGZ1FGLvRmbvZGLyVGdz9GcsQ3bsBHLhh2YlZGLvxWd0lGdgQ1QFxURTJCI6ICbxNnIgwyJdJ1TM90Qvs1chxWdj16wsVGUdBDM3QmZmZmZgI1TM90QbdCI6ICdvxGciACLwAiOiU2ZhBnIgwyM1AiOiQ3cpxUblRXS0lWbpxmIgwyJdJ1TM90Qvs1bsVHdtOMdgI3bQBCIgASXwAzNkZmZmZGIS9ETPN0WnAiOiwWZiFGbiACLncmbw5ichN2c1J2LhlGZl12LzV2YyV3bzVmcvMjcpRnbhxWYw5yblRWa25ibpdWdsB3Lz52bkRWY"
    
    # Usamos Container.Update con "replace" para machacar el historial
    
    xbmc.executebuiltin(f'Container.Update("{url_base}",replace)')
    
    # 3. EL BUCLE CENTINELA (Vigilante)
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        # Consultamos qué hay en pantalla ahora mismo
        ruta_actual = xbmc.getInfoLabel('Container.FolderPath')
        
        # CONDICIÓN DE SALIDA: 
        # Si la ruta actual YA NO es la de los resultados de Palantir, 
        # es que el usuario ha dado a "Atrás"
        if ruta_actual == 'plugin://plugin.video.palantir3/':            
            # 5. LANZAR TU URL DE 'PLAY'
            # Redireccionamos a tu addon para limpiar la navegación
            url_play = "plugin://plugin.video.play/?dXJsPWh0dHBzJTNBJTJGJTJGZGwuZHJvcGJveC5jb20lMkZzJTJGZDRrMW9nODg5ZGhodWUzJTJGc2Fsb25fcGVsaWN1bGFzLmh0bWwmbW9kZT0xJm5hbWU9JTVCQ09MT1Irb3JhbmdlcmVkJTVEJTVCQiU1RCUzQyU1QkNPTE9SK2dvbGQlNUQlM0MlNUIlMkZDT0xPUiU1RCUzQyU1QiUyRkNPTE9SJTVEK1BlbCVDMyVBRGN1bGFzKyU1QkNPTE9SK29yYW5nZXJlZCU1RCUzRSU1QkNPTE9SK2dvbGQlNUQlM0UlNUIlMkZDT0xPUiU1RCUzRSU1QiUyRkIlNUQlNUIlMkZDT0xPUiU1RCZmYW5hcnQ9aHR0cHMlM0ElMkYlMkZkcml2ZS5nb29nbGUuY29tJTJGdWMlM0ZleHBvcnQlM0Rkb3dubG9hZCUyNmlkJTNEMW5WY0dVLVdmeE5TbGF2ZVBVTjdCUjRYdTdXMTVSMzNV"
            
            xbmc.executebuiltin(f'ReplaceWindow(10025, "{url_play}")')
            
            # Salimos del bucle
            break
        
        # Pequeño sueño para no quemar la CPU (vuelve a mirar cada 250ms)
        if monitor.waitForAbort(0.1):
            break
    
    sys.exit()
    xbmcgui.Dialog().notification('salir del bucle', 'lol', time=1000, sound=False)
    

   
def modo_escucha(url, desde_cajon=False):
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    
    xbmc.sleep(2000)
    ruta_de_entrada = xbmc.getInfoLabel("Container.FolderPath")
    TIEMPO_MAX_INACTIVIDAD = 30
    while not monitor.abortRequested():
        if xbmc.getGlobalIdleTime() > TIEMPO_MAX_INACTIVIDAD:
            # 1. Cerramos cualquier ventana de diálogo abierta (por si acaso)
            xbmc.executebuiltin('Dialog.Close(all)')
            # 2. Simulamos la pulsación de la tecla "Atrás"
            xbmc.executebuiltin('Action(Back)')
            # 3. Esperamos un momento para que Kodi procese el retroceso
            xbmc.sleep(500)
            return True
        if player.isPlaying():
            while player.isPlaying() and not monitor.abortRequested(): 
                monitor.waitForAbort(0.1)
            espera_boton_back_visible(url, 515)
            # --- SOLUCIÓN PARA QUITAR LA CAJA ---
            if desde_cajon:
                # 1. Esperamos un poco a que el reproductor se limpie
                xbmc.sleep(500) 
                
                # 2. Bucle de persistencia: Intentamos cerrar la caja durante 2 segundos
                for _ in range(10): 
                    # Comprobamos si la ventana 12000 O el diálogo de progreso están activos
                    if xbmc.getCondVisibility("Window.IsActive(12000)") or xbmc.getCondVisibility("Window.IsActive(progressdialog)"):
                        xbmc.executebuiltin('Dialog.Close(12000)')
                        xbmc.executebuiltin('Dialog.Close(all, true)') # Forzamos cierre total
                        break
                    monitor.waitForAbort(0.8) # Espera pequeña entre intentos
            espera_boton_back_visible(url, 515)
            
                

        # --- Lógica de Salida ---
        ruta_actual = xbmc.getInfoLabel("Container.FolderPath")
        if ruta_actual != ruta_de_entrada:
            if not player.isPlaying() and not ruta_actual.startswith(ruta_de_entrada):
                if xbmc.getCondVisibility('Control.IsVisible(508)') or xbmc.getCondVisibility('Control.IsVisible(50)'):
                    break

        if not xbmc.getCondVisibility("Window.IsActive(10025)"):
            break

        monitor.waitForAbort(0.5)
    
    return False
def cambiar_modo_de_vista(url, view_mode):
    
    xbmc.executebuiltin(f"Container.SetViewMode({view_mode})")
    #xbmcgui.Dialog().ok('Guardada', f'{view_mode}') 
        # Guardar la vista en la propiedad del contenedor para recordarla
    xbmcplugin.setProperty(int(sys.argv[1]), f"view_mode_{hash(url)}", str(f'{view_mode}'))
    return
def espera_boton_back_visible(url, SetViewMode):
    
    
    def cambiar_al_ver_lista(url, control_id, timeout=5):
        """Espera hasta que la lista sea visible y esté completamente cargada"""
        start_time = time.time()
        #xbmcgui.Dialog().ok('antes del bucle', f'{control_id}') 
        while time.time() - start_time < timeout:
                             
            if xbmc.getCondVisibility('Control.IsVisible(50)'):                
                xbmc.sleep(100)                
                #xbmcgui.Dialog().ok('a ver', url) 
                cambiar_modo_de_vista(url, control_id)
                return
            #if xbmc.getCondVisibility('Control.IsVisible(724)'):
                #cambiar_modo_de_vista(params, control_id)
                #return
            xbmc.sleep(10)  # Check cada 30ms
        
        # Backup después de 5 segundos
        #cambiar_modo_de_vista(url, control_id)

    # Uso:
    threading.Thread(target=cambiar_al_ver_lista, args=(url, f'{SetViewMode}')).start()    


def Favoritos_sv(url_raiz):
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
    xbmc.executebuiltin(f'ActivateWindow(10025,"{url_raiz}",return)')
    
    monitor = xbmc.Monitor()
    estado_actual = "" 
    # Tiempo máximo de inactividad permitido (60 segundos)
    TIEMPO_MAX_INACTIVIDAD = 32

    while not monitor.abortRequested():
        es_temporadas = xbmc.getCondVisibility("Container.Content(seasons)")
        es_episodios = xbmc.getCondVisibility("Container.Content(episodes)")
        # --- SEGURIDAD: SI EL USUARIO NO TOCA NADA EN 1 MINUTO, SALIMOS ---
        # xbmc.getGlobalIdleTime() devuelve el tiempo en segundos
        if xbmc.getGlobalIdleTime() > TIEMPO_MAX_INACTIVIDAD:
            # 1. Cerramos cualquier ventana de diálogo abierta (por si acaso)
            xbmc.executebuiltin('Dialog.Close(all)')
            # 2. Simulamos la pulsación de la tecla "Atrás"
            xbmc.executebuiltin('Action(Back)')
            # 3. Esperamos un momento para que Kodi procese el retroceso
            xbmc.sleep(500)
            
            break
        if xbmc.getCondVisibility('Control.IsVisible(50)'):
            
            # --- NIVEL A: TEMPORADAS ---
            if es_temporadas and estado_actual != "seasons":
                
                xbmc.executebuiltin("Container.SetViewMode(724)")
                estado_actual = "seasons"
                
            
            # --- NIVEL B: EPISODIOS ---
            elif es_episodios and estado_actual != "episodes":
                xbmc.executebuiltin("Container.SetViewMode(515)")
                estado_actual = "episodes"
                
                # Entramos en modo escucha
                fue_por_inactividad = modo_escucha(url_raiz, True)
                if fue_por_inactividad:
                    #xbmc.sleep(500)
                    while not monitor.abortRequested():
                        if xbmc.getCondVisibility('Control.IsVisible(50)'):
                            xbmc.sleep(100)
                            #xbmcgui.Dialog().ok("SISTEMA", "detectado modo vista 50.")
                            xbmc.executebuiltin("Container.SetViewMode(724)")
                            estado_actual = "seasons"
                            xbmc.sleep(10000)
                            
                            break
                else: 
                    while not monitor.abortRequested():  
                        if xbmc.getCondVisibility('Control.IsVisible(50)'):
                            xbmc.executebuiltin("Container.SetViewMode(724)")
                            break
                    
                #xbmcgui.Dialog().ok("SISTEMA", "de vuelta de modo_escucha")
                # --- AQUÍ ESTÁ EL TRUCO PARA LA VUELTA RÁPIDA ---
                # En cuanto el usuario da atrás y sale de modo_escucha, 
                # forzamos una comprobación ultra-rápida para poner el 724
                '''for _ in range(20): # Reintenta durante 2 segundos máximo
                    if xbmc.getCondVisibility("Container.Content(seasons)"):
                        xbmc.executebuiltin("Container.SetViewMode(724)")
                        estado_actual = "seasons"
                        break
                    xbmc.sleep(100) # Chequea cada 100ms'''
                # ------------------------------------------------

        # --- NIVEL C: SALIDA ---
        elif not es_temporadas and not es_episodios:
            if xbmc.getCondVisibility('Control.IsVisible(508)'):
                #Con esto se sabe en que Container.Content estas 
                #xbmc.log(f"DEBUG: El contenido actual es: {xbmc.getInfoLabel('Container.Content')}", xbmc.LOGINFO)
                break  

        if monitor.waitForAbort(0.5): # Bajamos a 0.2 para más sensibilidad
            break
            
    #xbmcgui.Dialog().ok("SISTEMA", "Bucle cerrado correctamente.")
    sys.exit()
    #xbmcgui.Dialog().ok("a ver", "palante")  
def Favoritos_s(url):
    item_silencioso = xbmcgui.ListItem(path="http://0.0.0.0") 
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item_silencioso)            
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all)')
    #xbmcgui.Dialog().ok("filemon", url) 

    xbmc.executebuiltin(f'ActivateWindow(10025,"{url}",return)')
    if "thecrew" in url:
        xbmc.executebuiltin("Container.SetViewMode(500)")
    elif "balandro" in url: 
        xbmc.executebuiltin("Container.SetViewMode(50)")
    else:
        encoded_url = urllib.parse.quote(url, safe='')
        url = 'url=' + encoded_url
        #xbmc.log("URL FINAL ES :  " + url, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("sale del bucle por:", f"{url}")
        #espera_boton_back_visible(url, 515)
        monitor = xbmc.Monitor()    
        # Bucle infinito hasta que se cumpla la condición
        # pero con 2 "salvavidas" para que no se quede colgado para siempre
        while not xbmc.getCondVisibility("Control.IsVisible(50)"):
            
            # SALVAVIDAS 1: Si el usuario cierra Kodi o el addon se detiene
            if monitor.abortRequested():
                return False
                
            # SALVAVIDAS 2: Si el usuario se cansa de esperar y da atrás (sale de la ventana de videos)
            if not xbmc.getCondVisibility("Window.IsActive(10025)"):
                return False
                
            # Pequeña pausa de 100ms para no saturar el procesador mientras espera
            if monitor.waitForAbort(0.1):
                break

        # Si llegamos aquí, es porque el Control 50 YA ES VISIBLE
        xbmc.sleep(100) # Margen mínimo para que el motor gráfico procese el cambio
        xbmc.executebuiltin("Container.SetViewMode(515)")
        
        '''for _ in range(80):
           if xbmc.getCondVisibility("Control.IsVisible(50)"):
               # ¡Encontrado! Salimos del bucle inmediatamente
               xbmc.executebuiltin("Container.SetViewMode(515)")
               break
           xbmc.sleep(100)'''
        #xbmcgui.Dialog().ok("cargado", "modo_50")   
        #threading.Thread(target=espera_boton_back_visible, args=(url, '515')).start()
        #time.sleep(15)
        #xbmc.executebuiltin("Container.SetViewMode(515)")
     
    if "palantir" in url:
        xbmc.sleep(300)
        #xbmcgui.Dialog().ok("nos vamos a", "modo_escucha")
        
        modo_escucha(url, True)
        #xbmcgui.Dialog().ok("fin", " a ver")  
        sys.exit()
        #xbmcgui.Dialog().ok("sale del bucle", "Por echar para atras")
   #xbmcgui.Dialog().ok("filemon", " a ver")  
   #LAS TRES LINEAS SIGUIENTES VAN UNIDAS PARA QUE NO SALGAN ERRORES POSTERIORES
   #xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
   #xbmc.executebuiltin('Dialog.Close(all)')                            
   #sys.exit()
   # CON ESAS TRES COSAS REPLICAMOS EXACTAMENTE IGUAL QUE HAGAMOS CLIK EN FAVORITOS AL PEDIR UNA CARPETA A PALANTIR 
   #xbmc.executebuiltin(f'RunPlugin("{url}")')
def desofuscar(url):
              #  Wish, Vidhide, Upstream, filemoon 
    #xbmc.log("URL FINAL ES :  " + url, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("filemon", url)   
    regex = r"text/javascript'>(.*?)</script>"    
    es_android = xbmc.getCondVisibility("system.platform.android")
    headers = HEADERS["android"] if es_android else HEADERS["desktop"]
    if 'filemoon' not in url:         
        html_content = url
    else:         
        #re_ifra = re.search(r'(?s)src="([^"]*ptsd[^"]+)"', html_content, re.DOTALL)
        re_ifra = re.search(r'(?s)<iframe src="(.*?)"', url, re.DOTALL)
        if re_ifra:
            iframe_url = re_ifra.group(1)
        else:            
            url = "2701"
            return url        
        response = requests.get(iframe_url, headers=headers)
        html_content = response.text             
        
    match = re.search(regex, html_content, re.DOTALL)
    
    if match:   
        #xbmcgui.Dialog().ok("MATCH", "hubo match")     
        match = match.group(1)        
        #re_1 = r':\[\{(.*?)\}'  antigua 
        re_1 = r'([^"]*://[^"]*)'# CAPTURA LO QUE ESTE ENTRE COMILLAS Y QUE CONTENGA ://
        re_p = re.search(re_1, match)
        #xbmc.log(str(re_p), xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("captura regex", str(re_p.group(1)))
        if re_p:
            #re_p = '"' + re_p.group(1) + '"'
            re_p = re_p.group(1)
                            
        re_2 = r"',36[^|]*([^']+)"
        re_k = re.search(re_2, match)
        if re_k:
            re_k = re_k.group(1)
            
        ############################################################################ 
        
        p = re_p
        k = re_k
        a = 36
        
        # Convierte k en una lista de elementos.
        k_list = k.split('|') 
        
        # Patrones para encontrar los índices ofuscados
        pattern = re.compile(r'\b[0-9a-zA-Z]+\b')    
        
        # Función para obtener el reemplazo
        def reemplazo(match):
            # Extrae el índice desde el grupo del match
            index = int(match.group(0), a)
            if index < len(k_list):
                # Obtiene el valor de k_list
                valor_reemplazo = k_list[index]
                # Si el valor de reemplazo no es vacío, lo devuelve; de lo contrario, devuelve el texto original
                return valor_reemplazo if valor_reemplazo != "" else match.group(0)
            # Si el índice está fuera del rango, no realiza reemplazo
            return match.group(0)
        
        # Reemplaza las ocurrencias en el texto p utilizando la función reemplazo
        # Esto devuelve el texto modificado con los reemplazos
        p_modificado = pattern.sub(reemplazo, p)
        ########################################################################################      
        url_sin = p_modificado
        #xbmc.log(url_deo, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("captura regex", url_deo)
        
        #re_3 = r'"(.*?)"'    
        #url_sin = re.search(re_3, url_deo).group(1)     
        
        headers_string = '&'.join([f"{key}::{value.replace(' ', '+')}" for key, value in headers.items()])        
        headers_string = quote(headers_string, safe="&+").replace('%3A%3A', '=')    
        
        ############################# ASI SE CONFIGURA KODI E inputstream.adaptive PARA QUE TE DE LE VIDEO  ##################################    
        ###liz = xbmcgui.ListItem(url_sin)
        ###liz.setProperty('inputstream.adaptive.manifest_headers', headers_string)
        ###liz.setProperty('inputstream', 'inputstream.adaptive')
        ###liz.setProperty('inputstream.adaptive.manifest_type', 'hls')  # Define que el manifiesto es HLS
        ###liz.setMimeType('application/vnd.apple.mpegstream_url')  # Tipo MIME para el stream HLS
        ###liz.setContentLookup(False)
        ###liz.setPath(url_sin)
        ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)    
        ###sys.exit()
        #######################################################################################################################################    
        url_con = f"{url_sin}|{headers_string}"       
    
    else:
        global html_content_errores
        html_content_errores = html_content
        
    return url_con
    #
    
def resolver_Streamwish(url):
    regex = 'file: "([^"]+)'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    match = re.search(regex, html_content)
    if match:
        url_final = match.group(1)
        #xbmcgui.Dialog().ok("Estoy dentro de url_con_cabeza", str(url_final))
        url = url_final
    else:
        xbmcgui.Dialog().ok("Error 2701", "Ponte en contacto con el creador del addon para darle el código de error. Disculpe las molestias.")
        #sys.exit()    
    return url
    
def texto_url2(url):
    es_android = xbmc.getCondVisibility("system.platform.android")
    headers = HEADERS["android"] if es_android else HEADERS["desktop"]
    try:
        
        response = requests.get(url, headers=headers)  # Agregar tiempo de espera
        #response.raise_for_status() # Lanza una excepción si la respuesta no es 2xx
        #xbmc.log(response.text, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("Estoy dentro de texto_url", f'devuelvo texto: {url}')
        return response.text
        
    except requests.RequestException as e:
        caller_frame = inspect.stack()[1]
        caller_info = f"Llamado desde {caller_frame.filename}, línea {caller_frame.lineno}, en la función {caller_frame.function}"
        #xbmc.log(caller_info, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("Estoy dentro de funcion texto_url", f'devuelvo none: {url}')
        return None
    
def url_con_cabeza(url, regex):  
    es_android = xbmc.getCondVisibility("system.platform.android")
    headers = HEADERS["android"] if es_android else HEADERS["desktop"]
    response = requests.get(url, headers=headers)
    html_content = response.text    
    match = re.search(regex, html_content)
    #xbmc.log(html_content, xbmc.LOGINFO) 
    #xbmcgui.Dialog().ok("Estoy dentro de url_con_cabeza", str(match))
    if match:
        url_final = match.group(1)        
        headers_string = '&'.join([f"{key}::{value.replace(' ', '+')}" for key, value in headers.items()])
        headers_string = quote(headers_string, safe="&+").replace('%3A%3A', '=')    
        url_con = f"{url_final}|{headers_string}"
    else:
        url_con = "2701"
    return url_con
    #url_final_with_headers = f'''{url_final}|Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/98.0.4758.102Safari/537.36'''
    #return url_final_with_headers
    
    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url_final_with_headers))
    #sys.exit()
    
def resolver_Vtube(url, regex1, regex2): 
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url, headers=headers)
    html_content = response.text
        
    match = re.search(f"(?s){regex1}.*?{regex2}", html_content)
    cacho2 = match.group(1)    
    cacho1 = match.group(2)    
    url_final = f"https://{cacho1}.vtube.network/hls/{cacho2}.urlset/master.m3u8"  
    #xbmc.log(url_final, xbmc.LOGINFO) 
    url_final_with_headers = f'''{url_final}|Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/98.0.4758.102Safari/537.36'''
    return url_final_with_headers
    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url_final_with_headers))
    #sys.exit()
def resolve_vidhide(url):
    
    try:  
        
        resolved_url = desofuscar(url)              
        return resolved_url                
    except:
        #xbmc.log(url, xbmc.LOGINFO)
        #xbmcgui.Dialog().ok("error", f'error desofuscar: {url}')
        #sys.exit()
        html_content = html_content_errores 
        
        if "Video is processing" in html_content:
            xbmcgui.Dialog().ok("Aviso de codificación.", "Pendiente de codificación, cuando termine el proceso podrá disfrutar del video, disculpe las molestias.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')
            sys.exit()
        elif "vidhide" in url:
            url_descargas = url.replace("/v/", "/download/").replace("/file/", "/download/")   
            html_content = texto_url(url_descargas)
            if 'No such file=' in html_content:
                url = "2701"
                return url
                #xbmc.log(html_content, xbmc.LOGINFO)
                #xbmcgui.Dialog().ok("Error--- 2701", "Contacte con el creador del addon para darle el código de error. Disculpe las molestias.")
            if '.mkv' in html_content:
                prefijo = "_n" 
                nueva_url_descargas = url_descargas + prefijo
                html_content = texto_url(nueva_url_descargas)
                
                if 'Downloads disabled' in html_content:
                    xbmcgui.Dialog().ok("Avis de codificación", "Pendiente de codificación, cuando termine el proceso podrá disfrutar del video, disculpe las molestias.")
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                    xbmc.executebuiltin('Dialog.Close(all)') 
        
        elif "Please allow a few hours for the file to be" in html_content or "Please give us some time" in html_content:       
            xbmcgui.Dialog().ok("Servidor en mantenimiento", "Espere unas horas para que el archivo se transfiera a un servidor de mayor rendimiento. Gracias por su paciencia.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')                
        elif "File Not Found" in html_content:
            xbmcgui.Dialog().ok("Archivo borrado", "Contacte con el creador del addon para que repare el enlace. Si no le avisa, él no sabrá que este enlace tiene que repararlo. Disculpe las molestias.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')
        else:
            url = "2701"
            return url
            #xbmcgui.Dialog().ok("Error--- 2701", "Contacte con el creador del addon para darle el código de error. Disculpe las molestias.")
            #xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            #xbmc.executebuiltin('Dialog.Close(all)')
    #xbmcgui.Dialog().ok("Error 2701", str(url))
#bandera = True 
def normalizar_texto(texto):
    """
    Convierte entidades HTML, minúsculas y quita acentos
    """
    if texto is None:
        return ""
    
    # 1. Convertir entidades HTML (&amp; -> &)
    # Esto detecta cosas como &amp;, &quot;, &lt;, etc. y las limpia
    texto = html.unescape(texto)
    
    # 2. Convertir a minúsculas
    texto = texto.lower()
    
    # 3. Quitar acentos usando unicodedata
    texto = ''.join(
        c for c in unicodedata.normalize('NFD', texto)
        if unicodedata.category(c) != 'Mn'
    )
    
    return texto
def ranking(titulo, año):
    enlace_ex = ""
    PELICULAS_ESPECIALES = {}
    sinmatch = 1
    url_Dic ="https://dl.dropbox.com/scl/fi/xcoq9md1t1c58z5w1ycb8/diccionario.txt?rlkey=877jkx64tapwtfye0qqh9fy8u&st=5eyvhnd7&dl=1"
    url = ''
    encoded_titulo = urllib.parse.quote(titulo, safe='')
    url_segun = f'https://www.themoviedb.org/search?language=es&query={encoded_titulo}'
    
      
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url_segun, headers=headers)
    html_content = response.text
    
    
    elegir_pagina = r'(?s)div class="details".*?href="(.*?)".*?h2>(.*?)<.*?release_date">(.*?)<.*?p>(.*?)<'
    matches = []
    count = 0
    #xbmc.log(f"matches: {html_content}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("ahora", "Si")
    # Usar finditer que es más eficiente (procesa lazily)
    for match in re.finditer(elegir_pagina, html_content):
        if not match or count >= 5:
            
            break
        
        matches.append(match.groups())
        count += 1
    
    #xbmcgui.Dialog().ok("ahora", f"{titulo}")
    if matches:
        titulo = normalizar_texto(titulo)
        for match in matches:
            enlaceth, tituloth, añoth, tramath = match
            
            tituloth = tituloth.strip()
            match_añoth = re.search(r'\d{4}', añoth)
           
            if match_añoth:
                añoth = match_añoth.group()                                
                tituloth = normalizar_texto(tituloth)               
                #xbmc.log(f"URL obtenida: {añoth} {año}  {tituloth} {titulo}", xbmc.LOGINFO)
                #xbmcgui.Dialog().ok('titulo', f'{encoded_titulo}')
                if titulo == tituloth and año == añoth:
                    if titulo == 'campeones':
                        if 'baloncesto' in tramath.lower():  # Es la española
                            enlace_ex = enlaceth
                            trama = tramath
                            break
                        else:  # Es la peruana u otra
                            continue  # Saltar y buscar siguiente
                    else: 
                        sinmatch = 0
                        enlace_ex = enlaceth
                        trama = tramath
                        break
            else:
                añoth = "0000"  # o algún valor por defecto
                continue            
    #xbmcgui.Dialog().ok('titulo', f'{titulo}'.lower())    
      
    
    if sinmatch == 1: 
        #xbmcgui.Dialog().ok('titulo', f'{titulo}')
        response = requests.get(url_Dic, headers=headers)    
        html_content = response.text    
        # Buscamos directamente el título dentro del string
        # Este regex busca: "titulo": "enlace" o 'titulo': 'enlace'
        pattern = rf'["\']{re.escape(titulo.lower())}["\']\s*:\s*["\'](.*?)["\']'
        match_peli = re.search(pattern, html_content, re.IGNORECASE)

        if match_peli:
            enlace_ex = match_peli.group(1)
                        
    if enlace_ex == "":
        xbmcgui.Dialog().ok("ERROR 270175", f'La pelicula: *** [COLOR green]{titulo}[/COLOR] *** tienes que añadirla al diccionario, por favor informe al Boos del Play')
        cancelar_totalmente()
        
    url = 'https://www.themoviedb.org' + enlace_ex 
    
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url, headers=headers)
    html_content = response.text  
   
    match = re.search(r'description" content="(.*?)"', html_content)
    if match:
        trama = match.group(1)
        
    match = re.search(r'(?s)data-percent="(.*?)"', html_content)
    if match:
        puntuacion_texto = match.group(1)       
        puntuacion = int(puntuacion_texto) / 10
        puntuacion = str(puntuacion).replace('.0', '').replace('.', ',')
        if len(puntuacion) == 1:
            puntuacion = " " + puntuacion
    else:
        puntuacion = '--' 
        
    if '?language=es' in url:       
        url = url.replace('?language=es', '/cast')
    else:
        url = url + '/cast'
        
    headers = {'User-Agent': 'iPad'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    
    R_corte_web = r'(?s)section class="panel pad">(.*?)</section' 
    match = re.search(R_corte_web, html_content)
    if match:
        corte_web = match.group(1)        
        soup = BeautifulSoup(corte_web, 'html.parser')
    else:
        soup = BeautifulSoup(html_content, 'html.parser')

    # Buscamos todos los elementos de la lista del reparto
    reparto_items = soup.find_all('li', attrs={'data-order': True})

    matches_invertidos = []
    count = 0

    for item in reparto_items:
        # Si ya tenemos 10 actores VÁLIDOS, paramos
        if count >= 10:
            break

        # 1. EXTRAER NOMBRE (Obligatorio)
        info_div = item.find('div', class_='info')
        nombre = ""
        personaje = ""
        foto = ""
        if info_div:
            nombre_tag = info_div.find('a')
            if nombre_tag:
                nombre = nombre_tag.get_text(strip=True)
                
                personaje_tag = info_div.find('p', class_='character')
                if personaje_tag:
                    personaje = personaje_tag.get_text(strip=True)

        # 2. EXTRAER FOTO (Obligatorio)
        # Buscamos la etiqueta img; si no existe, 'foto' será un string vacío
        img_tag = item.find('img', class_='profile w-full')
        foto = img_tag.get('src', '') if img_tag else ""       

        # --- VALIDACIÓN CRÍTICA ---
        # Solo procesamos si hay NOMBRE y hay FOTO
        if nombre and foto:
            # Limpieza de entidades HTML (ej: &amp; -> &)
            nombre_clean = html.unescape(nombre)
            personaje_clean = html.unescape(personaje)

            if personaje_clean:
                text = f"{nombre_clean} ([COLOR green]{personaje_clean}[/COLOR])"
            else:
                text = nombre_clean

            # Añadimos a la lista y subimos el contador
            matches_invertidos.append((text, foto))
            count += 1
        else:
            # Si falta el nombre o la foto, ignoramos este <li> y pasamos al siguiente
            continue

    #xbmc.log(f"URL obtenida: {matches_invertidos}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("dentro de petra.cajon", 'ves')
    
   
    
    #xbmcgui.Dialog().ok('titulo', f'puntuacion: {puntuacion}\n fotos: {matches_limited}\ntrama: {trama}')
    return puntuacion, matches_invertidos, trama
def decode (url):
    #xbmc.log(f"URL obtenida: {url}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("dentro de petra.cajon", url)
    params = sys.argv[2]
    url = params.replace('?', '')
    url = urllib.parse.unquote(url)
    padding_needed = len(url) % 4
    if padding_needed:
        url += '=' * (4 - padding_needed)            
    trozo_bites = base64.b64decode(url)
    url = trozo_bites.decode('utf-8') 
    
    return url
def foto_lista():
     # Obtener la lista de reproducción de video
    playlist_id = xbmc.PLAYLIST_VIDEO
    #xbmc.log(f"Obteniendo la lista de reproducción de videos con ID {playlist_id}.", xbmc.LOGINFO)
    playlist = xbmc.PlayList(playlist_id)
    
    # Asegurarse de que la lista de reproducción no esté vacía
    size = playlist.size()
    #xbmc.log(f"Lista de reproducción de videos obtenida: tamaño {size}.", xbmc.LOGINFO)
    
    ###if size == 0:
        ###xbmc.log("La lista de reproducción de videos está vacía.", xbmc.LOGINFO)
        ###return
    
    #urls = []
    for index in range(size):
        item = playlist[index]
        #xbmc.log(f"Accediendo al elemento {index}.", xbmc.LOGINFO)
        if isinstance(item, xbmcgui.ListItem):
            # Obtener la URL del item, que normalmente se encuentra en el 'path'
            url = item.getPath()
            #xbmc.log(f"URL obtenida: {url}", xbmc.LOGINFO)
            #if url:
                #urls.append(url)
        else:
            xbmc.log(f"Elemento en la lista de reproducción no es un xbmcgui.ListItem: {item}", xbmc.LOGINFO)
    
    
    url_L = decode(url)
    match = re.search(r"iconimage=(.*?)&", url_L)
        
    
    if any(term in url for term in ['palantir', 'mega', 'rapidgator', '.com/%3F']):
        
        #re.search(r'palantir|mega|rapidgator', url):
        foto = 'https://dl.dropbox.com/scl/fi/xljdbiee07ody1xo0mimp/pasar_por_caja.jpg?rlkey=3o2mripsa3c14fqmzj2e6enoz&st=f5qb845n&dl=0'
    else:    
        foto = match.group(1)
   
    return foto
    #xbmcgui.Dialog().ok("dentro de petra.cajon", str(url))
    #sys.exit()
def palantir_p(url):    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    xbmc.executebuiltin('Dialog.Close(all)')           
        ##EJECUTA EL LINK DE PALANTIR
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))
    control_bucle = 0
    # Sistema de espera infinita
    player = xbmc.Player()
    monitor = xbmc.Monitor() 
    xbmc.executebuiltin('Dialog.Close(12002)')            
    time.sleep(5)
    if player.isPlaying():                
        while not monitor.abortRequested():
            #xbmcgui.Dialog().notification('dentro del bucle', 'lol', time=1000, sound=False)
            # 1. Usuario reproduce algo
            if player.isPlaying():
                # Esperar a que termine usuario da STOP
                while player.isPlaying() and not monitor.abortRequested():           
                    monitor.waitForAbort(0.1)
            if xbmc.getCondVisibility("Window.IsActive(12000)"):             
                xbmc.executebuiltin('Dialog.Close(12000)')
                control_bucle = 1
                break 
            if xbmc.getCondVisibility('Control.IsVisible(50)') or xbmc.getCondVisibility('Window.IsVisible(Home)'):            
                control_bucle = 2
                break
            monitor.waitForAbort(0.4)        
    '''if control_bucle == 1:
        xbmcgui.Dialog().notification('cartel de opciones', 'Estoy fuera del blucle', time=2000, sound=False)
    if control_bucle == 2:
        xbmcgui.Dialog().notification('Back', 'Estoy fuera del blucle', time=2000, sound=False)'''
        
    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(12002)')
    sys.exit()
    
def cajon(trailer, url, saltar, año, titulo):
    
    if titulo != "":
        foto = foto_lista()
        foto = urllib.parse.unquote(foto)        
        puntuacion_pelicula, fotos_filma, trama = ranking(titulo, año)
        #xbmcgui.Dialog().ok("dentro de petra.cajon", titulo)
        if titulo == 'Jokes & Cigarettes':
            titulo = 'Saben aquell'
        #if titulo != "Ocho pasos":
        sinopsis = trama.replace("(FILMAFFINITY)", "").replace("<br />", "")
        try:
            # Para Python >= 3.4
            from html import unescape
            def decode_html_entities(text):
                return unescape(text)
        except ImportError:
            # Para Python < 3.4
            from HTMLParser import HTMLParser
            def decode_html_entities(text):
                return HTMLParser().unescape(text)  # Instancia HTMLParser localmente
        sinopsis = decode_html_entities(sinopsis)
    
########################################################################################################## 
            ######### fotos_filma es una lista de tuplas cada tupla tiene el nombre y foto
        # Inicializar todas las variables con valores vacíos
        nombres = [""] * 10
        imagenes = [""] * 10

        # Asignar valores desde la tupla fotos_filma
        for i, (nombre, imagen) in enumerate(fotos_filma[:10]):
            nombres[i] = nombre
            imagenes[i] = imagen

        # Desempaquetar valores en variables explícitas
        n_ac1, n_ac2, n_ac3, n_ac4, n_ac5, n_ac6, n_ac7, n_ac8, n_ac9, n_ac10 = nombres
        ac1, ac2, ac3, ac4, ac5, ac6, ac7, ac8, ac9, ac10 = imagenes
        
############################################################################################################ 
    else:
        sinopsis = año
    salta_cajon = int(saltar)
    
    #Cuando salta_cajon es 1 y respuesta = 0 va directamente a darte la pelicula seccion hecha para cine kinki
    if salta_cajon == 1:
        respuesta = 0
        if any(substring in trailer for substring in ["duffyou", "moestv", "imdb", "vidhidepre"]) and url == "url":            
            respuesta = 1
            #xbmcgui.Dialog().ok("paso 1/4", "respuesta = 1")
    # Determinar la función de traducción de ruta adecuada según la versión de Kodi
    kodi_version = xbmc.getInfoLabel('System.BuildVersion')
    if kodi_version.startswith('19'):
        from xbmc import translatePath as variacion_translatePath
        db_name = "MyVideos119.db"
    elif int(kodi_version.split('.')[0]) >= 20:
        from xbmcvfs import translatePath as variacion_translatePath
        db_name = "MyVideos121.db"
    else:
        raise RuntimeError("Versión de Kodi no compatible")
    
    
    ruta_especial_kodi = xbmcvfs.translatePath("special://database/").encode("utf-8").decode("utf-8")        
    nombre_db = db_name
    ruta_completa_db = os.path.join(ruta_especial_kodi, nombre_db)
    #xbmcgui.Dialog().textviewer("ruta", str(ruta_completa_db))
    # Conecta con la base de datos SQLite
    conexion = sqlite3.connect(ruta_completa_db)
    cursor = conexion.cursor()
    #xbmc.log(str(cursor), xbmc.LOGINFO)
    #xbmcgui.Dialog().textviewer("ruta", str(cursor))
    try:
        # Consulta para obtener todos los datos de la columna strFilename de la tabla files
        cursor.execute("SELECT idFile, strFilename FROM files;")
        resultados = cursor.fetchall()
        
        # Variable para verificar si se encontraron datos
        datos_encontrados = False

        # Imprime los resultados en el log de Kodi
        for resultado in resultados:
            decoded_str_filename = urllib.parse.unquote(resultado[1])  # Decodificar la cadena
            #xbmc.log(f"ID: {resultado[0]}, strFilename: {decoded_str_filename}", xbmc.LOGINFO)
            
            
            if url in decoded_str_filename:
                # Se encontró la URL en el strFilename. Ahora, consultamos la tabla bookmark
                cursor.execute("SELECT idBookmark FROM bookmark WHERE idFile = ?;", (resultado[0],))
                bookmark_resultado = cursor.fetchone()

                if bookmark_resultado:
                    #xbmcgui.Dialog().ok("BINGO!!!!", f"Se encontró la URL en el strFilename. ID: {resultado[0]}\nID Bookmark: {bookmark_resultado[0]}")
                    salta_cajon = 1
                    respuesta = 0
                    if any(substring in trailer for substring in ["duffyou", "moestv", "imdb", "vidhidepre"]) and url == "url":
                        respuesta = 1
                        #xbmcgui.Dialog().ok("paso 2/4", "seguimos insistiendo en respuesta = 1")
                    conexion.close()
                #else:
                    #xbmcgui.Dialog().ok("BINGO!!!!", f"Se encontró la URL en el strFilename. ID: {resultado[0]}\nNo hay Bookmark asociado.")

                #datos_encontrados = True

        # Muestra el mensaje adecuado en el diálogo de Kodi
        #if not datos_encontrados:
            #xbmcgui.Dialog().ok("Datos encontrados.", "NINGUNO")

    except sqlite3.Error as e:
        xbmc.log(f"Error al consultar la base de datos: {e}", xbmc.LOGERROR)

    finally:
        # Cierra la conexión con la base de datos
        if conexion:
            conexion.close()
    #xbmcgui.Dialog().textviewer("ruta", str(cursor))
    

    #xbmcgui.Dialog().ok("ruta", str(salta_cajon))
    if salta_cajon == 0:
        if url.startswith('Estreno:'):
            dialog = xbmcgui.Dialog()
            respuesta = dialog.select('Próximamente......', [f'                                                        [COLOR pink][B]   {url}[/COLOR][/B]  ', '                                    <<  [COLOR green][B]Ver trailer[/B][/COLOR]  >>'])
        else:
            if sinopsis == "":
                dialog = xbmcgui.Dialog()
                respuesta = dialog.select('¿ Qué eliges ver ?                                                            ', ['                                <<<  [COLOR green][B]Ver película[/B][/COLOR]  >>>', '                                    <<  [COLOR green][B]Ver tráiler[/B][/COLOR]  >>'])
            else: 
                mostrar_reparto = len(fotos_filma) > 0
                #xbmcgui.Dialog().ok("paso 1/4", f'{mostrar_reparto}')
                class CustomDialog(xbmcgui.WindowXMLDialog):
                    
                    def __init__(self, *args, **kwargs):
                        super(CustomDialog, self).__init__(*args, **kwargs)
                        # Guardamos el valor que calculamos antes (True o False)
                        self.mostrar_reparto = kwargs.get('mostrar_reparto', False)
                        self.puntuacion = kwargs.get('puntuacion', 'puntuacion no disponible')
                        self.sinopsis = kwargs.get('sinopsis', 'Sinopsis no disponible')
                        self.N_ac1 = kwargs.get('N_ac1', 'N_ac1 no disponible')
                        self.N_ac2 = kwargs.get('N_ac2', 'N_ac2 no disponible')
                        self.N_ac3 = kwargs.get('N_ac3', 'N_ac3 no disponible')
                        self.N_ac4 = kwargs.get('N_ac4', 'N_ac4 no disponible')
                        self.N_ac5 = kwargs.get('N_ac5', 'N_ac5 no disponible')
                        self.N_ac6 = kwargs.get('N_ac6', 'N_ac6 no disponible')
                        self.N_ac7 = kwargs.get('N_ac7', 'N_ac7 no disponible')
                        self.N_ac8 = kwargs.get('N_ac8', 'N_ac8 no disponible')
                        self.N_ac9 = kwargs.get('N_ac9', 'N_ac9 no disponible')
                        self.N_ac10 = kwargs.get('N_ac10', 'N_ac10 no disponible')
                        self.foto = kwargs.get('foto', 'foto no disponible')
                        self.foto_ac1 = kwargs.get('foto_ac1', 'foto_ac1 no disponible')
                        self.foto_ac2 = kwargs.get('foto_ac2', 'foto_ac2 no disponible')
                        self.foto_ac3 = kwargs.get('foto_ac3', 'foto_ac3 no disponible')
                        self.foto_ac4 = kwargs.get('foto_ac4', 'foto_ac4 no disponible')
                        self.foto_ac5 = kwargs.get('foto_ac5', 'foto_ac5 no disponible')
                        self.foto_ac6 = kwargs.get('foto_ac6', 'foto_ac6 no disponible')
                        self.foto_ac7 = kwargs.get('foto_ac7', 'foto_ac7 no disponible')
                        self.foto_ac8 = kwargs.get('foto_ac8', 'foto_ac8 no disponible')
                        self.foto_ac9 = kwargs.get('foto_ac9', 'foto_ac9 no disponible')
                        self.foto_ac10 = kwargs.get('foto_ac10', 'foto_ac10 no disponible')
                        self.button_label = kwargs.get('button_label', 'Python')
                        self.button_label2 = kwargs.get('button_label2', 'Python2')
                        self.respuesta = None

                    def onInit(self):
                        try:
                            # Si mostrar_reparto es True, enviamos "true" al XML, si no "false"
                            valor_xml = "true" if self.mostrar_reparto else "false"
                            self.setProperty('hay_reparto', valor_xml)
                            self.getControl(200).setImage(self.foto)
                            self.getControl(201).setImage(self.foto_ac1)
                            xbmc.log(f"Setting CurrentActor to: {self.N_ac1}", xbmc.LOGINFO)  # Log para depurar
                            xbmcgui.Window().setProperty("CurrentActor", self.N_ac1)  # Se establece la propiedad directamente
                            self.getControl(202).setImage(self.foto_ac2)
                            self.getControl(203).setImage(self.foto_ac3)
                            self.getControl(204).setImage(self.foto_ac4)
                            self.getControl(205).setImage(self.foto_ac5)
                            self.getControl(206).setImage(self.foto_ac6)
                            self.getControl(207).setImage(self.foto_ac7)
                            self.getControl(208).setImage(self.foto_ac8)
                            self.getControl(209).setImage(self.foto_ac9)
                            self.getControl(210).setImage(self.foto_ac10)
                            self.getControl(101).setLabel(self.puntuacion)
                            self.getControl(100).setText(self.sinopsis)
                            self.getControl(301).setLabel(self.N_ac1)
                            self.getControl(302).setLabel(self.N_ac2)
                            self.getControl(303).setLabel(self.N_ac3)
                            self.getControl(304).setLabel(self.N_ac4)
                            self.getControl(305).setLabel(self.N_ac5)
                            self.getControl(306).setLabel(self.N_ac6)
                            self.getControl(307).setLabel(self.N_ac7)
                            self.getControl(308).setLabel(self.N_ac8)
                            self.getControl(309).setLabel(self.N_ac9)
                            self.getControl(310).setLabel(self.N_ac10)
                            self.getControl(1).setLabel(self.button_label)
                            self.getControl(2).setLabel(self.button_label2)
                            # Aquí puedes configurar los controles si es necesario
                        except Exception as e:
                            xbmcgui.Dialog().textviewer("Error en onInit:", f'{str(e)}')
                            xbmc.log(f"Error en onInit: {str(e)}", xbmc.LOGERROR)
                    
                    def onClick(self, controlId):
                        if controlId == 10:  # El ID del botón "X"
                            self.close()  # Cierra el diálogo
                            
                        elif controlId == 1:
                            self.respuesta = 0
                            self.close()
                        elif controlId == 2:
                            self.respuesta = 1
                            self.close()

                    def getRespuesta(self):
                        return self.respuesta

                # Obtener ruta absoluta para el archivo XML
                addon = xbmcaddon.Addon()
                direccion = addon.getAddonInfo('path')

                # Crear y mostrar el diálogo personalizado
                
                dialog = CustomDialog('dialog_custom.xml', direccion, 'skin.xonfluence',
                mostrar_reparto = mostrar_reparto,
                foto = f'{foto}', foto_ac1 = f'{ac1}', 
                foto_ac2 = f'{ac2}', 
                foto_ac3 = f'{ac3}', 
                foto_ac4 = f'{ac4}', 
                foto_ac5 = f'{ac5}', 
                foto_ac6 = f'{ac6}', 
                foto_ac7 = f'{ac7}', 
                foto_ac8 = f'{ac8}', 
                foto_ac9 = f'{ac9}', 
                foto_ac10 = f'{ac10}', 
                N_ac1=f'{n_ac1}',
                N_ac2=f'{n_ac2}',
                N_ac3=f'{n_ac3}',
                N_ac4=f'{n_ac4}',
                N_ac5=f'{n_ac5}',
                N_ac6=f'{n_ac6}',
                N_ac7=f'{n_ac7}',
                N_ac8=f'{n_ac8}',
                N_ac9=f'{n_ac9}',
                N_ac10=f'{n_ac10}',
                puntuacion=f"{puntuacion_pelicula}", 
                sinopsis=f"{sinopsis}", 
                button_label=f"[COLOR orange][B]{titulo}[/B][/COLOR]", 
                button_label2="[B][COLOR red]-------[/COLOR][/B]" if trailer == "" or ".com/v" in trailer else "[B]Tráiler[/B]")
                dialog.doModal()

                # Recuperar la respuesta después de que el diálogo se haya cerrado
                respuesta = dialog.getRespuesta()
                #xbmc.log(f"Respuesta del diálogo: {respuesta}", xbmc.LOGDEBUG)
                del dialog
            
                ##dialog = xbmcgui.Dialog()
                ##respuesta = dialog.select('¿ Qué eliges ver ?                                                            ', ['                                <<<  [COLOR green][B]Ver película[/B][/COLOR]  >>>', '                                    <<  [COLOR green][B]Ver tráiler[/B][/COLOR]  >>', '[COLOR orange][B]                                            Sinopsis[/B][/COLOR]'])
       
    if respuesta in [-1, None]:
        cancelar_totalmente()
        
    elif respuesta == 0: 
        rojo = []
        urlfija = url
        seleccionada = ''
        if not "//" in url and not ".com" in url:
            url_final = urlsolve(url)
            return url_final
        if any(substring in url for substring in ["vidhide", "dhtpre", "mivalyo", "ryderjet", "wish", "dumbalag", "iplayerhls", "filemoon", "upstream", "bigwarp", "vembed", "palantir", "com/?"]):
            
            #xbmcgui.Dialog().ok("dentro de petra.cajon", str(url))
            #xbmc.log(f"com/%3F {url}.", xbmc.LOGINFO)
            if "streamwish" in url:
                url = url.replace("streamwish.to/", "yuguaab.com/")
            if "dhtpre" in url:
                url = url.replace("dhtpre.com/f", "mivalyo.com/file")
            url = url.replace("_", "")
            #xbmcgui.Dialog().ok("aqui", f'{url}')           
            if titulo != "":
                while True:
                    url2 = 'https://dl.dropbox.com/scl/fi/uq3zbn24v6wxzwrjqs3mb/lipe.html?rlkey=qjkiqb0l71sootb8k3qe4ryu7&st=0hcgtw4h&dl=0' 
                    #xbmc.log(url, xbmc.LOGINFO)            
                    headers = {'User-Agent': 'iPad'}
                    response = requests.get(url2, headers=headers)
                    html_content = response.text
                    
                    nombre_buscado = titulo
                    # Buscar si el nombre existe y capturar el contenido del link correspondiente
                    pattern = rf'nombre="{re.escape(nombre_buscado)}".*?link=\[([^\]]+)\]'
                    
                    match = re.search(pattern, html_content, re.DOTALL)
                    #xbmcgui.Dialog().ok("titulo coincide", str(sys.version))
                    #nombre_capturado = match.group(1)
                    #xbmc.log(f"URL seleccionada: {match2}", xbmc.LOGINFO)
                    #
                    
                    if match:                        
                        # Extraer las URLs asociadas al nombre
                        urls_raw = match.group(1)                   
                                       # Contenido entre corchetes
                        urls = [url2.strip() for url2 in urls_raw.split(",")]
                        urls.insert(0, urlfija)
                        
                        ###opciones = [f"[COLOR red]{urlparse(url).netloc.split('.')[0]}[/COLOR]" if url in rojo else urlparse(url).netloc.split('.')[0].replace('www', 'Torrent') for url in urls]
                        opciones = []
                        for url in urls:
                            #xbmcgui.Dialog().ok("url", f"{url}")
                            
                            if url in rojo:
                                opciones.append(f"[COLOR red]{urlparse(url).netloc.split('.')[0]}[/COLOR]")
                            else:
                                original_domain = urlparse(url).netloc.split('.')[0]
                                modified_url = original_domain.replace('www', 'Torrent').replace('Torrent28', 'Torrent')
                                if "com/?" in url:
                                    modified_url = "LiveVideo"
                                if modified_url == "":
                                    #xbmcgui.Dialog().ok("a ver", f"paso1  {url}")
                                    modified_url = "magnet"
                                if 'Torrent' in modified_url or 'plugin' in modified_url or 'magnet' in modified_url or 'LiveVideo' in modified_url:
                                    match = re.search(r'(BluRay-720p|BluRay-1080p|MicroHD|4K|BDremux|4k|plugin|magnet|com/\?|WEB-DL%201080p)', url)
                                    
                                    if match:
                                        if modified_url == "LiveVideo":
                                            opciones.append(f'[COLOR olive][B]{modified_url}[/B][/COLOR]')
                                        if modified_url == "plugin":
                                            modified_url = "Varios link"
                                            opciones.append(f'[COLOR violet]{modified_url}[/COLOR]')
                                        if modified_url == "magnet": 
                                            modified_url = "MagNet"
                                            opciones.append(f'[COLOR violet]{modified_url}[/COLOR]')
                                        if modified_url == "Torrent":
                                            opciones.append(f'[COLOR violet]{match.group(0)}[/COLOR]'.replace("%20"," "))
                                    else:
                                        opciones.append(modified_url)
                                else:
                                    
                                    opciones.append(modified_url)
                        #xbmc.log(f"URL seleccionada: {opciones}", xbmc.LOGINFO)       
                        #xbmcgui.Dialog().ok("segundo", "log")
                        opciones = [
    item.replace("Varios link plugin", "Varios link") if "Varios link plugin" in item else item
    for item in opciones
]
                            
                        dialog = xbmcgui.Dialog()
                        opcion = dialog.select(f"Enlaces para la película:[COLOR green] {titulo}[/COLOR]", opciones)  # Mostrar lista de URLs
                        
                        if opcion != -1:  # Si se selecciona una opción
                            seleccionada = urls[opcion]
                            #xbmcgui.Dialog().ok("url seleccionada", str(seleccionada))
                            url = seleccionada
                            if "streamwish" in url:
                                url = url.replace("streamwish.to/", "dumbalag.com/")
                            url = url.replace("_", "")
                            #xbmc.log(f"URL seleccionada: {seleccionada}", xbmc.LOGINFO)
                            #xbmcgui.Dialog().notification("URL Seleccionada", seleccionada, xbmcgui.NOTIFICATION_INFO)
                        else:
                            ###CON LAS 5 LINEAS LE DECIMOS A KODI QUE CIERRE EL CUADRO DE DIALOGO SIN EMITIR ERRORES
                            cancelar_totalmente()
                        if "plugin" in url:
                            break    
                        if "torrent" in url or "magnet" in url:
                            break
                        #xbmc.log(com_url, xbmc.LOGINFO)                 
                            
                        com_url = texto_url(url)                        
                        if com_url is None:                             
                            url_final = "2701"
                            
                        elif any(substring in seleccionada for substring in ['rapidgator', 'streamsilk', 'vembed']) and com_url != None:                                                    
                            import resolveurl                                            
                            resolved_url = resolveurl.resolve(seleccionada) 
                            if not resolved_url:
                                #para que entre por la condicion 2701
                                url_final = "2701"                               
                            else:                        
                                url_final = resolved_url
                                break
                                
                        elif "bigwarp" in url and com_url != None:                            
                            regex = '(?s)sources:\s*\[{file:"(.*?)"'            
                            url_final = url_con_cabeza(url, regex)
                            if url_final != "2701":
                                break
                            
                        elif "filemoon" in url and com_url != None:                  
                            url_final = resolve_vidhide(com_url)
                            if url_final != "2701":
                                break                            
                        else: 
                            
                            url_final = resolve_vidhide(com_url)
                            break
                        
                        if url_final == "2701":                     
                            if seleccionada not in rojo:                       
                                rojo.append(seleccionada)                     
                                                      
                    else:
                        #xbmcgui.Dialog().ok("estará", f"No esta {titulo}")
                        #xbmcgui.Dialog().ok("aqui", f'{url}')
                        if "plugin" in url or "com/?" in url:
                            break
                        com_url = texto_url(url)
                        url_final = resolve_vidhide(com_url)
                        break
            else:
                if "plugin" in url:
                    palantir_p(url)
                else:
                    com_url = texto_url(url)
                    url_final = resolve_vidhide(com_url)
            if "torrent" in url or "magnet" in url:                
                #xbmc.log(url, xbmc.LOGINFO)
                #xbmcgui.Dialog().ok("estará", 'vete al log')
                return url
                ###item = xbmcgui.ListItem(path=f"plugin://plugin.video.elementum/play?uri={url}")
                ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
                ###sys.exit()
            if "plugin" in url:
                palantir_p(url)
                #xbmcgui.Dialog().ok("estará", 'vete al log')
                #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))
                sys.exit()
            if "com/?" in url:
                url = url.replace('com/?', '')            
                return urlsolve(url)
            return url_final
        elif "com/?" in url:
            url = url.replace('com/?', '')            
            return urlsolve(url)
            
        elif "palantir" in url:
            palantir_p(url)
            '''
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(all)')           
                ##EJECUTA EL LINK DE PALANTIR
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))
            control_bucle = 0
            # Sistema de espera infinita
            player = xbmc.Player()
            monitor = xbmc.Monitor() 
            xbmc.executebuiltin('Dialog.Close(12002)')            
            time.sleep(7)
            if player.isPlaying():                
                while not monitor.abortRequested():
                    #xbmcgui.Dialog().notification('dentro del bucle', 'lol', time=1000, sound=False)
                    # 1. Usuario reproduce algo
                    if player.isPlaying():
                        # Esperar a que termine usuario da STOP
                        while player.isPlaying() and not monitor.abortRequested():           
                            monitor.waitForAbort(0.1)
                    if xbmc.getCondVisibility("Window.IsActive(12000)"):             
                        xbmc.executebuiltin('Dialog.Close(12000)')
                        control_bucle = 1
                        break 
                    if xbmc.getCondVisibility('Control.IsVisible(50)') or xbmc.getCondVisibility('Window.IsVisible(Home)'):            
                        control_bucle = 2
                        break
                    monitor.waitForAbort(0.4)       
            if control_bucle == 1:
                xbmcgui.Dialog().notification('cartel de opciones', 'Estoy fuera del blucle', time=2000, sound=False)
            if control_bucle == 2:
                xbmcgui.Dialog().notification('Back', 'Estoy fuera del blucle', time=2000, sound=False)
                
            
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.executebuiltin('Dialog.Close(12002)')
            sys.exit()'''
            
        elif url.startswith('Estreno:'):               
             # Ruta local al icono en la misma carpeta que tu script
            addon_icon_path = os.path.join(variacion_translatePath('special://home/addons/plugin.video.play'), 'icon.png')
            # Convierte la ruta local a una ruta special://
            icon_path = variacion_translatePath(addon_icon_path)

            # Muestra la notificación con la ruta especial
            xbmcgui.Dialog().notification('[COLOR green]                  No seas impaciente[/COLOR]', f'[COLOR pink][B]   {url}[/COLOR][/B]', icon=icon_path, time=4000)                
            sys.exit()
        
            
    elif respuesta == 1:
        #xbmcgui.Dialog().ok("estoy en respuesta 1", trailer)
        if trailer == "" or ".com/v" in trailer:            
            cancelar_totalmente()
        elif "imdb" in trailer:
            #xbmcgui.Dialog().ok("estoy imbd", " A ver")
            resolve = Trailer_IMBD(trailer)
            return resolve            
        else:
            #RESUELVE LOS TRILER DE FICHER
            trailer_final = urlsolve (trailer)            
            return trailer_final
    elif respuesta == 2: 
        xbmcgui.Dialog().textviewer("Sinopsis", f'{sinopsis}') 
        #xbmc.executebuiltin('Dialog.Close(all, true)')
        #cajon(trailer, url, saltar, sinopsis)
        sys.exit()#con esto se para dentro de la funcion y no vuelve al xml
                    