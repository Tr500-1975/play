import os
import sys
import xbmc
import shutil
import xbmcgui
import xbmcaddon
import xbmcvfs
from xbmcvfs import translatePath as TRANSLATEPATH
import urllib.request
import xml.etree.ElementTree as ET
import zipfile


def copiar_carpeta(origen, destino):
    # 🔹 CASO 1: Si el origen es un archivo
    if os.path.isfile(origen):
        destino_dir = os.path.dirname(destino)
        if destino_dir and not os.path.exists(destino_dir):
            os.makedirs(destino_dir, exist_ok=True)
        if not os.path.exists(destino):
            shutil.copyfile(origen, destino)
        return

    # 🔹 CASO 2: Si el origen es una carpeta
    if os.path.isdir(origen):
        if not os.path.exists(destino):
            os.makedirs(destino, exist_ok=True)

        for item in os.listdir(origen):
            origen_item = os.path.join(origen, item)
            destino_item = os.path.join(destino, item)

            if os.path.isdir(origen_item):
                # En lugar de usar copytree, llamamos de nuevo a esta función
                copiar_carpeta(origen_item, destino_item)
            else:
                if not os.path.exists(destino_item):
                    # Usamos copyfile para evitar transferir metadatos problemáticos
                    shutil.copyfile(origen_item, destino_item)
                    
full_version = xbmc.getInfoLabel('System.BuildVersion')
major_version = int(full_version.split('.')[0])
if major_version <= 20:   
    version_kodi = 'skin.xonfluence'
    origen_advancedsettings = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/advancedsettings.xml')
    destino_advancedsettings = TRANSLATEPATH('special://userdata/advancedsettings.xml')
    copiar_carpeta(origen_advancedsettings, destino_advancedsettings)
elif major_version >= 21:
    version_kodi = 'skin.xonfluence_O'
    

#xbmcgui.Dialog().ok("Resultado", f"version de kodi: {major_version}")

origen_xonfluence = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/skin.xonfluence')
origen_play = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/plugin.video.play')
origen_embuary = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/script.embuary.info')
origen_sources = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/sources.xml')


addon_data_folder = TRANSLATEPATH('special://profile/addon_data/')

destino_xonfluence = os.path.join(addon_data_folder, f'{version_kodi}')
destino_play = os.path.join(addon_data_folder, 'plugin.video.play')
destino_embuary = os.path.join(addon_data_folder, 'script.embuary.info')
destino_sources = TRANSLATEPATH('special://userdata/sources.xml')
        
copiar_carpeta(origen_xonfluence, destino_xonfluence)
copiar_carpeta(origen_play, destino_play)
copiar_carpeta(origen_embuary, destino_embuary)
copiar_carpeta(origen_sources, destino_sources)

    




    
    
    






