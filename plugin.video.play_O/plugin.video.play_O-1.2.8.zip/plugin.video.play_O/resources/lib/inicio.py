import os
import sys
import xbmc
import shutil
import xbmcgui
import xbmcaddon
from xbmcvfs import translatePath as TRANSLATEPATH
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

origen_xonfluence = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/skin.xonfluence_O')
origen_play = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/plugin.video.play_O')
origen_embuary = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/script.embuary.info')
origen_sources = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/sources.xml')
origen_advancedsettings = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/advancedsettings.xml')

addon_data_folder = TRANSLATEPATH('special://profile/addon_data/')

destino_xonfluence = os.path.join(addon_data_folder, 'skin.xonfluence_O')
destino_play = os.path.join(addon_data_folder, 'plugin.video.play_O')
destino_embuary = os.path.join(addon_data_folder, 'script.embuary.info')
destino_sources = TRANSLATEPATH('special://userdata/sources.xml')
destino_advancedsettings = TRANSLATEPATH('special://userdata/advancedsettings.xml')

def copiar_carpeta(origen, destino):

    # 🔹 CASO 1: ORIGEN ES ARCHIVO (sources.xml, advancedsettings.xml)
    if os.path.isfile(origen):
        if not os.path.exists(destino):
            shutil.copy2(origen, destino)
        return

    # 🔹 CASO 2: ORIGEN ES CARPETA
    if os.path.isdir(origen):

        # Si destino no existe → copiar todo
        if not os.path.exists(destino):
            shutil.copytree(origen, destino)
            return

        # Si destino existe → copiar solo lo que falte
        for item in os.listdir(origen):
            origen_item = os.path.join(origen, item)
            destino_item = os.path.join(destino, item)

            if not os.path.exists(destino_item):
                if os.path.isdir(origen_item):
                    shutil.copytree(origen_item, destino_item)
                else:
                    shutil.copy2(origen_item, destino_item)
        
copiar_carpeta(origen_xonfluence, destino_xonfluence)
copiar_carpeta(origen_play, destino_play)
copiar_carpeta(origen_embuary, destino_embuary)
copiar_carpeta(origen_sources, destino_sources)
copiar_carpeta(origen_advancedsettings, destino_advancedsettings)
    




    
    
    






