import base64
import xbmcgui
import xbmc
import requests
import re
import xbmcplugin
import sys
def por_vivo (url):
    
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)    
    response.encoding = 'utf-8'
    html_content = response.text    
    matches = re.search(r'Stream\(window.atob\("(.*?)"', html_content)    
    url = matches.group(1)
    #xbmc.log("resultado url: " + url, xbmc.LOGINFO)  
    #xbmcgui.Dialog().ok("torrent", str(url))
    url = base64.b64decode(url).decode('utf-8') 
    item = xbmcgui.ListItem(path=f"{url}")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    